import React, { useEffect, useState } from "react";
import { api } from "../lib.js";
import { ErrorLine } from "../ui.jsx";

const splitList = (s) => s.split(",").map((x) => x.trim()).filter(Boolean);

function AccountEditor({ account, onSaved, onCancel }) {
  const [f, setF] = useState({
    bank: account?.bank || "", account: account?.account || "",
    holder_names: (account?.holder_names || []).join(", "), sms_senders: (account?.sms_senders || []).join(", "),
    is_active: account?.is_active ?? true,
  });
  const [err, setErr] = useState("");
  const save = async () => {
    setErr("");
    const body = { ...f, holder_names: splitList(f.holder_names), sms_senders: splitList(f.sms_senders) };
    try {
      if (account) await api.patch(`/api/accounts/${account.id}`, body); else await api.post("/api/accounts", body);
      onSaved();
    } catch (e) { setErr(e.message); }
  };
  return (
    <div className="grid grid-cols-2 gap-3 bg-slate-50 border border-slate-200 rounded p-3">
      <div><label className="label">Bank</label><input className="input" value={f.bank} onChange={(e) => setF({ ...f, bank: e.target.value })} placeholder="Commercial Bank" /></div>
      <div><label className="label">Account number (full, as customers should type it)</label><input className="input font-mono" value={f.account} onChange={(e) => setF({ ...f, account: e.target.value })} placeholder="8026328795" /></div>
      <div className="col-span-2"><label className="label">Account holder names (comma separated, all names that may appear on slips)</label>
        <input className="input" value={f.holder_names} onChange={(e) => setF({ ...f, holder_names: e.target.value })} /></div>
      <div className="col-span-2"><label className="label">SMS sender numbers / IDs for this account's credit alerts (comma separated, exactly as shown on the business phone)</label>
        <input className="input font-mono" value={f.sms_senders} onChange={(e) => setF({ ...f, sms_senders: e.target.value })} placeholder="e.g. COMBANK" /></div>
      <label className="text-sm flex items-center gap-2"><input type="checkbox" checked={f.is_active} onChange={(e) => setF({ ...f, is_active: e.target.checked })} /> active</label>
      <div className="flex justify-end gap-2">
        <button className="btn-ghost" onClick={onCancel}>Cancel</button>
        <button className="btn-primary" onClick={save}>Save account</button>
      </div>
      <div className="col-span-2"><ErrorLine error={err} /></div>
    </div>
  );
}

export default function Settings({ health }) {
  const [b, setB] = useState(null);
  const [form, setForm] = useState(null);
  const [edit, setEdit] = useState(null);   // account id | "new"
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const load = () => api.get("/api/business").then((x) => {
    setB(x);
    setForm(x ? { name: x.name, whatsapp_number: x.whatsapp_number || "", hotline: x.hotline || "",
      payment_window_min: x.payment_window_min ?? "", balance_window_min: x.balance_window_min ?? "" } : { name: "", whatsapp_number: "", hotline: "", payment_window_min: 10, balance_window_min: 10 });
  });
  useEffect(() => { load(); }, []);
  if (!form) return null;

  const saveBusiness = async () => {
    setErr(""); setMsg("");
    try {
      await api.put("/api/business", { ...form, payment_window_min: form.payment_window_min === "" ? null : Number(form.payment_window_min),
        balance_window_min: form.balance_window_min === "" ? null : Number(form.balance_window_min), hotline: form.hotline || null });
      setMsg("Saved."); load();
    } catch (e) { setErr(e.message); }
  };

  return (
    <div className="grid grid-cols-[380px_1fr] gap-4 items-start">
      <div className="card p-4 space-y-3">
        <h2 className="font-semibold">Business</h2>
        <div><label className="label">Business name</label><input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
        <div><label className="label">WhatsApp number</label><input className="input" value={form.whatsapp_number} onChange={(e) => setForm({ ...form, whatsapp_number: e.target.value })} /></div>
        <div><label className="label">Hotline (sent to customers for refunds)</label><input className="input" value={form.hotline} onChange={(e) => setForm({ ...form, hotline: e.target.value })} placeholder="011 234 5678" /></div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className="label">Minutes to pay</label><input type="number" min="1" className="input" value={form.payment_window_min} onChange={(e) => setForm({ ...form, payment_window_min: e.target.value })} /></div>
          <div><label className="label">Minutes to pay a balance</label><input type="number" min="1" className="input" value={form.balance_window_min} onChange={(e) => setForm({ ...form, balance_window_min: e.target.value })} /></div>
        </div>
        <p className="text-xs text-slate-500">Leave a time empty for no limit. Late transfers are held as refunds; customers get their customer ID and the hotline.</p>
        <button className="btn-primary w-full" onClick={saveBusiness}>Save</button>
        <ErrorLine error={err} />
        {msg && <div className="text-sm text-emerald-700">{msg}</div>}
      </div>

      <div className="space-y-4">
        {health?.setup_warnings?.length > 0 && <div className="card p-4 bg-amber-50 border-amber-200">
          <div className="font-medium text-sm text-amber-900 mb-1">To finish setup</div>
          <ul className="list-disc pl-5 text-sm text-amber-900 space-y-0.5">{health.setup_warnings.map((w, i) => <li key={i}>{w}</li>)}</ul>
        </div>}
        <div className="card">
          <div className="px-4 py-2 border-b border-slate-200 flex items-center">
            <h2 className="font-semibold mr-auto">Bank accounts</h2>
            <button className="btn-ghost !py-1 text-xs" onClick={() => setEdit("new")}>+ Add account</button>
          </div>
          <div className="p-4 space-y-3">
            {edit === "new" && <AccountEditor onSaved={() => { setEdit(null); load(); }} onCancel={() => setEdit(null)} />}
            {(b?.accounts || []).map((a) => edit === a.id ? (
              <AccountEditor key={a.id} account={a} onSaved={() => { setEdit(null); load(); }} onCancel={() => setEdit(null)} />
            ) : (
              <div key={a.id} className="flex items-start gap-3 border border-slate-200 rounded p-3">
                <div className="flex-1 text-sm">
                  <div className="font-medium">{a.bank} <span className="font-mono">{a.account}</span>
                    {a.masked && <span className="ml-2 text-xs bg-amber-100 text-amber-900 rounded px-1.5">mask only: enter full number</span>}
                    {!a.is_active && <span className="ml-2 text-xs bg-slate-200 rounded px-1.5">inactive</span>}</div>
                  <div className="text-xs text-slate-500 mt-0.5">Names: {a.holder_names.join(" / ") || "–"}</div>
                  <div className="text-xs mt-0.5">SMS senders: {a.sms_senders.length ? <span className="font-mono">{a.sms_senders.join(", ")}</span> : <span className="text-amber-700">not set</span>}</div>
                </div>
                <button className="btn-ghost !py-1 text-xs" onClick={() => setEdit(a.id)}>Edit</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
