"""WhatsApp channel: order creation message, inbound slip routing, Cloud API webhook parsing/verification.

The simulator and the real Meta Cloud API webhook both end in `handle_inbound_image`, so the demo exercises the
same code path production would.
"""
from __future__ import annotations

import hashlib
import hmac
import re
import secrets
import string
from dataclasses import dataclass
from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.clock import LK_TZ, Clock
from app.config import RulesConfig
from app.db.models import Business, BusinessAccount, Customer, Order, OutboundMessage, Submission
from app.domain.decision import Decision
from app.domain.normalize import format_rs
from app.domain.reasons import customer_message
from app.imaging.extraction import SlipExtractor
from app.services.intake import extract_with_cache, submit_slip_image
from app.services.verification import audit

OPEN_STATUSES = ("AWAITING_PAYMENT", "PARTIALLY_PAID")
_CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"   # no O/0, I/1: survives being typed into a bank remark


def normalize_phone(raw: str) -> str:
    digits = re.sub(r"\D", "", raw or "")
    if digits.startswith("0") and len(digits) == 10:       # 0771234567 -> +94771234567
        digits = "94" + digits[1:]
    return "+" + digits


def new_order_code(session: Session) -> str:
    while True:
        code = "".join(secrets.choice(_CODE_ALPHABET) for _ in range(5))
        if not session.scalar(select(Order.id).where(Order.code == code)):
            return code


def get_or_create_customer(session: Session, clock: Clock, business_id: int, name: str, phone: str) -> Customer:
    phone = normalize_phone(phone)
    c = session.scalar(select(Customer).where(Customer.business_id == business_id, Customer.phone == phone))
    if c is None:
        c = Customer(business_id=business_id, name=name.strip(), phone=phone, created_at=clock.now())
        session.add(c)
        session.flush()
    return c


def payment_instructions(business: Business, order: Order, account: BusinessAccount) -> str:
    holder = (account.holder_names or [""])[0]
    lines = [f"Thank you for your order {order.code} from {business.name}.",
             f"Amount to pay: {format_rs(order.expected_cents)}", "", "Please pay to:",
             f"Bank: {account.bank}", f"Account number: {account.display_account}"]
    if holder:
        lines.append(f"Account name: {holder}")
    lines.append("")
    if order.expires_at:
        lines.append(f"Please make the payment within {business.payment_window_min} minutes "
                     f"(by {order.expires_at.astimezone(LK_TZ):%I:%M %p}), otherwise the order will be cancelled.")
    lines += [f"Please write {order.code} in the transfer remarks / narration if your bank allows it.",
              "Then send a photo or screenshot of the payment slip here."]
    return "\n".join(lines)


def notify(session: Session, clock: Clock, customer: Customer, order: Order | None, code: str, **params) -> None:
    """Queue a customer WhatsApp message from a reason template (only customer-safe parameters)."""
    business = session.get(Business, customer.business_id)
    body = customer_message(code, order_code=order.code if order else "", customer_id=customer.code,
                            hotline=business.hotline or "", **params)
    session.add(OutboundMessage(customer_id=customer.id, order_id=order.id if order else None,
                                to_phone=customer.phone, body=body, reason_code=code, created_at=clock.now()))


class OrderError(ValueError):
    pass


def choose_pay_to_account(session: Session, business_id: int, account_id: int | None) -> BusinessAccount:
    """Staff choose which account the customer is told to pay into. A masked account cannot be sent: the customer
    needs the full number. With no choice given, default only if exactly one sendable account exists."""
    sendable = [a for a in session.scalars(select(BusinessAccount).where(
        BusinessAccount.business_id == business_id, BusinessAccount.is_active.is_(True))).all()
        if "*" not in a.account_number]
    if account_id is not None:
        acc = session.get(BusinessAccount, account_id)
        if acc is None or acc.business_id != business_id or not acc.is_active:
            raise OrderError("account not found or inactive")
        if "*" in acc.account_number:
            raise OrderError(f"{acc.bank} account is stored only as a mask ({acc.display_account}). "
                             "Enter the full account number in Settings before sending it to customers.")
        return acc
    if len(sendable) == 1:
        return sendable[0]
    if not sendable:
        raise OrderError("no business account with a full number: add one in Settings")
    raise OrderError("choose which account to send to the customer")


def create_order(session: Session, clock: Clock, business_id: int, customer_name: str, phone: str,
                 amount_cents: int, description: str | None = None, actor: str = "staff",
                 account_id: int | None = None) -> Order:
    if amount_cents <= 0:
        raise OrderError("amount must be positive")
    business = session.get(Business, business_id)
    account = choose_pay_to_account(session, business_id, account_id)
    customer = get_or_create_customer(session, clock, business_id, customer_name, phone)
    now = clock.now()
    order = Order(business_id=business_id, customer_id=customer.id, code=new_order_code(session),
                  description=description, expected_cents=amount_cents, pay_to_account_id=account.id,
                  expires_at=now + timedelta(minutes=business.payment_window_min) if business.payment_window_min else None,
                  created_at=now)
    session.add(order)
    session.flush()
    session.add(OutboundMessage(customer_id=customer.id, order_id=order.id, to_phone=customer.phone,
                                body=payment_instructions(business, order, account), reason_code="ORDER_CREATED",
                                created_at=clock.now()))
    audit(session, clock, actor, "order_created", "order", order.id,
          {"code": order.code, "amount_cents": amount_cents, "customer": customer.id, "pay_to_account": account.id})
    session.commit()
    return order


@dataclass
class InboundResult:
    submission: Submission | None
    decision: Decision | None
    reply: str | None
    duplicate_delivery: bool = False
    order_guessed: bool = False


def _pick_order(session: Session, customer: Customer, caption: str | None, amount_cents: int | None) -> tuple[Order | None, bool]:
    """Order code in the caption wins. Otherwise the customer's single open order. With several open orders,
    prefer the one whose balance equals the slip amount, else the newest; flagged as a guess for staff."""
    if caption:
        for token in re.findall(r"[A-Z0-9]{5}", caption.upper()):
            o = session.scalar(select(Order).where(Order.code == token, Order.customer_id == customer.id))
            if o:
                return o, False
    open_orders = session.scalars(select(Order).where(Order.customer_id == customer.id,
                                                      Order.status.in_(OPEN_STATUSES))
                                  .order_by(Order.created_at.desc())).all()
    if not open_orders:
        # No open order: route to the most recent one anyway, so a re-sent slip is answered as a duplicate and a
        # payment for a paid / expired / cancelled order is recorded as a refund instead of being ignored.
        latest = session.scalar(select(Order).where(Order.customer_id == customer.id)
                                .order_by(Order.created_at.desc()).limit(1))
        return latest, False
    if len(open_orders) == 1:
        return open_orders[0], False
    if amount_cents is not None:
        exact = [o for o in open_orders if o.expected_cents - o.paid_cents == amount_cents]
        if len(exact) == 1:
            return exact[0], True
    return open_orders[0], True


def handle_inbound_image(session: Session, clock: Clock, cfg: RulesConfig, extractor: SlipExtractor,
                         business_id: int, phone: str, image: bytes, message_id: str | None,
                         caption: str | None = None, upload_dir: str | None = None) -> InboundResult:
    phone = normalize_phone(phone)
    if message_id:
        existing = session.scalar(select(Submission).where(Submission.channel_message_id == message_id))
        if existing:
            return InboundResult(existing, None, None, duplicate_delivery=True)
    customer = session.scalar(select(Customer).where(Customer.business_id == business_id, Customer.phone == phone))
    if customer is None:
        return InboundResult(None, None, "Hello! We couldn't find an order for this number. "
                                         "Please place your order first or contact us.")
    # Extraction is cached by image hash, so peeking at the amount for order routing costs nothing extra.
    extraction, meta = extract_with_cache(session, image, extractor, clock)
    order, guessed = _pick_order(session, customer, caption, extraction.get("amount_cents"))
    if order is None:
        msg = "Thank you! We couldn't find an open order for you. Please contact us so we can help."
        session.add(OutboundMessage(customer_id=customer.id, to_phone=customer.phone, body=msg,
                                    reason_code="NO_OPEN_ORDER", created_at=clock.now()))
        session.commit()
        return InboundResult(None, None, msg)
    sub, decision = submit_slip_image(session, order.id, image, extractor, clock, cfg,
                                      channel_message_id=message_id, upload_dir=upload_dir,
                                      pre_extracted=(extraction, meta))
    if guessed:
        audit(session, clock, "system", "order_guessed", "submission", sub.id,
              {"order": order.code, "reason": "customer has several open orders and no code in caption"})
        session.commit()
    reply = decision.customer_message if decision else None
    return InboundResult(sub, decision, reply, order_guessed=guessed)


# --------------------------------------------------------------------------- Meta WhatsApp Cloud API

def verify_meta_signature(app_secret: str, raw_body: bytes, header: str | None) -> bool:
    """X-Hub-Signature-256: 'sha256=<hex hmac of raw body with the app secret>'."""
    if not app_secret or not header or not header.startswith("sha256="):
        return False
    expected = hmac.new(app_secret.encode(), raw_body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, header[7:])


@dataclass
class CloudImageMessage:
    message_id: str
    phone: str
    media_id: str
    caption: str | None


def parse_cloud_webhook(payload: dict) -> list[CloudImageMessage]:
    out = []
    for entry in payload.get("entry", []):
        for change in entry.get("changes", []):
            for m in change.get("value", {}).get("messages", []) or []:
                if m.get("type") == "image" and m.get("image", {}).get("id"):
                    out.append(CloudImageMessage(m["id"], m.get("from", ""), m["image"]["id"],
                                                 m["image"].get("caption")))
    return out


class GraphMediaFetcher:
    """Downloads media from the Graph API. Not exercised offline (needs a real token)."""

    def __init__(self, access_token: str, api_version: str = "v20.0"):
        self.token, self.version = access_token, api_version

    def fetch(self, media_id: str) -> bytes:
        import httpx
        h = {"Authorization": f"Bearer {self.token}"}
        meta = httpx.get(f"https://graph.facebook.com/{self.version}/{media_id}", headers=h, timeout=15).json()
        return httpx.get(meta["url"], headers=h, timeout=30).content


def random_message_id() -> str:
    return "sim." + "".join(secrets.choice(string.ascii_lowercase + string.digits) for _ in range(16))
