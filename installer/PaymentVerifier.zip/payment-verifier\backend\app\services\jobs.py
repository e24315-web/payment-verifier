"""Periodic work (runs every PV_JOB_INTERVAL_S in the app, or via POST /api/jobs/tick).

* Payment window: an order with no transfer/slip by `expires_at` -> EXPIRED (customer told, with hotline + ID).
* Balance window: a partially paid order whose balance is not paid by `balance_due_by` -> CANCELLED; what was paid
  becomes a refund due (customer told, with hotline + ID).
  A slip that arrived inside the window keeps the order open while it is being verified: its own decision
  (approved / LATE_PAYMENT) closes the order instead.
* WAITING_FOR_SMS past its TTL -> re-evaluated, which escalates it to WAITING_FOR_SMS_EXPIRED (human review).
"""
from __future__ import annotations

from datetime import datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.clock import Clock
from app.config import RulesConfig
from app.db.models import Customer, Order, Submission
from app.domain.normalize import format_rs
from app.services.verification import audit, evaluate
from app.services.whatsapp import notify


def _slip_pending(session: Session, order: Order, since: datetime | None, until: datetime) -> bool:
    """Was a slip received inside the window that is still being verified (or not yet decided)?"""
    q = select(Submission.id).where(Submission.order_id == order.id, Submission.created_at <= until,
                                    (Submission.outcome.is_(None)) | (Submission.outcome == "NEEDS_VERIFICATION"))
    if since is not None:
        q = q.where(Submission.created_at >= since)
    return session.scalar(q.limit(1)) is not None


def close_overdue_orders(session: Session, clock: Clock) -> dict:
    now = clock.now()
    expired, cancelled = [], []
    for o in session.scalars(select(Order).where(Order.status == "AWAITING_PAYMENT", Order.expires_at.is_not(None),
                                                 Order.expires_at < now)).all():
        if _slip_pending(session, o, None, o.expires_at):
            continue
        o.status, o.closed_reason = "EXPIRED", "no payment within the payment window"
        audit(session, clock, "system", "order_expired", "order", o.id, {"expires_at": o.expires_at.isoformat()})
        notify(session, clock, session.get(Customer, o.customer_id), o, "ORDER_EXPIRED")
        expired.append(o.id)
    for o in session.scalars(select(Order).where(Order.status == "PARTIALLY_PAID", Order.balance_due_by.is_not(None),
                                                 Order.balance_due_by < now)).all():
        if _slip_pending(session, o, None, o.balance_due_by):
            continue
        o.status, o.closed_reason = "CANCELLED", "balance not paid within the balance window"
        audit(session, clock, "system", "order_cancelled", "order", o.id,
              {"paid_cents": o.paid_cents, "balance_due_by": o.balance_due_by.isoformat()})
        notify(session, clock, session.get(Customer, o.customer_id), o, "ORDER_CANCELLED_BALANCE",
               amount=format_rs(o.paid_cents), balance=format_rs(o.expected_cents - o.paid_cents))
        cancelled.append(o.id)
    session.commit()
    return {"expired_orders": expired, "cancelled_orders": cancelled}


def tick(session: Session, clock: Clock, cfg: RulesConfig) -> dict:
    cutoff = clock.now() - timedelta(minutes=cfg.sms_wait_ttl_min)
    ids = session.scalars(select(Submission.id).where(
        Submission.outcome == "NEEDS_VERIFICATION", Submission.reason_code == "WAITING_FOR_SMS",
        Submission.decided_by == "system", Submission.created_at <= cutoff)).all()
    escalated = []
    for sid in ids:
        d = evaluate(session, sid, clock, cfg)
        if d.reason_code != "WAITING_FOR_SMS":
            escalated.append(sid)
    return {"checked": len(ids), "escalated": escalated, **close_overdue_orders(session, clock)}
