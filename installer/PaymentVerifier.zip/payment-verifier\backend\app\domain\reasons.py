"""Reason codes: one row per decision-table outcome.

Each code carries: default outcome, internal title (staff), next action (staff), customer WhatsApp template.
Customer templates may only use the placeholders in SAFE_PARAMS (the customer's own order/amounts, their customer
ID, the business hotline, the balance deadline).
They never mention SMS, matching, balances of the business account, tamper checks or other customers.
"""
from __future__ import annotations

from dataclasses import dataclass

from app.domain.types import Outcome

A, R, NV = Outcome.APPROVED, Outcome.REJECTED, Outcome.NEEDS_VERIFICATION

_MSG_UNDER_REVIEW = ("Thank you, we have received your payment slip for order {order_code}. "
                     "We couldn't verify this payment yet. Our team will check it and get back to you shortly.")
_MSG_WAITING = ("Thank you, we have received your payment slip for order {order_code}. "
                "We are waiting for confirmation from the bank and will update you shortly.")
_MSG_UNCLEAR = ("We couldn't clearly read the payment slip. Please send a clearer photo of the complete slip "
                "showing the date, time and amount.")


@dataclass(frozen=True)
class ReasonSpec:
    code: str
    outcome: Outcome
    title: str
    next_action: str
    customer_message: str


_SPECS = [
    ReasonSpec("APPROVED_PAID", A, "Payment verified against bank SMS; order fully paid",
               "Fulfil the order.",
               "Thank you! We have received your payment of {amount} for order {order_code}."),
    ReasonSpec("APPROVED_UNDERPAID", A, "Payment verified but less than the balance due; order partially paid",
               "Wait for the customer to pay the balance. Do not fulfil yet.",
               "We have received {amount} for order {order_code}. The remaining balance is {balance}. "
               "Please pay the balance{deadline_clause} and send the payment slip here."),
    ReasonSpec("APPROVED_OVERPAID", A, "Payment verified but more than the balance due; excess is a refund due",
               "Fulfil the order. Refund the excess (customer will call the hotline with their customer ID).",
               "Thank you! We have received your payment for order {order_code}. You paid {excess} more than "
               "the order amount. For the refund of the extra amount, please contact our hotline {hotline} "
               "with your customer ID {customer_id}."),
    ReasonSpec("LATE_PAYMENT", R, "Transfer made after the payment deadline; order closed, payment is a refund due",
               "Refund the payment when the customer calls (customer ID in the message).",
               "We received your payment of {amount}, but it was made after the payment time for order "
               "{order_code}, so the order has been cancelled. Your payment will be refunded: please contact our "
               "hotline {hotline} with your customer ID {customer_id}."),
    ReasonSpec("ORDER_CLOSED", R, "Payment for an order that was already expired or cancelled; payment is a refund due",
               "Refund the payment when the customer calls.",
               "Order {order_code} was already cancelled, so we could not use this payment. It will be refunded: "
               "please contact our hotline {hotline} with your customer ID {customer_id}."),
    ReasonSpec("ORDER_EXPIRED", R, "No transfer or slip within the payment window; order expired",
               "Nothing, unless the customer calls with a slip.",
               "Order {order_code} has been cancelled because we did not receive payment in time. If you have "
               "already paid, please send the slip here or contact our hotline {hotline} with your customer ID "
               "{customer_id}."),
    ReasonSpec("ORDER_CANCELLED_BALANCE", R, "Balance not paid within the balance window; order cancelled, paid amount is a refund due",
               "Refund the amount already paid when the customer calls.",
               "Order {order_code} has been cancelled because the remaining balance of {balance} was not paid in "
               "time. The {amount} you paid will be refunded: please contact our hotline {hotline} with your "
               "customer ID {customer_id}."),
    ReasonSpec("DUPLICATE_SUBMISSION", NV, "Same slip / same transaction already submitted for this order",
               "Nothing to do; previous decision stands.",
               "We have already received this payment slip for order {order_code}. There is no need to send it again."),
    ReasonSpec("UNREADABLE_SLIP", NV, "Amount or transaction time could not be read reliably",
               "Read the slip manually and correct the fields, or ask for a clearer slip.",
               _MSG_UNCLEAR),
    ReasonSpec("INCOMPLETE_SLIP", NV, "Receiving account not visible on an online-transfer slip (cropped?)",
               "Ask for the complete slip, or read the account manually.",
               "Please send a photo or screenshot of the complete payment slip, including the account number it was paid to."),
    ReasonSpec("WRONG_ACCOUNT", R, "Slip shows a receiving account that is not one of the business accounts",
               "Do not accept. Customer should pay to the correct account.",
               "This payment does not appear to have been made to our account. Please check the account details "
               "we sent you and send the correct payment slip."),
    ReasonSpec("ACCOUNT_UNCERTAIN", NV, "Receiving account read with low confidence and does not match a business account",
               "Check the receiving account on the image.", _MSG_UNDER_REVIEW),
    ReasonSpec("ALREADY_USED", R, "This transaction was already used for another customer's order",
               "Do not accept. Review the earlier order that used this payment.",
               "This payment appears to have already been used for another order. Please send the correct payment slip."),
    ReasonSpec("CLAIM_CONTESTED", NV, "The matching bank SMS is on hold for another submission under review",
               "Review both submissions together and decide who paid.", _MSG_UNDER_REVIEW),
    ReasonSpec("SAME_CUSTOMER_OTHER_ORDER", NV, "Same transaction already submitted by this customer for a different order",
               "Confirm with the customer which order this payment is for.", _MSG_UNDER_REVIEW),
    ReasonSpec("REFERENCE_REUSED_DIFFERENT_DETAILS", NV,
               "Bank reference seen before with a different amount or time: likely edited slip",
               "Compare with the earlier slip; treat as suspected fraud.", _MSG_UNDER_REVIEW),
    ReasonSpec("OLD_PAYMENT", R, "Transaction happened before this order was created",
               "Do not accept. Ask for the payment made for this order.",
               "This payment slip appears to be from before your order was placed. Please send the slip for the "
               "payment made for order {order_code}."),
    ReasonSpec("OLD_PAYMENT_UNCONFIRMED", NV,
               "Slip date is before the order, but only one date on the slip was readable (could be an OCR misread)",
               "Check the date on the image. Reject as old payment if it really is before the order.",
               _MSG_UNDER_REVIEW),
    ReasonSpec("PAID_BEFORE_ORDER_GRACE", NV, "Transaction a few minutes before order creation (within grace window)",
               "Check the chat: were bank details sent before the order was recorded?", _MSG_UNDER_REVIEW),
    ReasonSpec("FUTURE_DATED", NV, "Slip time is in the future: impossible, possibly edited or misread",
               "Check the date/time on the image.", _MSG_UNDER_REVIEW),
    ReasonSpec("NOT_COMPLETED", NV, "Slip status is not Completed (pending/scheduled/failed transfer)",
               "Wait for the bank SMS; do not accept on this slip alone.",
               "Your transfer does not appear to be completed yet. Once the bank completes it, please send the final "
               "confirmation slip."),
    ReasonSpec("AMBIGUOUS_MATCH", NV, "More than one bank credit fits this amount and time",
               "Pick the correct bank SMS manually (see candidates) or ask the customer for more detail.",
               _MSG_UNDER_REVIEW),
    ReasonSpec("SMS_CONFLICT", NV, "Bank SMS exists near this slip but time/date/amount disagree",
               "Compare the slip with the SMS candidates; possible edited slip.", _MSG_UNDER_REVIEW),
    ReasonSpec("WAITING_FOR_SMS", NV, "No matching bank SMS yet",
               "Nothing yet; the system re-checks automatically when SMS arrive.", _MSG_WAITING),
    ReasonSpec("WAITING_FOR_SMS_EXPIRED", NV, "Still no matching bank SMS after the waiting period",
               "Check the bank account / app manually for this credit.", _MSG_WAITING),
    ReasonSpec("SMS_FEED_STALE", NV, "No SMS received from the business phone recently: feed may be down",
               "Check the SMS forwarder on the business phone.", _MSG_WAITING),
    ReasonSpec("SUSPICIOUS", NV, "Bank SMS matches but the slip has suspicious indicators",
               "Review the indicators before accepting. The bank SMS is on hold for this submission.",
               _MSG_UNDER_REVIEW),
    ReasonSpec("LOW_CONFIDENCE", NV, "Bank SMS matches but extraction confidence is too low for auto-approval",
               "Confirm the fields on the image and approve if correct.", _MSG_UNDER_REVIEW),
    ReasonSpec("ORDER_ALREADY_PAID", NV, "Verified payment for an order that is already fully paid; held as customer credit",
               "Decide whether to refund or keep as credit.",
               "Order {order_code} is already fully paid, so this extra payment will be refunded: please contact "
               "our hotline {hotline} with your customer ID {customer_id}."),
    ReasonSpec("MANUAL_APPROVED", A, "Approved manually by staff", "None.",
               "Thank you! We have received your payment of {amount} for order {order_code}."),
    ReasonSpec("MANUAL_REJECTED", R, "Rejected manually by staff", "None.",
               "We couldn't accept this payment for order {order_code}. Please contact us for help."),
    ReasonSpec("NEW_SLIP_REQUESTED", NV, "Staff asked the customer for a new slip", "Wait for the new slip.",
               "Please send a clear photo or screenshot of the complete payment slip for order {order_code}."),
]

REASONS: dict[str, ReasonSpec] = {s.code: s for s in _SPECS}


SAFE_PARAMS = ("order_code", "amount", "balance", "excess", "customer_id", "hotline", "deadline_clause")


def customer_message(code: str, **params) -> str:
    spec = REASONS[code]
    safe = {k: params.get(k, "") for k in SAFE_PARAMS}
    if not safe["hotline"]:
        safe["hotline"] = "our hotline"
    return spec.customer_message.format(**safe).replace("our hotline our hotline", "our hotline")
