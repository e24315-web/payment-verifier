"""Authentication of the SMS-forwarder webhook (defence against fake-SMS injection).

A forged "credit" SMS is the most dangerous input in this system: the SMS is the source of truth. Layers:
  1. HMAC-SHA256 over timestamp + raw body with a shared secret, 5-minute replay window  (strong)
     or a static per-device token for off-the-shelf forwarder apps                      (weaker, documented)
  2. device id must be registered
  3. SMS sender id must be on the bank allowlist (a customer texting the business phone is not a bank)
Manual paste and CSV upload are staff actions behind staff auth and are marked source='manual'/'csv'.
"""
from __future__ import annotations

import hashlib
import hmac
import time
from dataclasses import dataclass

from app.settings import Settings


@dataclass
class SmsAuthResult:
    ok: bool
    status: int
    reason: str
    device_id: str = ""


def verify_sms_webhook(settings: Settings, raw_body: bytes, headers: dict, sender: str | None,
                       now_epoch: float | None = None, allowlist: list[str] | None = None) -> SmsAuthResult:
    """allowlist: sender IDs configured per bank account in the UI (plus PV_SMS_SENDER_ALLOWLIST)."""
    h = {k.lower(): v for k, v in headers.items()}
    device = h.get("x-device-id", "")
    now_epoch = time.time() if now_epoch is None else now_epoch

    if settings.sms_hmac_secret and h.get("x-signature"):
        ts = h.get("x-timestamp", "")
        try:
            skew = abs(now_epoch - float(ts))
        except ValueError:
            return SmsAuthResult(False, 401, "bad timestamp")
        if skew > settings.sms_max_clock_skew_s:
            return SmsAuthResult(False, 401, "timestamp outside replay window")
        expected = hmac.new(settings.sms_hmac_secret.encode(), f"{ts}.".encode() + raw_body, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, h["x-signature"]):
            return SmsAuthResult(False, 401, "bad signature")
        mode = "hmac"
    elif settings.sms_device_tokens:
        token = settings.sms_device_tokens.get(device)
        if not token or not hmac.compare_digest(token, h.get("x-device-token", "")):
            return SmsAuthResult(False, 401, "unknown device or bad token")
        mode = "token"
    else:
        return SmsAuthResult(False, 503, "SMS webhook not configured (set PV_SMS_HMAC_SECRET or PV_SMS_DEVICE_TOKENS)")

    if settings.sms_device_tokens and device not in settings.sms_device_tokens:
        return SmsAuthResult(False, 403, "device not registered")
    allowed = [a.upper().replace(" ", "").replace("-", "").lstrip("+")
               for a in list(settings.sms_sender_allowlist) + list(allowlist or [])]
    if allowed:
        s = (sender or "").upper().replace(" ", "").replace("-", "").lstrip("+")
        if s not in allowed:
            return SmsAuthResult(False, 403, f"sender '{sender}' is not a configured bank SMS sender")
    return SmsAuthResult(True, 200, mode, device)


def sign(secret: str, ts: str, raw_body: bytes) -> str:
    """Helper for the forwarder script / tests."""
    return hmac.new(secret.encode(), f"{ts}.".encode() + raw_body, hashlib.sha256).hexdigest()
