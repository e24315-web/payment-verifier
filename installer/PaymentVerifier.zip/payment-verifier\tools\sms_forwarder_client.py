"""Reference client for the signed SMS webhook (what a forwarder script on the business phone does).

HMAC mode (strongest; for Tasker / MacroDroid / Termux scripts that can compute a signature):
    PV_SMS_HMAC_SECRET=... python tools/sms_forwarder_client.py --sender COMBANK --device phone-1 \
        --body "Credit for Rs. 5,000.00 to 8026328795 at 16:18 at DIGITAL BANKING DIVISION"

Token mode (off-the-shelf "SMS forwarder" apps that can only add a fixed header): send the header
    X-Device-Id: <id>      X-Device-Token: <token>
with JSON {"sender": "<bank sender id>", "body": "<sms text>", "received_at": "<ISO time or epoch ms>"}
to POST /webhooks/sms. The server must have PV_SMS_DEVICE_TOKENS="<id>:<token>".
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
import time
from datetime import datetime, timezone

import httpx


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://127.0.0.1:8000/webhooks/sms")
    ap.add_argument("--sender", required=True, help="bank SMS sender id exactly as on the phone, e.g. COMBANK")
    ap.add_argument("--device", default="phone-1")
    ap.add_argument("--body", required=True)
    ap.add_argument("--received-at", default=None, help="ISO time; default now")
    args = ap.parse_args()
    secret = os.environ["PV_SMS_HMAC_SECRET"]
    raw = json.dumps({"sender": args.sender, "body": args.body,
                      "received_at": args.received_at or datetime.now(timezone.utc).isoformat()}).encode()
    ts = str(int(time.time()))
    sig = hmac.new(secret.encode(), f"{ts}.".encode() + raw, hashlib.sha256).hexdigest()
    r = httpx.post(args.url, content=raw, headers={"Content-Type": "application/json", "X-Device-Id": args.device,
                                                    "X-Timestamp": ts, "X-Signature": sig})
    print(r.status_code, r.text)


if __name__ == "__main__":
    main()
