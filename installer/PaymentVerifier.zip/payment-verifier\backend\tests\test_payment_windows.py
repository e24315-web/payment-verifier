"""The owner's payment-time rules (10 min to pay; 10 more min to pay a balance; refunds via customer ID + hotline)."""
from app.clock import lk
from app.services.actions import record_refund, refund_summary
from app.services.jobs import tick
from tests.fixtures import samples as S

T = lk(2026, 9, 26, 16, 18)          # fixture A transfer time


def setup(world, amount=5000, created=lk(2026, 9, 26, 16, 10)):
    world.windows(10, 10, hotline="0112345678")
    world.clock.set(lk(2026, 9, 26, 16, 20))
    o = world.order("Rizan", amount, created)             # expires 16:20
    world.sms(S.SMS_A, lk(2026, 9, 26, 16, 18, 40))
    return o


def test_paid_within_window_approved(world):
    o = setup(world)
    r = world.submit(o, world.slip(S.COMBANK_ERECEIPT))
    assert (r.outcome, r.reason) == ("APPROVED", "APPROVED_PAID")


def test_transfer_after_window_rejected_order_expired_refund_due(world):
    o = setup(world, created=lk(2026, 9, 26, 16, 0))      # expired 16:10, transfer 16:18
    r = world.submit(o, world.slip(S.COMBANK_ERECEIPT))
    assert (r.outcome, r.reason) == ("REJECTED", "LATE_PAYMENT")
    assert world.refresh(o).status == "EXPIRED"
    msg = world.outbox()[-1].body
    assert "C0000" in msg and "0112345678" in msg and "refunded" in msg
    rs = refund_summary(world.s, o.customer_id)
    assert rs["outstanding_cents"] == 500000
    assert [c.kind for c in world.claims()] == ["UNAPPLIED_CREDIT"]      # SMS consumed: cannot be reused elsewhere


def test_slip_sent_late_but_transfer_inside_window_is_fine(world):
    o = setup(world)
    world.clock.set(lk(2026, 9, 26, 16, 45))                  # slip sent 25 minutes after the deadline
    r = world.submit(o, world.slip(S.COMBANK_ERECEIPT))
    assert r.outcome == "APPROVED"


def test_underpaid_gets_balance_window_then_pays_in_time(world):
    o = setup(world, amount=8000)
    r1 = world.submit(o, world.slip(S.COMBANK_ERECEIPT))
    assert r1.reason == "APPROVED_UNDERPAID"
    assert world.refresh(o).balance_due_by is not None
    msg = world.outbox()[-1].body
    assert "within 10 minutes" in msg and "Rs. 3,000.00" in msg and "cancelled" in msg
    world.clock.set(lk(2026, 9, 26, 16, 26))
    world.sms(S.combank_sms("3,000.00", "16:25"), lk(2026, 9, 26, 16, 25, 30))
    r2 = world.submit(o, world.slip(S.COMBANK_ERECEIPT, amount_cents=300000, txn_at=lk(2026, 9, 26, 16, 25),
                                    reference="O600066100002", generated_at=lk(2026, 9, 26, 16, 25)))
    assert (r2.outcome, r2.reason) == ("APPROVED", "APPROVED_PAID")
    assert world.refresh(o).status == "PAID"


def test_underpaid_balance_not_paid_in_time_order_cancelled_and_refund_due(world):
    o = setup(world, amount=8000)
    world.submit(o, world.slip(S.COMBANK_ERECEIPT))           # 5,000 of 8,000; balance due by 16:30
    world.clock.set(lk(2026, 9, 26, 16, 31))
    res = tick(world.s, world.clock, world.cfg)
    assert o.id in res["cancelled_orders"]
    assert world.refresh(o).status == "CANCELLED"
    msg = world.outbox()[-1].body
    assert "cancelled" in msg and "Rs. 5,000.00" in msg and "C0000" in msg and "0112345678" in msg
    assert refund_summary(world.s, o.customer_id)["outstanding_cents"] == 500000


def test_balance_transferred_too_late_is_refund_and_order_cancelled(world):
    o = setup(world, amount=8000)
    world.submit(o, world.slip(S.COMBANK_ERECEIPT))
    world.clock.set(lk(2026, 9, 26, 16, 36))
    world.sms(S.combank_sms("3,000.00", "16:35"), lk(2026, 9, 26, 16, 35, 30))
    r = world.submit(o, world.slip(S.COMBANK_ERECEIPT, amount_cents=300000, txn_at=lk(2026, 9, 26, 16, 35),
                                   reference="O600066100003", generated_at=lk(2026, 9, 26, 16, 35)))
    assert (r.outcome, r.reason) == ("REJECTED", "LATE_PAYMENT")
    assert world.refresh(o).status == "CANCELLED"
    assert refund_summary(world.s, o.customer_id)["outstanding_cents"] == 800000     # both payments go back


def test_overpaid_message_has_customer_id_and_hotline(world):
    o = setup(world, amount=4000)
    r = world.submit(o, world.slip(S.COMBANK_ERECEIPT))
    assert r.reason == "APPROVED_OVERPAID"
    msg = world.outbox()[-1].body
    assert "Rs. 1,000.00 more" in msg and "C0000" in msg and "0112345678" in msg
    assert refund_summary(world.s, o.customer_id)["outstanding_cents"] == 100000


def test_no_slip_within_window_order_expires_with_message(world):
    world.windows(10, 10)
    world.clock.set(lk(2026, 9, 26, 16, 0))
    o = world.order("Rizan", 5000, world.clock.now())
    world.clock.set(lk(2026, 9, 26, 16, 9))
    assert tick(world.s, world.clock, world.cfg)["expired_orders"] == []
    world.clock.set(lk(2026, 9, 26, 16, 11))
    assert tick(world.s, world.clock, world.cfg)["expired_orders"] == [o.id]
    assert world.refresh(o).status == "EXPIRED"
    assert "did not receive payment in time" in world.outbox()[-1].body


def test_slip_received_in_window_keeps_order_open_while_verifying(world):
    world.windows(10, 10)
    world.clock.set(lk(2026, 9, 26, 16, 10))
    o = world.order("Rizan", 5000, world.clock.now())
    world.sms(S.combank_sms("1,000.00", "15:00"), lk(2026, 9, 26, 15, 0, 20))    # feed alive
    world.clock.set(lk(2026, 9, 26, 16, 19))
    r = world.submit(o, world.slip(S.COMBANK_ERECEIPT))                     # SMS not in yet
    assert r.reason == "WAITING_FOR_SMS"
    world.clock.set(lk(2026, 9, 26, 16, 25))
    assert tick(world.s, world.clock, world.cfg)["expired_orders"] == []    # not expired: slip is being verified
    world.sms(S.SMS_A, lk(2026, 9, 26, 16, 24, 50))                          # late SMS for a 16:18 transfer
    assert world.refresh(r.submission).outcome == "APPROVED"


def test_payment_for_already_expired_order_is_refund(world):
    world.windows(10, 10)
    world.clock.set(lk(2026, 9, 26, 16, 0))
    o = world.order("Rizan", 5000, world.clock.now())
    world.clock.set(lk(2026, 9, 26, 16, 11))
    tick(world.s, world.clock, world.cfg)
    world.clock.set(lk(2026, 9, 26, 16, 20))
    world.sms(S.SMS_A, lk(2026, 9, 26, 16, 18, 40))
    r = world.submit(o, world.slip(S.COMBANK_ERECEIPT))
    assert r.outcome == "REJECTED" and r.reason in ("ORDER_CLOSED", "LATE_PAYMENT")
    assert refund_summary(world.s, o.customer_id)["outstanding_cents"] == 500000


def test_recording_a_refund_reduces_outstanding(world):
    o = setup(world, amount=4000)
    world.submit(o, world.slip(S.COMBANK_ERECEIPT))
    record_refund(world.s, world.clock, o.customer_id, 100000, "staff:test", "refunded by bank transfer")
    assert refund_summary(world.s, o.customer_id)["outstanding_cents"] == 0
    import pytest
    from app.services.actions import ActionError
    with pytest.raises(ActionError):
        record_refund(world.s, world.clock, o.customer_id, 1, "staff:test", "too much")
