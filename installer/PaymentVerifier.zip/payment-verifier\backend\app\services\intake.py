"""Slip image intake: idempotency -> exact-duplicate cache -> tiered extraction -> submission -> decision."""
from __future__ import annotations

from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.clock import Clock
from app.config import RulesConfig
from app.db.models import ImageCache, Order, Submission
from app.domain.decision import Decision
from app.domain.types import Flag, Severity, SlipExtraction
from app.imaging.extraction import SlipExtractor
from app.imaging.images import phash_distance, sha256_bytes
from app.services.verification import create_submission

NEAR_IDENTICAL_PHASH = 4   # of 64 bits. Different receipts of one bank share a layout, so keep this tight.


def extract_with_cache(session: Session, data: bytes, extractor: SlipExtractor, clock: Clock) -> tuple[SlipExtraction, dict]:
    sha = sha256_bytes(data)
    cached = session.get(ImageCache, sha)
    if cached is not None:
        cached.hits += 1
        rep = dict(cached.report)
        meta = {k: v for k, v in rep.items() if k != "extraction"}
        meta.update({"tier": "CACHE", "cache_of_tier": rep.get("tier"), "latency_ms": 0, "cost_usd": 0.0,
                     "attempts": []})
        return SlipExtraction.from_dict(rep["extraction"]), meta
    report = extractor.extract_bytes(data)
    rep = report.to_dict()
    session.add(ImageCache(sha256=sha, phash=report.phash, report=rep, created_at=clock.now()))
    return report.extraction, {k: v for k, v in rep.items() if k != "extraction"}


def _near_identical_flags(session: Session, phash: str | None, customer_id: int) -> list[Flag]:
    if not phash:
        return []
    rows = session.execute(select(Submission.id, Submission.image_phash, Submission.customer_id)
                           .where(Submission.image_phash.is_not(None))
                           .order_by(Submission.id.desc()).limit(5000)).all()
    hits = [sid for sid, ph, cid in rows if cid != customer_id and (phash_distance(phash, ph) or 99) <= NEAR_IDENTICAL_PHASH]
    if not hits:
        return []
    # LOW: informative for staff; the canonical-transaction check is what actually catches reuse.
    return [Flag("NEAR_IDENTICAL_IMAGE", Severity.LOW,
                 f"image is visually near-identical to another customer's submission(s) {hits[:5]}")]


def submit_slip_image(session: Session, order_id: int, data: bytes, extractor: SlipExtractor, clock: Clock,
                      cfg: RulesConfig, channel_message_id: str | None = None,
                      upload_dir: str | Path | None = None,
                      pre_extracted: tuple[SlipExtraction, dict] | None = None) -> tuple[Submission, Decision | None]:
    """pre_extracted: pass the result if the caller already extracted this image (e.g. for order routing),
    otherwise the second lookup would hit the cache and the real tier/latency/cost would be lost."""
    if channel_message_id:
        existing = session.scalar(select(Submission).where(Submission.channel_message_id == channel_message_id))
        if existing:
            return existing, None
    extraction, meta = pre_extracted or extract_with_cache(session, data, extractor, clock)
    sha = sha256_bytes(data)
    order = session.get(Order, order_id)
    extraction.flags.extend(_near_identical_flags(session, meta.get("phash"), order.customer_id))
    path = None
    if upload_dir:
        p = Path(upload_dir)
        p.mkdir(parents=True, exist_ok=True)
        path = p / f"{sha}.jpg"
        if not path.exists():
            path.write_bytes(data)
    return create_submission(session, order_id, extraction, clock, cfg, image_sha256=sha, image_phash=meta.get("phash"),
                             image_path=str(path) if path else None, channel_message_id=channel_message_id,
                             extraction_meta=meta)
