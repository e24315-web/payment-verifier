"""Seed a live demo through the real HTTP API (real OCR, real decisions). See docs/DEMO_SCRIPT.md.

Start the server with the demo clock first (so the real 26/09/2026 slips are "now"):
    cd backend
    python run.py --reset --demo-start 2026-09-26T16:17:00
then, in another terminal:
    python tools/demo_seed.py
"""
from __future__ import annotations

import sys
from pathlib import Path

import httpx

B = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8000"
ROOT = Path(__file__).resolve().parent.parent
REAL = ROOT / "backend" / "tests" / "fixtures" / "images"
TEST = ROOT / "frontend" / "public" / "samples" / "test"
c = httpx.Client(base_url=B, timeout=180, headers={"X-Staff-Name": "Demo"})


def combank(amount: str, hhmm: str) -> str:
    return f"Credit for Rs. {amount} to 8026328795 at {hhmm} at DIGITAL BANKING DIVISION"


def sms(body: str, received: str, sender="COMBANK"):
    return c.post("/api/sms/simulate", json={"body": body, "sender": sender, "received_at": received}).json()


def order(name: str, phone: str, amount: str) -> dict:
    return c.post("/api/orders", json={"customer_name": name, "phone": phone, "amount": amount,
                                       "account_id": ACC["Commercial Bank"]["id"]}).json()


def slip(phone: str, path: Path, caption: str | None = None) -> dict:
    data = {"phone": phone, **({"caption": caption} if caption else {})}
    r = c.post("/api/whatsapp/simulate", data=data, files={"image": (path.name, path.read_bytes(), "image/jpeg")}).json()
    return r


def show(label: str, r: dict):
    d = c.get(f"/api/submissions/{r['submission_id']}").json()["system_concluded"] if r.get("submission_id") else {}
    print(f"{label:<44} -> {d.get('outcome', '-'):<19} {d.get('reason_code', r.get('reply'))}")


# ---------------------------------------------------------------- setup (what the owner does once in Settings)
biz = c.get("/api/business").json()
ACC = {a["bank"]: a for a in biz["accounts"]}
for bank, sender in (("Commercial Bank", "COMBANK"), ("People's Bank", "PEOPLESBANK")):
    a = ACC[bank]
    c.patch(f"/api/accounts/{a['id']}", json={"bank": a["bank"], "account": a["account"],
                                               "holder_names": a["holder_names"], "sms_senders": [sender]})
c.put("/api/business", json={"name": "Rasool Stores", "whatsapp_number": "+94770000000", "hotline": "011 234 5678",
                             "payment_window_min": 10, "balance_window_min": 10})
# An earlier, unrelated credit: a live system's SMS feed is never empty (otherwise case 1 says "feed stale").
sms(combank("1,250.00", "15:02"), "2026-09-26T15:02:30+05:30")
print("clock:", c.get("/api/health").json()["now"])

# 1. VALID: slip arrives first, bank SMS two minutes later -> auto re-check -> approved
order("Mohamed Rizan", "0771234567", "5,000")
r1 = slip("0771234567", REAL / "combank_ereceipt.jpeg")
show("1a valid slip, SMS not in yet", r1)
sms(combank("5,000.00", "16:18"), "2026-09-26T16:18:40+05:30")
show("1b ... bank SMS arrives", r1)

# 2. REUSED: another customer forwards the same receipt
order("Kasun Perera", "0712222222", "5,000")
show("2  same receipt, another customer", slip("0712222222", REAL / "combank_ereceipt.jpeg"))

# 3. WRONG AMOUNT (underpaid): 3,000 of 8,000 -> balance window starts
order("Nimal Perera", "0713333333", "8,000")
sms(combank("3,000.00", "16:19"), "2026-09-26T16:19:30+05:30")
show("3  underpaid 3,000 of 8,000", slip("0713333333", TEST / "underpaid_3000_0419pm.jpg"))

# 4. SUSPICIOUS: slip says 20,000; the bank credited 2,000 in that minute
order("Saman Silva", "0714444444", "20,000")
sms(combank("2,000.00", "16:20"), "2026-09-26T16:20:25+05:30")
show("4  edited amount (slip 20,000, bank 2,000)", slip("0714444444", TEST / "edited_amount_20000_0420pm.jpg"))

# 5. UNCLEAR: blurred photo
order("Dilani Fernando", "0715555555", "5,000")
show("5  blurred slip", slip("0715555555", TEST / "unclear_5000_0420pm.jpg"))

# 6. INSUFFICIENT EVIDENCE: good slip, no bank SMS (deliver it live later in the simulator)
order("Priya Raj", "0716666666", "4,000")
show("6  no bank SMS yet", slip("0716666666", TEST / "no_sms_4000_0421pm.jpg"))

# 7. OLD PAYMENT: the real month-old People's Bank cash slip
sms("Dear Sir/Madam, Your A/C 065-2002****90 has been Credited by Rs. 7500.00(Cash Depo. @13:44 28/08/2026)."
    "[Av_Bal: Rs. 36222.13 at SMS generated]", "2026-08-28T13:44:55+05:30", sender="PEOPLESBANK")
order("Athayea Rasool", "0717777777", "7,500")
show("7  month-old cash deposit slip", slip("0717777777", REAL / "peoples_deposit.jpeg"))

# 8. OVERPAID: 1,800 for a 1,500 order -> refund of 300 via customer ID + hotline
#    (not 2,000: a second Rs 2,000 credit one minute after Saman's would correctly be AMBIGUOUS_MATCH)
order("Ruwan Dias", "0718888888", "1,500")
sms(combank("1,800.00", "16:21"), "2026-09-26T16:21:20+05:30")
show("8  overpaid 1,800 for 1,500", slip("0718888888", TEST / "overpaid_1800_0421pm.jpg"))

print("\nOpen", B, "- queue shows needs-action items first. Live steps: docs/DEMO_SCRIPT.md")
