"""The decision table. Pure function: DecisionInput -> Decision. No I/O.

Rows are evaluated strictly in order; the first row that fires decides. APPROVED is only reachable at
the very end, after every blocking row has been passed.

 #  Row                          Outcome
 1  duplicate for this order     prior outcome (DUPLICATE_SUBMISSION)
 2  unreadable / incomplete      NEEDS_VERIFICATION
 3  wrong receiving account      REJECTED (high conf) / NEEDS_VERIFICATION (low conf)
 4  reuse across orders          REJECTED ALREADY_USED / NV variants
 5  time sanity vs order/now     REJECTED OLD_PAYMENT / NV (grace, future)
 6  status not completed         NEEDS_VERIFICATION
 7  SMS match not strong         NEEDS_VERIFICATION (ambiguous / conflict / waiting / feed stale)
 8  suspicious flags             NEEDS_VERIFICATION (SMS put on HOLD for this submission)
 9  low overall confidence       NEEDS_VERIFICATION (HOLD)
10  amount vs balance due        APPROVED (paid / underpaid / overpaid) or NV ORDER_ALREADY_PAID
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta

from app.clock import LK_TZ
from app.config import RulesConfig
from app.domain.matching import FINAL_CLAIMS, MatchResult, MatchStatus
from app.domain.normalize import accounts_compatible, format_rs, minute_floor, name_similarity
from app.domain.reasons import REASONS, customer_message
from app.domain.types import Flag, Outcome, Severity, SlipExtraction, SlipType


@dataclass
class OrderView:
    id: int
    code: str
    customer_id: int
    expected_cents: int
    paid_cents: int
    created_at: datetime
    pay_to_account_id: int | None = None
    status: str = "AWAITING_PAYMENT"
    expires_at: datetime | None = None
    balance_due_by: datetime | None = None
    customer_code: str = ""


@dataclass
class AccountView:
    id: int
    bank: str
    account: str           # full number or mask
    holder_names: list[str]


@dataclass
class PriorSubmission:
    submission_id: int
    order_id: int
    customer_id: int
    outcome: str | None
    reason_code: str | None
    kind: str               # IMAGE | CANONICAL | REFERENCE
    same_details: bool      # same amount AND same minute


@dataclass
class DecisionInput:
    now: datetime
    cfg: RulesConfig
    order: OrderView
    slip: SlipExtraction
    business_accounts: list[AccountView]
    match: MatchResult | None
    same_order_prior: PriorSubmission | None = None
    cross_order_priors: list[PriorSubmission] = field(default_factory=list)
    feed_stale: bool = False
    waited_too_long: bool = False
    known_sender_accounts: list[str] = field(default_factory=list)
    extra_flags: list[Flag] = field(default_factory=list)
    hotline: str = ""
    balance_window_min: int | None = None


@dataclass
class ClaimIntent:
    kind: str               # HOLD | ORDER_PAYMENT | UNAPPLIED_CREDIT
    sms_id: int
    applied_cents: int = 0
    excess_cents: int = 0


@dataclass
class Decision:
    outcome: Outcome
    reason_code: str
    confidence: float
    reasons: list[str]
    flags: list[Flag]
    next_action: str
    customer_message: str
    claim: ClaimIntent | None = None
    duplicate_of: int | None = None
    contest_submission_ids: list[int] = field(default_factory=list)
    related_submission_ids: list[int] = field(default_factory=list)
    new_paid_cents: int | None = None
    close_order: str | None = None            # EXPIRED | CANCELLED
    balance_due_by: datetime | None = None    # set after an underpayment

    def to_dict(self) -> dict:
        return {
            "outcome": self.outcome.value,
            "reason_code": self.reason_code,
            "confidence": round(self.confidence, 3),
            "reasons": self.reasons,
            "flags": [f.to_dict() for f in self.flags],
            "next_action": self.next_action,
            "customer_message": self.customer_message,
            "claim": vars(self.claim) if self.claim else None,
            "duplicate_of": self.duplicate_of,
            "contest_submission_ids": self.contest_submission_ids,
            "related_submission_ids": self.related_submission_ids,
        }


# Earlier results on the same order that a NEW slip can resolve (clearer photo, completed transfer, full
# screenshot). A resubmission after one of these is evaluated fresh instead of being treated as a duplicate.
SUPERSEDABLE = {"UNREADABLE_SLIP", "INCOMPLETE_SLIP", "NOT_COMPLETED", "ACCOUNT_UNCERTAIN", "NEW_SLIP_REQUESTED"}


def _blocking(flags: list[Flag]) -> list[Flag]:
    return [f for f in flags if f.severity in (Severity.MEDIUM, Severity.HIGH)]


def compatible_accounts(slip: SlipExtraction, accounts: list[AccountView]) -> list[AccountView]:
    acc = slip.get("receiving_account")
    return [a for a in accounts if accounts_compatible(acc, a.account)] if acc else []


def decide(inp: DecisionInput) -> Decision:
    slip, order, cfg = inp.slip, inp.order, inp.cfg
    flags: list[Flag] = list(slip.flags) + list(inp.extra_flags)
    reasons: list[str] = []
    amount = slip.get("amount_cents")
    txn_at: datetime | None = slip.get("txn_at")
    params = {"order_code": order.code, "amount": format_rs(amount) if amount else "",
              "customer_id": order.customer_code, "hotline": inp.hotline}

    def done(code: str, confidence: float, outcome: Outcome | None = None, **kw) -> Decision:
        spec = REASONS[code]
        msg_params = {**params, **kw.pop("msg_params", {})}
        return Decision(
            outcome=outcome or spec.outcome, reason_code=code, confidence=max(0.0, min(1.0, confidence)),
            reasons=reasons + [spec.title], flags=flags, next_action=spec.next_action,
            customer_message=customer_message(code, **msg_params), **kw,
        )

    online = slip.slip_type != SlipType.CASH_DEPOSIT
    field_conf = min(slip.conf("amount_cents"), slip.conf("txn_at"))
    if online:
        field_conf = min(field_conf, slip.conf("receiving_account"))

    # 1. Duplicate of an earlier submission for THIS order: return the earlier decision, no reprocessing.
    if p := inp.same_order_prior:
        reasons.append(f"Same {p.kind.lower()} as submission #{p.submission_id} for this order")
        prior_outcome = Outcome(p.outcome) if p.outcome else Outcome.NEEDS_VERIFICATION
        return done("DUPLICATE_SUBMISSION", 1.0, outcome=prior_outcome, duplicate_of=p.submission_id)

    # 2. Readability. Time is the confirmation key, so it has the strictest threshold.
    unknown_layout = slip.template == "generic"
    if unknown_layout:
        reasons.append(f"Slip layout not recognised ({slip.get('bank') or 'unknown bank'}): no template for this "
                       f"bank, so a person must confirm the values")
    if slip.slip_type == SlipType.CASH_DEPOSIT and any(f.code == "NO_TELLER_VALIDATION" for f in flags):
        reasons.append("Cash slip without a machine-printed teller stamp: every value is customer-written")
    if amount is None or slip.conf("amount_cents") < cfg.min_amount_conf:
        if amount is None:
            reasons.append("Amount not found on the slip")
        else:
            reasons.append(f"Amount read as {format_rs(amount)} but confidence {slip.conf('amount_cents'):.2f} is "
                           f"below {cfg.min_amount_conf:.2f}")
        return done("UNREADABLE_SLIP", slip.conf("amount_cents"))
    if txn_at is None or slip.conf("txn_at") < cfg.min_time_conf:
        if txn_at is None and slip.get("txn_date"):
            reasons.append(f"Slip shows only a date ({slip.get('txn_date')}), no transaction time: the time is "
                           f"needed to match the bank SMS")
        elif txn_at is None:
            reasons.append("Transaction date/time not found on the slip")
        else:
            reasons.append(f"Transaction time read as {txn_at:%d/%m/%Y %H:%M} but confidence "
                           f"{slip.conf('txn_at'):.2f} is below {cfg.min_time_conf:.2f}")
        return done("UNREADABLE_SLIP", slip.conf("txn_at"))
    if online and slip.get("receiving_account") is None:
        reasons.append("Online transfer slip without a readable receiving account")
        return done("INCOMPLETE_SLIP", 0.5)

    # 3. Receiving account (only checkable on online transfers; cash slips carry handwritten accounts).
    matched_accounts = compatible_accounts(slip, inp.business_accounts)
    if online and not matched_accounts:
        acc_conf = slip.conf("receiving_account")
        reasons.append(f"Receiving account {slip.get('receiving_account')} is not a business account")
        if acc_conf >= cfg.wrong_account_reject_conf:
            return done("WRONG_ACCOUNT", acc_conf)
        return done("ACCOUNT_UNCERTAIN", acc_conf)
    if online and slip.conf("receiving_account") < cfg.min_account_conf:
        reasons.append("Receiving account read with low confidence")
        return done("UNREADABLE_SLIP", slip.conf("receiving_account"))

    # 4. Reuse across orders (by canonical transaction identity / bank reference / claimed SMS).
    # A REJECTED prior did not "use" the payment (e.g. a fraudster submitted the victim's slip first and was
    # rejected as OLD_PAYMENT). It must not cause the real payer to be rejected, but it is suspicious.
    others = inp.cross_order_priors
    active = [p for p in others if p.outcome != "REJECTED"]
    other_customer_same = [p for p in active if p.same_details and p.customer_id != order.customer_id]
    same_customer_same = [p for p in active if p.same_details and p.customer_id == order.customer_id]
    ref_edited = [p for p in others if p.kind == "REFERENCE" and not p.same_details]
    rejected_elsewhere = [p for p in others if p.outcome == "REJECTED" and p.same_details
                          and p.customer_id != order.customer_id]
    if other_customer_same:
        ids = [p.submission_id for p in other_customer_same]
        approved = [p.submission_id for p in other_customer_same if p.outcome == "APPROVED"]
        if approved:
            reasons.append(f"Same transaction already accepted for another customer's order (submission {approved})")
            return done("ALREADY_USED", 0.97, related_submission_ids=ids, contest_submission_ids=approved)
        reasons.append(f"Same transaction is under review for another customer's order (submission {ids})")
        return done("CLAIM_CONTESTED", 0.5, related_submission_ids=ids)
    if rejected_elsewhere:
        ids = [p.submission_id for p in rejected_elsewhere]
        flags.append(Flag("SEEN_ON_OTHER_CUSTOMER", Severity.MEDIUM,
                          f"same transaction was previously submitted (and rejected) for another customer: {ids}"))
    if ref_edited:
        ids = [p.submission_id for p in ref_edited]
        flags.append(Flag("REFERENCE_REUSED", Severity.HIGH,
                          f"bank reference already seen on submission(s) {ids} with a different amount/time"))
        return done("REFERENCE_REUSED_DIFFERENT_DETAILS", 0.5, related_submission_ids=ids)
    if same_customer_same:
        ids = [p.submission_id for p in same_customer_same]
        reasons.append(f"This customer already submitted this transaction for another order (submission {ids})")
        return done("SAME_CUSTOMER_OTHER_ORDER", 0.6, related_submission_ids=ids)

    m = inp.match
    if m and m.status == MatchStatus.ALREADY_CLAIMED:
        holders = m.claimed_by
        final = [c for c in holders if c.claim_kind in FINAL_CLAIMS]
        if final and all(c.claim_customer_id == order.customer_id for c in final):
            reasons.append("The matching bank SMS is already applied to another order of this customer")
            return done("SAME_CUSTOMER_OTHER_ORDER", 0.6,
                        related_submission_ids=[c.claim_submission_id for c in final])
        if final:
            reasons.append("The matching bank SMS has already been claimed by another order")
            return done("ALREADY_USED", 0.95,
                        related_submission_ids=[c.claim_submission_id for c in final],
                        contest_submission_ids=[c.claim_submission_id for c in final])
        reasons.append("The matching bank SMS is on hold for another submission under review")
        return done("CLAIM_CONTESTED", 0.5, related_submission_ids=[c.claim_submission_id for c in holders])

    # 5. Time sanity against the order and against "now".
    if txn_at > inp.now + timedelta(minutes=cfg.future_tolerance_min):
        flags.append(Flag("FUTURE_DATED", Severity.HIGH, f"slip time {txn_at.isoformat()} is in the future"))
        return done("FUTURE_DATED", 0.5)
    grace = timedelta(minutes=cfg.old_payment_grace_min)
    if txn_at < order.created_at - grace:
        reasons.append(f"Transaction {txn_at:%d/%m/%Y %H:%M} is before order creation {order.created_at:%d/%m/%Y %H:%M}")
        # A hard rejection needs corroborated evidence: OCR can confidently misread a dot-matrix year
        # (2026 -> 2028/2020 seen on the real slip). Only reject if a second date on the slip agrees.
        if slip.get("date_corroborated"):
            return done("OLD_PAYMENT", slip.conf("txn_at"))
        return done("OLD_PAYMENT_UNCONFIRMED", 0.5)
    if txn_at < order.created_at:
        reasons.append("Transaction is a few minutes before the order was created")
        return done("PAID_BEFORE_ORDER_GRACE", 0.5)

    # 6. Transfer status.
    status = slip.get("status")
    if status and status != "COMPLETED":
        reasons.append(f"Slip status is '{status}'")
        return done("NOT_COMPLETED", 0.5)
    if online and not status:
        flags.append(Flag("STATUS_NOT_VISIBLE", Severity.LOW, "transfer status not visible on slip"))

    # 7. Bank SMS confirmation.
    if m is None or m.status == MatchStatus.NONE:
        if inp.feed_stale:
            return done("SMS_FEED_STALE", field_conf * 0.5)
        if inp.waited_too_long:
            return done("WAITING_FOR_SMS_EXPIRED", field_conf * 0.5)
        return done("WAITING_FOR_SMS", field_conf * 0.5)
    reasons.extend(m.notes)
    if m.status == MatchStatus.AMBIGUOUS:
        return done("AMBIGUOUS_MATCH", field_conf * 0.5)
    if m.status == MatchStatus.CONFLICT:
        flags.append(Flag("SMS_CONFLICT", Severity.MEDIUM, "; ".join(m.notes)))
        return done("SMS_CONFLICT", field_conf * 0.4)
    assert m.status == MatchStatus.STRONG and m.chosen is not None
    sms = m.chosen

    # Soft (LOW) identity signals: shown to staff, never block.
    if order.pay_to_account_id and sms.business_account_id and sms.business_account_id != order.pay_to_account_id:
        acc = next((a for a in inp.business_accounts if a.id == sms.business_account_id), None)
        flags.append(Flag("OTHER_BUSINESS_ACCOUNT", Severity.LOW,
                          f"paid into {acc.bank if acc else 'another'} business account, not the one sent to the customer"))
    if online and slip.get("sender_account") and inp.known_sender_accounts:
        if not any(accounts_compatible(slip.get("sender_account"), k) for k in inp.known_sender_accounts):
            flags.append(Flag("NEW_SENDER_ACCOUNT", Severity.LOW,
                              f"sender account {slip.get('sender_account')} not seen before for this customer"))
    ben = slip.get("beneficiary_name")
    if online and ben and matched_accounts and slip.conf("beneficiary_name") >= 0.8:
        best = max(name_similarity(ben, h) for a in matched_accounts for h in a.holder_names) \
            if any(a.holder_names for a in matched_accounts) else 1.0
        if best < 0.75:
            flags.append(Flag("BENEFICIARY_NAME_MISMATCH", Severity.LOW,
                              f"beneficiary name '{ben}' does not resemble the account holder names"))

    confidence = field_conf * m.strength

    # 8. Suspicious indicators: keep the SMS reserved for this submission while a human looks.
    if blocking := _blocking(flags):
        reasons.append("Suspicious indicators: " + ", ".join(f.code for f in blocking))
        return done("SUSPICIOUS", confidence * 0.6, claim=ClaimIntent("HOLD", sms.id))

    # 9. Confidence floor.
    if confidence < cfg.approve_min_conf:
        reasons.append(f"Overall confidence {confidence:.2f} below auto-approve threshold {cfg.approve_min_conf:.2f}")
        return done("LOW_CONFIDENCE", confidence, claim=ClaimIntent("HOLD", sms.id))

    # 10. Payment window. The money is real (SMS-confirmed), so a late payment is never lost: it is held as a
    #     refund due to the customer, and the order is closed.
    if order.status in ("EXPIRED", "CANCELLED"):
        reasons.append(f"Order is already {order.status.lower()}")
        return done("ORDER_CLOSED", confidence, claim=ClaimIntent("UNAPPLIED_CREDIT", sms.id, 0, amount))
    deadline = order.balance_due_by if order.paid_cents > 0 else order.expires_at
    if deadline is not None and minute_floor(txn_at) > minute_floor(deadline):
        late = int((minute_floor(txn_at) - minute_floor(deadline)).total_seconds() // 60)
        reasons.append(f"Transfer at {txn_at.astimezone(LK_TZ):%H:%M} is {late} min after the payment deadline "
                       f"{deadline.astimezone(LK_TZ):%H:%M}")
        return done("LATE_PAYMENT", confidence, claim=ClaimIntent("UNAPPLIED_CREDIT", sms.id, 0, amount),
                    close_order="CANCELLED" if order.paid_cents > 0 else "EXPIRED")

    # 11. Amount vs balance due. The SMS confirmed this amount arrived, so it is never lost.
    balance = order.expected_cents - order.paid_cents
    if balance <= 0:
        return done("ORDER_ALREADY_PAID", confidence,
                    claim=ClaimIntent("UNAPPLIED_CREDIT", sms.id, 0, amount),
                    msg_params={"excess": format_rs(amount)})
    if amount == balance:
        return done("APPROVED_PAID", confidence, claim=ClaimIntent("ORDER_PAYMENT", sms.id, amount, 0),
                    new_paid_cents=order.paid_cents + amount)
    if amount < balance:
        reasons.append(f"Paid {format_rs(amount)} of {format_rs(balance)} due")
        due_by = inp.now + timedelta(minutes=inp.balance_window_min) if inp.balance_window_min else None
        mp = {"balance": format_rs(balance - amount)}
        if due_by:
            mp["deadline_clause"] = (f" within {inp.balance_window_min} minutes (by {due_by.astimezone(LK_TZ):%I:%M %p}). "
                                     f"If the balance is not paid in time, the order will be cancelled and your "
                                     f"payment refunded (customer ID {order.customer_code})")
            reasons.append(f"Balance must be paid by {due_by.astimezone(LK_TZ):%H:%M}")
        return done("APPROVED_UNDERPAID", confidence,
                    claim=ClaimIntent("ORDER_PAYMENT", sms.id, amount, 0),
                    new_paid_cents=order.paid_cents + amount, balance_due_by=due_by, msg_params=mp)
    excess = amount - balance
    reasons.append(f"Paid {format_rs(amount)} against {format_rs(balance)} due; excess {format_rs(excess)}")
    return done("APPROVED_OVERPAID", confidence, claim=ClaimIntent("ORDER_PAYMENT", sms.id, balance, excess),
                new_paid_cents=order.paid_cents + balance, msg_params={"excess": format_rs(excess)})
