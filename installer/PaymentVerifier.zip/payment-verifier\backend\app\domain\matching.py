"""Slip <-> bank SMS matching. Time (to the minute) + amount + business account is the confirmation key.

Directional time rule: a bank SMS is generated at or after the transaction, never before.
    offset = SMS minute - slip minute
    0            -> EXACT      (strong)
    +1           -> LAG1       (strong, SMS lag)
    -2..+2 other -> WEAK       (not enough to approve)
    within +-conflict window -> NEAR (time conflict: possibly edited time)
    same clock time, other date (<= 7 days) -> DATE_CONFLICT (possibly edited date / old slip)

Safety rules:
    * A strong candidate is only accepted if NO other same-amount credit on the same business account lies
      within +-isolation_window of it (claimed or not). Two customers paying the same amount at nearly the
      same minute is exactly the "amount alone is not proof" case, so we hand it to a human.
    * If a strong candidate is already claimed by someone else and another is free, we do not silently take
      the free one: AMBIGUOUS.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum

from app.config import RulesConfig
from app.domain.normalize import minute_floor


class MatchStatus(str, Enum):
    STRONG = "STRONG"
    AMBIGUOUS = "AMBIGUOUS"
    CONFLICT = "CONFLICT"
    ALREADY_CLAIMED = "ALREADY_CLAIMED"
    NONE = "NONE"


FINAL_CLAIMS = {"ORDER_PAYMENT", "UNAPPLIED_CREDIT"}


@dataclass
class SmsCandidate:
    id: int
    business_account_id: int | None
    amount_cents: int | None
    txn_at: datetime | None
    parse_confidence: float = 0.95
    claim_kind: str | None = None          # None | HOLD | ORDER_PAYMENT | UNAPPLIED_CREDIT
    claim_submission_id: int | None = None
    claim_order_id: int | None = None
    claim_customer_id: int | None = None


@dataclass
class ScoredCandidate:
    sms: SmsCandidate
    offset_min: int | None
    kind: str  # EXACT | LAG1 | WEAK | NEAR | DATE_CONFLICT | AMOUNT_CONFLICT

    def to_dict(self) -> dict:
        s = self.sms
        return {
            "sms_id": s.id, "offset_min": self.offset_min, "kind": self.kind,
            "amount_cents": s.amount_cents, "txn_at": s.txn_at.isoformat() if s.txn_at else None,
            "business_account_id": s.business_account_id, "claim_kind": s.claim_kind,
            "claim_order_id": s.claim_order_id,
        }


@dataclass
class MatchResult:
    status: MatchStatus
    chosen: SmsCandidate | None = None
    offset_min: int | None = None
    strength: float = 0.0
    candidates: list[ScoredCandidate] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    claimed_by: list[SmsCandidate] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "status": self.status.value,
            "chosen_sms_id": self.chosen.id if self.chosen else None,
            "offset_min": self.offset_min,
            "strength": self.strength,
            "candidates": [c.to_dict() for c in self.candidates],
            "notes": self.notes,
        }


def _offset_minutes(sms_at: datetime, slip_at: datetime) -> int:
    delta = minute_floor(sms_at) - minute_floor(slip_at)
    return int(delta.total_seconds() // 60)


def match_slip(
    slip_amount_cents: int,
    slip_txn_at: datetime,
    candidates: list[SmsCandidate],
    cfg: RulesConfig,
    allowed_account_ids: set[int] | None = None,
    own_submission_id: int | None = None,
) -> MatchResult:
    """allowed_account_ids: business accounts the slip could have paid into (None = any business account)."""
    scored: list[ScoredCandidate] = []
    pool = [
        c for c in candidates
        if c.txn_at is not None and c.business_account_id is not None
        and (allowed_account_ids is None or c.business_account_id in allowed_account_ids)
    ]
    for c in pool:
        off = _offset_minutes(c.txn_at, slip_txn_at)
        if c.amount_cents == slip_amount_cents:
            if off == 0:
                kind = "EXACT"
            elif off == 1:
                kind = "LAG1"
            elif abs(off) <= 2:
                kind = "WEAK"
            elif abs(off) <= cfg.conflict_window_min:
                kind = "NEAR"
            elif off % 1440 in (0, 1) and abs(off) <= 7 * 1440:
                kind = "DATE_CONFLICT"
            else:
                continue
        elif off in (0, 1):
            kind = "AMOUNT_CONFLICT"
        else:
            continue
        scored.append(ScoredCandidate(c, off, kind))

    def is_mine(c: SmsCandidate) -> bool:
        return c.claim_kind is None or (own_submission_id is not None and c.claim_submission_id == own_submission_id)

    strong = [s for s in scored if s.kind in ("EXACT", "LAG1")]
    if not strong:
        conflicts = [s for s in scored if s.kind != "AMOUNT_CONFLICT"]
        amount_conf = [s for s in scored if s.kind == "AMOUNT_CONFLICT"]
        if conflicts or amount_conf:
            notes = []
            if conflicts:
                notes.append("SMS with the same amount exists but its time/date does not match the slip")
            if amount_conf:
                notes.append("SMS at the slip's minute exists but for a different amount")
            return MatchResult(MatchStatus.CONFLICT, candidates=scored, notes=notes)
        return MatchResult(MatchStatus.NONE, candidates=scored, notes=["no bank SMS matches this slip yet"])

    free = [s for s in strong if is_mine(s.sms)]
    taken = [s for s in strong if not is_mine(s.sms)]
    if not free:
        return MatchResult(MatchStatus.ALREADY_CLAIMED, candidates=scored,
                           claimed_by=[s.sms for s in taken],
                           notes=["the matching bank SMS is already claimed"])
    if len(free) > 1:
        return MatchResult(MatchStatus.AMBIGUOUS, candidates=scored,
                           notes=[f"{len(free)} unclaimed bank SMS match this amount and time"])
    if taken:
        return MatchResult(MatchStatus.AMBIGUOUS, candidates=scored,
                           notes=["one matching SMS is already claimed by another order and another is free; "
                                  "refusing to pick automatically"])

    chosen = free[0]
    window = timedelta(minutes=cfg.isolation_window_min)
    neighbours = [
        c for c in candidates
        if c.id != chosen.sms.id and c.txn_at is not None
        and c.business_account_id == chosen.sms.business_account_id
        and c.amount_cents == slip_amount_cents
        and abs(minute_floor(c.txn_at) - minute_floor(chosen.sms.txn_at)) <= window
    ]
    if neighbours:
        extra = [ScoredCandidate(n, _offset_minutes(n.txn_at, slip_txn_at), "NEIGHBOUR") for n in neighbours
                 if all(n.id != s.sms.id for s in scored)]
        return MatchResult(MatchStatus.AMBIGUOUS, candidates=scored + extra,
                           notes=[f"{len(neighbours)} other same-amount credit(s) within "
                                  f"{cfg.isolation_window_min} min on the same account"])

    strength = 1.0 if chosen.kind == "EXACT" else 0.95
    # Bank-specific parsers are strict regexes (>= 0.9); only the generic fallback parser discounts the match.
    if chosen.sms.parse_confidence < 0.9:
        strength *= chosen.sms.parse_confidence
    return MatchResult(MatchStatus.STRONG, chosen=chosen.sms, offset_min=chosen.offset_min,
                       strength=strength, candidates=scored,
                       notes=[f"bank SMS #{chosen.sms.id} matches amount and time ({chosen.kind})"])
