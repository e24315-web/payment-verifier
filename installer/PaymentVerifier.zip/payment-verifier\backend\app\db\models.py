"""SQLAlchemy models. Money = integer cents. Datetimes stored as naive UTC, returned as aware UTC.

Integrity guarantees enforced by the database (not just by code):
* claims.sms_id UNIQUE             -> one bank credit can back at most one submission (race-safe)
* submissions.channel_message_id UNIQUE -> WhatsApp webhook retries are idempotent
* sms_messages UNIQUE(content_hash, received_at, device_id) -> forwarder retries are idempotent
* decision_records / audit_log are append-only (triggers abort UPDATE/DELETE)
"""
from __future__ import annotations

import json
from datetime import datetime, timezone

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    TypeDecorator,
    UniqueConstraint,
    event,
    text,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class UTCDateTime(TypeDecorator):
    impl = DateTime
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        if value.tzinfo is None:
            raise ValueError("naive datetime passed to UTCDateTime")
        return value.astimezone(timezone.utc).replace(tzinfo=None)

    def process_result_value(self, value, dialect):
        return value.replace(tzinfo=timezone.utc) if value is not None else None


class Base(DeclarativeBase):
    type_annotation_map = {datetime: UTCDateTime, dict: JSON, list: JSON}


class Business(Base):
    __tablename__ = "businesses"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    whatsapp_number: Mapped[str | None] = mapped_column(String(40))
    hotline: Mapped[str | None] = mapped_column(String(40))          # given to customers for refunds/help
    # Minutes the customer has to transfer after receiving the account details / to pay a balance.
    # None = no time limit.
    payment_window_min: Mapped[int | None] = mapped_column(Integer)
    balance_window_min: Mapped[int | None] = mapped_column(Integer)
    created_at: Mapped[datetime]


class BusinessAccount(Base):
    __tablename__ = "business_accounts"
    id: Mapped[int] = mapped_column(primary_key=True)
    business_id: Mapped[int] = mapped_column(ForeignKey("businesses.id"))
    bank: Mapped[str] = mapped_column(String(100))
    account_number: Mapped[str] = mapped_column(String(40))   # normalised digits, may contain '*'
    display_account: Mapped[str] = mapped_column(String(60))  # as the owner typed it
    holder_names: Mapped[list] = mapped_column(default=list)  # aliases: full name, short name...
    # SMS sender numbers / IDs this account's credit alerts come from (e.g. "COMBANK", "+94112353353").
    # Used as the webhook allowlist and to know which account an SMS belongs to.
    sms_senders: Mapped[list] = mapped_column(default=list)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class Customer(Base):
    __tablename__ = "customers"
    __table_args__ = (UniqueConstraint("business_id", "phone"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    business_id: Mapped[int] = mapped_column(ForeignKey("businesses.id"))
    name: Mapped[str] = mapped_column(String(200))
    phone: Mapped[str] = mapped_column(String(40))
    created_at: Mapped[datetime]

    @property
    def code(self) -> str:
        """Customer ID given to the customer for refunds / hotline calls."""
        return f"C{self.id:05d}"


class Refund(Base):
    """Staff record that money owed to a customer (overpayment, late or cancelled payment) was paid back."""
    __tablename__ = "refunds"
    id: Mapped[int] = mapped_column(primary_key=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), index=True)
    amount_cents: Mapped[int] = mapped_column(Integer)
    actor: Mapped[str] = mapped_column(String(60))
    note: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime]


class Order(Base):
    __tablename__ = "orders"
    id: Mapped[int] = mapped_column(primary_key=True)
    business_id: Mapped[int] = mapped_column(ForeignKey("businesses.id"))
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), index=True)
    code: Mapped[str] = mapped_column(String(20), unique=True)
    description: Mapped[str | None] = mapped_column(String(500))
    expected_cents: Mapped[int] = mapped_column(Integer)
    # The business account the bot told this customer to pay into (chosen by staff at order creation).
    pay_to_account_id: Mapped[int | None] = mapped_column(ForeignKey("business_accounts.id"))
    paid_cents: Mapped[int] = mapped_column(Integer, default=0)
    # AWAITING_PAYMENT | PARTIALLY_PAID | PAID | EXPIRED (nothing paid in time) | CANCELLED (balance not paid in time)
    status: Mapped[str] = mapped_column(String(30), default="AWAITING_PAYMENT")
    expires_at: Mapped[datetime | None]        # transfer must happen by this time (payment window)
    balance_due_by: Mapped[datetime | None]    # after an underpayment: balance must be paid by this time
    closed_reason: Mapped[str | None] = mapped_column(String(200))
    created_at: Mapped[datetime]

    customer: Mapped[Customer] = relationship()


class Submission(Base):
    __tablename__ = "submissions"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), index=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), index=True)
    channel_message_id: Mapped[str | None] = mapped_column(String(120), unique=True)
    image_path: Mapped[str | None] = mapped_column(String(500))
    image_sha256: Mapped[str | None] = mapped_column(String(64), index=True)
    image_phash: Mapped[str | None] = mapped_column(String(32))

    extraction: Mapped[dict] = mapped_column(default=dict)       # SlipExtraction.to_dict()
    corrections: Mapped[dict | None] = mapped_column(JSON)      # staff edits {field: value}
    extraction_meta: Mapped[dict | None] = mapped_column(JSON)  # tier, attempts, latency, cost, quality

    # Canonical transaction identity (denormalised from extraction for indexed duplicate/reuse lookups).
    slip_type: Mapped[str | None] = mapped_column(String(30))
    amount_cents: Mapped[int | None] = mapped_column(Integer, index=True)
    txn_at: Mapped[datetime | None]
    txn_minute: Mapped[str | None] = mapped_column(String(12), index=True)   # local YYYYMMDDHHMM
    receiving_account: Mapped[str | None] = mapped_column(String(40))
    reference_raw: Mapped[str | None] = mapped_column(String(60))
    reference_folded: Mapped[str | None] = mapped_column(String(60), index=True)
    sender_account: Mapped[str | None] = mapped_column(String(40))
    sender_name: Mapped[str | None] = mapped_column(String(200))

    outcome: Mapped[str | None] = mapped_column(String(30), index=True)
    reason_code: Mapped[str | None] = mapped_column(String(60))
    confidence: Mapped[float | None] = mapped_column(Float)
    flags: Mapped[list] = mapped_column(default=list)
    match: Mapped[dict | None] = mapped_column(JSON)
    decided_by: Mapped[str] = mapped_column(String(60), default="system")  # system | staff:<name>
    duplicate_of: Mapped[int | None] = mapped_column(Integer)
    contested: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime]
    updated_at: Mapped[datetime]

    order: Mapped[Order] = relationship()


class SmsMessage(Base):
    __tablename__ = "sms_messages"
    __table_args__ = (UniqueConstraint("content_hash", "received_at", "device_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    business_id: Mapped[int] = mapped_column(ForeignKey("businesses.id"))
    source: Mapped[str] = mapped_column(String(20))          # webhook | manual | csv | simulator
    sender: Mapped[str | None] = mapped_column(String(60))
    device_id: Mapped[str] = mapped_column(String(80), default="")
    body: Mapped[str] = mapped_column(Text)
    content_hash: Mapped[str] = mapped_column(String(64))
    received_at: Mapped[datetime]

    parser: Mapped[str | None] = mapped_column(String(40))
    is_credit: Mapped[bool] = mapped_column(Boolean, default=False)
    amount_cents: Mapped[int | None] = mapped_column(Integer, index=True)
    account: Mapped[str | None] = mapped_column(String(40))
    business_account_id: Mapped[int | None] = mapped_column(ForeignKey("business_accounts.id"))
    txn_at: Mapped[datetime | None] = mapped_column(UTCDateTime, index=True)
    date_source: Mapped[str | None] = mapped_column(String(20))
    reference: Mapped[str | None] = mapped_column(String(60))
    balance_cents: Mapped[int | None] = mapped_column(Integer)   # INTERNAL ONLY
    channel: Mapped[str | None] = mapped_column(String(60))
    parse_confidence: Mapped[float] = mapped_column(Float, default=0.0)
    issues: Mapped[list] = mapped_column(default=list)
    created_at: Mapped[datetime]


class Claim(Base):
    __tablename__ = "claims"
    id: Mapped[int] = mapped_column(primary_key=True)
    sms_id: Mapped[int] = mapped_column(ForeignKey("sms_messages.id"), unique=True)
    submission_id: Mapped[int] = mapped_column(ForeignKey("submissions.id"), index=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), index=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), index=True)
    kind: Mapped[str] = mapped_column(String(20))   # HOLD | ORDER_PAYMENT | UNAPPLIED_CREDIT
    applied_cents: Mapped[int] = mapped_column(Integer, default=0)
    excess_cents: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime]


class CreditApplication(Base):
    """Staff applying a customer's held credit (overpayment / payment on an already-paid order) to an order.
    Keeps UNIQUE(claims.sms_id) intact: one bank credit, one claim; the claim's excess can be spread over orders."""
    __tablename__ = "credit_applications"
    id: Mapped[int] = mapped_column(primary_key=True)
    claim_id: Mapped[int] = mapped_column(ForeignKey("claims.id"), index=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), index=True)
    amount_cents: Mapped[int] = mapped_column(Integer)
    actor: Mapped[str] = mapped_column(String(60))
    note: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime]


class DecisionRecord(Base):
    __tablename__ = "decision_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    submission_id: Mapped[int] = mapped_column(ForeignKey("submissions.id"), index=True)
    outcome: Mapped[str] = mapped_column(String(30))
    reason_code: Mapped[str] = mapped_column(String(60))
    confidence: Mapped[float] = mapped_column(Float)
    reasons: Mapped[list] = mapped_column(default=list)
    flags: Mapped[list] = mapped_column(default=list)
    next_action: Mapped[str] = mapped_column(String(300))
    customer_message: Mapped[str] = mapped_column(Text)
    match: Mapped[dict | None] = mapped_column(JSON)
    evidence: Mapped[dict | None] = mapped_column(JSON)   # snapshot of the slip fields used
    engine_version: Mapped[str] = mapped_column(String(40))
    actor: Mapped[str] = mapped_column(String(60))
    note: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime]


class ImageCache(Base):
    """Extraction result per exact image. A re-sent / forwarded identical image costs zero OCR."""
    __tablename__ = "image_cache"
    sha256: Mapped[str] = mapped_column(String(64), primary_key=True)
    phash: Mapped[str] = mapped_column(String(32))
    report: Mapped[dict] = mapped_column(JSON)
    hits: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime]


class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(primary_key=True)
    at: Mapped[datetime]
    actor: Mapped[str] = mapped_column(String(60))
    action: Mapped[str] = mapped_column(String(60))
    entity_type: Mapped[str] = mapped_column(String(40))
    entity_id: Mapped[int | None] = mapped_column(Integer)
    detail: Mapped[dict | None] = mapped_column(JSON)


class OutboundMessage(Base):
    __tablename__ = "outbound_messages"
    id: Mapped[int] = mapped_column(primary_key=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), index=True)
    order_id: Mapped[int | None] = mapped_column(ForeignKey("orders.id"))
    submission_id: Mapped[int | None] = mapped_column(ForeignKey("submissions.id"))
    to_phone: Mapped[str] = mapped_column(String(40))
    body: Mapped[str] = mapped_column(Text)
    reason_code: Mapped[str | None] = mapped_column(String(60))
    status: Mapped[str] = mapped_column(String(20), default="QUEUED")  # QUEUED | SENT | FAILED
    created_at: Mapped[datetime]


_APPEND_ONLY = ("decision_records", "audit_log")


@event.listens_for(Base.metadata, "after_create")
def _append_only_triggers(target, connection, **kw):
    if connection.dialect.name != "sqlite":
        return
    for table in _APPEND_ONLY:
        for op in ("UPDATE", "DELETE"):
            connection.execute(text(
                f"CREATE TRIGGER IF NOT EXISTS {table}_no_{op.lower()} BEFORE {op} ON {table} "
                f"BEGIN SELECT RAISE(ABORT, '{table} is append-only'); END;"
            ))


def dumps(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, default=str)
