import React, { useEffect, useState } from "react";
import { api, ago, dt, setStaffName, staffName } from "./lib.js";
import { usePoll } from "./ui.jsx";
import Queue from "./pages/Queue.jsx";
import Orders from "./pages/Orders.jsx";
import SmsPage from "./pages/Sms.jsx";
import Customers from "./pages/Customers.jsx";
import Simulator from "./pages/Simulator.jsx";
import Settings from "./pages/Settings.jsx";

const PAGES = [
  ["queue", "Payments to review", Queue],
  ["orders", "Orders", Orders],
  ["sms", "Bank SMS", SmsPage],
  ["customers", "Customers & refunds", Customers],
  ["simulator", "WhatsApp simulator", Simulator],
  ["settings", "Settings", Settings],
];

function useHashRoute() {
  const parse = () => {
    const [page, id] = window.location.hash.replace(/^#\/?/, "").split("/");
    return { page: page || "queue", id: id ? Number(id) : null };
  };
  const [route, setRoute] = useState(parse);
  useEffect(() => {
    const h = () => setRoute(parse());
    window.addEventListener("hashchange", h);
    return () => window.removeEventListener("hashchange", h);
  }, []);
  return route;
}

export default function App() {
  const route = useHashRoute();
  const [health, setHealth] = useState(null);
  const [biz, setBiz] = useState(null);
  const [staff, setStaff] = useState(staffName());
  usePoll(() => api.get("/api/health").then(setHealth).catch(() => setHealth(null)), 10000);
  useEffect(() => { api.get("/api/business").then(setBiz).catch(() => {}); }, [route.page]);
  const Page = (PAGES.find((p) => p[0] === route.page) || PAGES[0])[2];
  const feed = health?.sms_feed;

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-[1500px] mx-auto px-4 flex items-center gap-6 h-14">
          <div className="font-semibold">{biz?.name || "Payment Verifier"}</div>
          <nav className="flex gap-1 overflow-x-auto">
            {PAGES.map(([key, label]) => (
              <a key={key} href={`#/${key}`}
                className={`px-3 py-1.5 rounded-md text-sm whitespace-nowrap ${route.page === key ? "bg-slate-900 text-white" : "text-slate-600 hover:bg-slate-100"}`}>
                {label}
                {key === "queue" && health?.needs_action > 0 && (
                  <span className="ml-1.5 bg-amber-500 text-white rounded-full px-1.5 text-[11px]">{health.needs_action}</span>
                )}
              </a>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-3 text-xs text-slate-500">
            {health?.now && <span title="Server time (Asia/Colombo)">{dt(health.now)}</span>}
            <span className="flex items-center gap-1.5" title="Bank SMS feed from the business phone">
              <span className={`w-2 h-2 rounded-full ${feed ? (feed.stale ? "bg-red-500" : "bg-emerald-500") : "bg-slate-300"}`} />
              SMS feed {feed?.last_received_at ? `· last ${ago(feed.last_received_at)}` : "· none yet"}
            </span>
            <label className="flex items-center gap-1">
              Staff
              <input className="input !w-28 !py-1" value={staff} onChange={(e) => { setStaff(e.target.value); setStaffName(e.target.value); }} />
            </label>
          </div>
        </div>
      </header>

      {feed?.stale && (
        <div className="bg-red-50 border-b border-red-200 text-red-800 text-sm">
          <div className="max-w-[1500px] mx-auto px-4 py-2">
            <b>Bank SMS feed looks stale:</b> no SMS received in the last {feed.stale_after_hours} hours.
            "No SMS yet" may mean the phone forwarder is down, not that the customer did not pay. Check the business phone.
          </div>
        </div>
      )}
      {health?.setup_warnings?.length > 0 && route.page !== "settings" && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 text-xs">
          <div className="max-w-[1500px] mx-auto px-4 py-1.5">
            Setup: {health.setup_warnings[0]}{health.setup_warnings.length > 1 && ` (+${health.setup_warnings.length - 1} more)`} ·{" "}
            <a className="underline" href="#/settings">open Settings</a>
          </div>
        </div>
      )}

      <main className="flex-1 max-w-[1500px] w-full mx-auto px-4 py-4">
        <Page id={route.id} business={biz} health={health} />
      </main>
    </div>
  );
}
