"""Labelled evaluation cases.

Each case builds a small world (fresh database, fixed clock), submits ONE slip for the order under test and returns
that submission. Ground truth is what a careful human with bank-statement access would conclude:

  GENUINE    this customer's real payment for this order -> the right answer is to accept it
  INVALID    not a valid payment for this order (reused, wrong account, old, edited, not completed...)
  UNCERTAIN  the evidence genuinely cannot decide (two identical credits, feed down...) -> review is the right answer

Scoring: APPROVED on INVALID = FALSE APPROVAL (the costly error). REJECTED on GENUINE = FALSE REJECTION.
NEEDS_VERIFICATION is never "wrong" but costs staff time (manual-review rate).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from app.clock import lk
from tests.fixtures import samples as S

IMG = Path(__file__).resolve().parent.parent / "tests" / "fixtures" / "images"
A_T = lk(2026, 9, 26, 16, 18)


@dataclass
class Case:
    id: str
    scenario: str          # brief scenario / extra fraud case
    description: str
    truth: str             # GENUINE | INVALID | UNCERTAIN
    run: Callable          # (world, extractor) -> submission (and optionally expected sms id)
    image: bool = False    # uses real OCR
    expect_sms: int | None = None
    tags: list[str] = field(default_factory=list)


def _a(w, customer="Rizan", amount=5000, created=lk(2026, 9, 26, 16, 10), sms=True):
    w.clock.set(lk(2026, 9, 26, 16, 20))
    o = w.order(customer, amount, created)
    if sms:
        w.sms(S.SMS_A, lk(2026, 9, 26, 16, 18, 40))
    return o


def _b(w, customer="Athayea", created=lk(2026, 8, 28, 13, 30)):
    w.clock.set(lk(2026, 8, 28, 13, 50))
    o = w.order(customer, 7500, created)
    w.sms(S.SMS_B, lk(2026, 8, 28, 13, 44, 55))
    return o


def _slip(w, **kw):
    return w.slip(S.COMBANK_ERECEIPT, **kw)


def _reuse(w, **kw):
    o1 = _a(w)
    w.submit(o1, _slip(w))
    o2 = w.order("Fraudster", 5000, lk(2026, 9, 26, 16, 12))
    return w.submit(o2, _slip(w, **kw)).submission


def _img(w, x, name, order, transform=None):
    from app.services.intake import submit_slip_image
    data = (IMG / name).read_bytes()
    if transform:
        import io
        from PIL import Image
        im = transform(Image.open(io.BytesIO(data)).convert("RGB"))
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=85)
        data = buf.getvalue()
    sub, _ = submit_slip_image(w.s, order.id, data, x, w.clock, w.cfg)
    return sub


def text_cases() -> list[Case]:
    C = []
    add = lambda *a, **k: C.append(Case(*a, **k))

    # 1. normal payment
    add("N1", "Normal payment", "ComBank e-receipt, SMS same minute", "GENUINE",
        lambda w, x: w.submit(_a(w), _slip(w)).submission, expect_sms=1)
    add("N2", "Normal payment", "People's Bank cash slip, stamp 13:44:42, SMS 13:44", "GENUINE",
        lambda w, x: w.submit(_b(w), w.slip(S.PEOPLES_DEPOSIT)).submission, expect_sms=1)
    add("N3", "Normal payment", "Cash slip stamp 13:43:42, SMS 13:44 (1-min lag)", "GENUINE",
        lambda w, x: w.submit(_b(w), w.slip(S.PEOPLES_DEPOSIT.replace("13:44:42", "13:43:42"))).submission, expect_sms=1)

    def flash(w, x):
        w.clock.set(lk(2026, 9, 24, 22, 5))
        o = w.order("Kampu", 51000, lk(2026, 9, 24, 21, 55))
        w.sms(S.SMS_C_SYNTHETIC, lk(2026, 9, 24, 22, 1, 50))
        return w.submit(o, w.slip(S.COMBANK_FLASH)).submission
    add("N4", "Normal payment", "ComBank Flash receipt, synthetic SMS", "GENUINE", flash, expect_sms=1)

    def midnight(w, x):
        w.clock.set(lk(2026, 9, 27, 0, 5))
        o = w.order("Night", 5000, lk(2026, 9, 26, 23, 50))
        w.sms(S.combank_sms("5,000.00", "23:59"), lk(2026, 9, 27, 0, 1, 10))
        return w.submit(o, _slip(w, txn_at=lk(2026, 9, 26, 23, 59), reference="O600066123123",
                                 generated_at=lk(2026, 9, 26, 23, 59))).submission
    add("N5", "Normal payment", "Transfer 23:59, SMS delivered after midnight", "GENUINE", midnight, expect_sms=1)

    def slip_first(w, x):
        w.clock.set(lk(2026, 9, 26, 16, 19))
        o = w.order("Rizan", 5000, lk(2026, 9, 26, 16, 10))
        w.sms(S.combank_sms("1,000.00", "15:00"), lk(2026, 9, 26, 15, 0, 20))
        r = w.submit(o, _slip(w))
        w.clock.set(lk(2026, 9, 26, 16, 26))
        w.sms(S.SMS_A, lk(2026, 9, 26, 16, 25, 5))
        return w.refresh(r.submission)
    add("N6", "Missing evidence (SMS late)", "Slip first, SMS arrives 7 min later -> auto re-check", "GENUINE",
        slip_first, expect_sms=2)

    # 2. wrong amount
    add("W1", "Wrong amount", "Paid Rs 5,000 of Rs 8,000 (underpaid)", "GENUINE",
        lambda w, x: w.submit(_a(w, amount=8000), _slip(w)).submission, expect_sms=1, tags=["partial"])
    add("W2", "Wrong amount", "Paid Rs 5,000 for Rs 4,000 order (overpaid)", "GENUINE",
        lambda w, x: w.submit(_a(w, amount=4000), _slip(w)).submission, expect_sms=1, tags=["over"])
    add("W3", "Wrong amount / edited", "Slip amount edited to 50,000; bank credited 5,000", "INVALID",
        lambda w, x: w.submit(_a(w, amount=50000), _slip(w, amount_cents=5000000)).submission)

    # 3. wrong account
    add("A1", "Wrong account", "Beneficiary account is not the business's", "INVALID",
        lambda w, x: w.submit(_a(w), _slip(w, receiving_account="8026328799")).submission)
    add("A2", "Wrong account", "Different account read with low OCR confidence", "INVALID",
        lambda w, x: w.submit(_a(w), _slip(w, receiving_account=("8026328799", 0.7))).submission)

    # 4. duplicate
    def dup(w, x):
        o = _a(w)
        w.submit(o, _slip(w), sha="img-A")
        return w.submit(o, _slip(w), sha="img-A").submission
    add("D1", "Duplicate payment", "Same image sent twice for the same order", "GENUINE", dup, expect_sms=None,
        tags=["duplicate"])

    # 5. reused
    add("R1", "Reused payment", "Approved slip sent for another customer's order", "INVALID", lambda w, x: _reuse(w))
    add("R2", "Reused payment", "Same, reference OCR'd as 0 instead of O", "INVALID",
        lambda w, x: _reuse(w, reference="0600066186696"))

    def reuse_cash(w, x):
        o1 = _b(w)
        w.submit(o1, w.slip(S.PEOPLES_DEPOSIT))
        o2 = w.order("Other", 7500, lk(2026, 8, 28, 13, 35))
        return w.submit(o2, w.slip(S.PEOPLES_DEPOSIT)).submission
    add("R3", "Reused payment", "Cash slip reused by another customer (no reference)", "INVALID", reuse_cash)

    def fraud_first(w, x):
        w.clock.set(lk(2026, 9, 26, 16, 45))
        fo = w.order("Fraudster", 5000, lk(2026, 9, 26, 16, 40))
        w.sms(S.SMS_A, lk(2026, 9, 26, 16, 18, 40))
        w.submit(fo, _slip(w))
        ro = w.order("Rizan", 5000, lk(2026, 9, 26, 16, 10))
        return w.submit(ro, _slip(w)).submission
    add("R4", "Reused payment (fraudster first)", "Real payer submits after a fraudster's rejected attempt", "GENUINE",
        fraud_first, tags=["contested"])

    def same_cust(w, x):
        o1 = _a(w)
        w.submit(o1, _slip(w))
        o2 = w.order("Rizan", 5000, lk(2026, 9, 26, 16, 12))
        return w.submit(o2, _slip(w)).submission
    add("R5", "Reused payment", "Same customer uses one payment for two orders", "INVALID", same_cust)

    # 6. same payment different image
    def diff_img_same(w, x):
        o = _a(w)
        w.submit(o, _slip(w), sha="screenshot")
        return w.submit(o, _slip(w, ocr_conf=0.97), sha="photo").submission
    add("S1", "Same payment, different image", "Screenshot then photo of it, same order", "GENUINE",
        diff_img_same, tags=["duplicate"])
    add("S2", "Same payment, different image", "Cropped (no reference) copy for another customer", "INVALID",
        lambda w, x: _reuse(w, reference=None, secondary_reference=None))

    # 7. old payment
    def old_cash(w, x):
        w.clock.set(lk(2026, 9, 28, 10, 5))
        w.sms(S.SMS_B, lk(2026, 8, 28, 13, 44, 55))
        o = w.order("Athayea", 7500, lk(2026, 9, 28, 10, 0))
        return w.submit(o, w.slip(S.PEOPLES_DEPOSIT)).submission
    add("O1", "Old payment", "Month-old cash slip for today's order", "INVALID", old_cash)

    def old_flash(w, x):
        w.clock.set(lk(2026, 9, 28, 10, 5))
        w.sms(S.SMS_C_SYNTHETIC, lk(2026, 9, 24, 22, 1, 50))
        o = w.order("Kampu", 51000, lk(2026, 9, 28, 10, 0))
        return w.submit(o, w.slip(S.COMBANK_FLASH)).submission
    add("O2", "Old payment", "Old Flash receipt (only one date on slip)", "INVALID", old_flash)
    add("O3", "Old payment (grace)", "Paid 3 min before the order row was created", "UNCERTAIN",
        lambda w, x: w.submit(_a(w, created=lk(2026, 9, 26, 16, 21)), _slip(w)).submission)

    # 8. edited / suspicious
    add("E1", "Edited slip", "Time edited 16:18 -> 16:25", "INVALID",
        lambda w, x: w.submit(_a(w), _slip(w, txn_at=lk(2026, 9, 26, 16, 25))).submission)
    add("E2", "Edited slip", "Known reference with edited amount (other customer)", "INVALID",
        lambda w, x: _reuse(w, amount_cents=5000000))

    def gen_before(w, x):
        from app.domain.slip_parsers import extract_slip
        return w.submit(_a(w), extract_slip(S.COMBANK_ERECEIPT.replace("Generated at 9/26/26", "Generated at 9/25/26"))).submission
    add("E3", "Edited slip", "Receipt 'generated' a day before the transfer", "INVALID", gen_before)
    add("E4", "Edited slip", "Date edited forward one day (future)", "INVALID",
        lambda w, x: w.submit(_a(w), _slip(w, txn_at=lk(2026, 9, 27, 16, 18))).submission)
    add("E5", "Pending transfer", "Screenshot of a PENDING transfer", "INVALID",
        lambda w, x: w.submit(_a(w, sms=False), _slip(w, status="PENDING")).submission)
    add("E6", "Scheduled transfer", "Screenshot of a SCHEDULED transfer", "INVALID",
        lambda w, x: w.submit(_a(w, sms=False), _slip(w, status="SCHEDULED")).submission)

    def date_conf(w, x):
        w.clock.set(lk(2026, 8, 28, 13, 50))
        o = w.order("Athayea", 7500, lk(2026, 8, 20, 9, 0))
        w.sms(S.SMS_B, lk(2026, 8, 28, 13, 44, 55))
        return w.submit(o, w.slip(S.PEOPLES_DEPOSIT.replace("28AUG2026 13:44:42", "27AUG2026 13:44:42"))).submission
    add("E7", "Conflicting evidence", "Cash slip date differs from the SMS date", "INVALID", date_conf)

    def new_sender(w, x):
        o1 = _a(w)
        w.submit(o1, _slip(w))
        o2 = w.order("Rizan", 2000, lk(2026, 9, 26, 17, 0))
        w.clock.set(lk(2026, 9, 26, 17, 10))
        w.sms(S.combank_sms("2,000.00", "17:05"), lk(2026, 9, 26, 17, 5, 30))
        return w.submit(o2, _slip(w, amount_cents=200000, txn_at=lk(2026, 9, 26, 17, 5), reference="O600066100001",
                                  sender_account="8011111199", generated_at=lk(2026, 9, 26, 17, 5))).submission
    add("E8", "New sender account", "Known customer pays from a new account (soft signal)", "GENUINE", new_sender,
        expect_sms=2)

    # 9. unclear
    add("U1", "Unclear image", "Amount not readable", "UNCERTAIN",
        lambda w, x: w.submit(_a(w), _slip(w, amount_cents=None)).submission)
    add("U2", "Unclear image", "Time cropped out", "UNCERTAIN",
        lambda w, x: w.submit(_a(w), _slip(w, txn_at=None)).submission)
    add("U3", "Unclear image", "Low OCR confidence overall", "UNCERTAIN",
        lambda w, x: w.submit(_a(w), _slip(w, ocr_conf=0.8)).submission)
    add("U4", "Unclear image", "Receiving account cropped out", "UNCERTAIN",
        lambda w, x: w.submit(_a(w), _slip(w, receiving_account=None)).submission)

    # 11. missing evidence
    def no_sms(w, x):
        w.clock.set(lk(2026, 9, 26, 16, 20))
        o = w.order("Rizan", 5000, lk(2026, 9, 26, 16, 10))
        w.sms(S.combank_sms("1,000.00", "15:00"), lk(2026, 9, 26, 15, 0, 20))
        return w.submit(o, _slip(w)).submission
    add("M1", "Missing evidence", "No SMS (yet) for a real-looking slip", "UNCERTAIN", no_sms)
    add("M2", "Missing evidence", "SMS feed down (no SMS for hours)", "UNCERTAIN",
        lambda w, x: w.submit(_a(w, sms=False), _slip(w)).submission)

    def debit_only(w, x):
        o = _a(w, sms=False)
        w.sms(S.combank_sms("5,000.00", "16:18", kind="Debit"), lk(2026, 9, 26, 16, 18, 40))
        return w.submit(o, _slip(w)).submission
    add("M3", "Fake/irrelevant SMS", "Only a DEBIT SMS of that amount exists", "UNCERTAIN", debit_only)

    # 12. multiple customers similar payments
    def two_same(w, x):
        o = _a(w)
        w.sms(S.SMS_A, lk(2026, 9, 26, 16, 18, 52))
        return w.submit(o, _slip(w)).submission
    add("P1", "Similar payments", "Two Rs 5,000 credits in the same minute", "UNCERTAIN", two_same)

    def one_apart(w, x):
        o = _a(w)
        w.sms(S.combank_sms("5,000.00", "16:19"), lk(2026, 9, 26, 16, 19, 30))
        return w.submit(o, _slip(w)).submission
    add("P2", "Similar payments", "Same amount one minute apart", "UNCERTAIN", one_apart)

    def far_apart(w, x):
        o1 = _a(w)
        w.submit(o1, _slip(w))
        o2 = w.order("Nimal", 5000, lk(2026, 9, 26, 16, 35))
        w.clock.set(lk(2026, 9, 26, 16, 45))
        w.sms(S.combank_sms("5,000.00", "16:40"), lk(2026, 9, 26, 16, 40, 10))
        return w.submit(o2, _slip(w, txn_at=lk(2026, 9, 26, 16, 40), reference="O600066177777",
                                  sender_account="81******11", generated_at=lk(2026, 9, 26, 16, 40))).submission
    add("P3", "Similar payments", "Same amount, second customer 22 min later", "GENUINE", far_apart, expect_sms=2)

    def two_accounts(w, x):
        o = _a(w)
        w.sms(S.peoples_sms("5000.00", "16:18", "26/09/2026"), lk(2026, 9, 26, 16, 18, 45))
        return w.submit(o, _slip(w)).submission
    add("P4", "Similar payments", "Same amount+minute on the OTHER business account", "GENUINE", two_accounts,
        expect_sms=1)

    # payment windows (owner rules)
    def late(w, x):
        w.windows(10, 10)
        return w.submit(_a(w, created=lk(2026, 9, 26, 16, 0)), _slip(w)).submission
    add("T1", "Payment window", "Transfer 8 min after the 10-min window closed", "INVALID", late, tags=["late"])

    def on_time(w, x):
        w.windows(10, 10)
        return w.submit(_a(w), _slip(w)).submission
    add("T2", "Payment window", "Transfer inside the 10-min window", "GENUINE", on_time, expect_sms=1)
    return C


def image_cases() -> list[Case]:
    from PIL import ImageEnhance, ImageFilter
    C = []
    add = lambda *a, **k: C.append(Case(*a, image=True, **k))

    add("I1", "Normal payment (real image)", "Real ComBank e-receipt image", "GENUINE",
        lambda w, x: _img(w, x, "combank_ereceipt.jpeg", _a(w)), expect_sms=1)

    def flash(w, x):
        w.clock.set(lk(2026, 9, 24, 22, 5))
        o = w.order("Kampu", 51000, lk(2026, 9, 24, 21, 55))
        w.sms(S.SMS_C_SYNTHETIC, lk(2026, 9, 24, 22, 1, 50))
        return _img(w, x, "combank_flash.jpeg", o)
    add("I2", "Normal payment (real image)", "Real ComBank Flash screenshot", "GENUINE", flash, expect_sms=1)
    add("I3", "Normal payment (real image)", "Real People's Bank cash-slip PHOTO (rotated, folded)", "GENUINE",
        lambda w, x: _img(w, x, "peoples_deposit.jpeg", _b(w)), expect_sms=1)

    def old_real(w, x):
        w.clock.set(lk(2026, 9, 28, 10, 5))
        w.sms(S.SMS_B, lk(2026, 8, 28, 13, 44, 55))
        return _img(w, x, "peoples_deposit.jpeg", w.order("Athayea", 7500, lk(2026, 9, 28, 10, 0)))
    add("I4", "Old payment (real image)", "Real month-old cash slip for today's order", "INVALID", old_real)

    def reuse_real(w, x):
        o1 = _a(w)
        _img(w, x, "combank_ereceipt.jpeg", o1)
        o2 = w.order("Fraudster", 5000, lk(2026, 9, 26, 16, 12))
        return _img(w, x, "combank_ereceipt.jpeg", o2, lambda im: im.crop((8, 8, im.width - 8, int(im.height * 0.7))))
    add("I5", "Reused payment (real image)", "Cropped + recompressed copy sent by another customer", "INVALID", reuse_real)
    add("I6", "Same payment (real image)", "Real e-receipt rotated 90 degrees", "GENUINE",
        lambda w, x: _img(w, x, "combank_ereceipt.jpeg", _a(w), lambda im: im.rotate(90, expand=True)), expect_sms=1)
    add("I7", "Unclear image (real)", "Real e-receipt heavily blurred", "GENUINE",
        lambda w, x: _img(w, x, "combank_ereceipt.jpeg", _a(w), lambda im: im.filter(ImageFilter.GaussianBlur(6))),
        tags=["degraded"])
    add("I8", "Unclear image (real)", "Real e-receipt very dark", "GENUINE",
        lambda w, x: _img(w, x, "combank_ereceipt.jpeg", _a(w), lambda im: ImageEnhance.Brightness(im).enhance(0.3)),
        tags=["degraded"])
    add("I9", "Unclear image (real)", "Real cash slip, low resolution (25%)", "GENUINE",
        lambda w, x: _img(w, x, "peoples_deposit.jpeg", _b(w), lambda im: im.resize((im.width // 4, im.height // 4))),
        tags=["degraded"])
    add("I10", "Unclear image (real)", "Real e-receipt cropped to top 30% (no time)", "GENUINE",
        lambda w, x: _img(w, x, "combank_ereceipt.jpeg", _a(w), lambda im: im.crop((0, 0, im.width, int(im.height * 0.3)))),
        tags=["degraded"])
    return C
