"""Verification service: gathers evidence from the DB, runs the pure decision table, applies the result
atomically (claim + decision record + order balance + audit + WhatsApp outbox).
"""
from __future__ import annotations

import re
from datetime import timedelta

from sqlalchemy import func, or_, select
from sqlalchemy.exc import IntegrityError, OperationalError
from sqlalchemy.orm import Session

from app.clock import Clock
from app.config import ENGINE_VERSION, RulesConfig
from app.db.models import (
    AuditLog,
    Business,
    BusinessAccount,
    Claim,
    CreditApplication,
    Customer,
    DecisionRecord,
    Order,
    OutboundMessage,
    SmsMessage,
    Submission,
)
from app.domain.decision import (
    AccountView,
    Decision,
    DecisionInput,
    OrderView,
    SUPERSEDABLE,
    PriorSubmission,
    compatible_accounts,
    decide,
)
from app.domain.matching import SmsCandidate, match_slip
from app.domain.normalize import accounts_compatible, fold_reference, minute_key
from app.domain.types import Outcome, SlipExtraction, SlipType

CLOSED_STATUSES = ("EXPIRED", "CANCELLED")

# Reasons that the system re-checks automatically when new bank SMS arrive.
REEVALUABLE = {"WAITING_FOR_SMS", "WAITING_FOR_SMS_EXPIRED", "SMS_FEED_STALE", "SMS_CONFLICT", "AMBIGUOUS_MATCH"}


def audit(session: Session, clock: Clock, actor: str, action: str, entity_type: str, entity_id: int | None,
          detail: dict | None = None) -> None:
    session.add(AuditLog(at=clock.now(), actor=actor, action=action, entity_type=entity_type,
                         entity_id=entity_id, detail=detail))


def account_views(session: Session, business_id: int) -> list[AccountView]:
    rows = session.scalars(select(BusinessAccount).where(BusinessAccount.business_id == business_id,
                                                         BusinessAccount.is_active.is_(True))).all()
    return [AccountView(a.id, a.bank, a.account_number, list(a.holder_names or [])) for a in rows]


def _bank_key(name: str | None) -> str:
    return re.sub(r"[^A-Z]", "", (name or "").upper())


def _allowed_account_ids(slip: SlipExtraction, accounts: list[AccountView], cfg: RulesConfig) -> set[int] | None:
    """Which business accounts could this slip have paid into? None = don't restrict."""
    if slip.get("receiving_account") and slip.conf("receiving_account") >= cfg.min_account_conf:
        ids = {a.id for a in compatible_accounts(slip, accounts)}
        return ids or None
    bank = _bank_key(slip.get("bank"))
    if bank:
        ids = {a.id for a in accounts if _bank_key(a.bank).startswith(bank[:8]) or bank.startswith(_bank_key(a.bank)[:8])}
        if ids:
            return ids
    return None


def refresh_canonical(sub: Submission, slip: SlipExtraction) -> None:
    sub.slip_type = slip.slip_type.value
    sub.amount_cents = slip.get("amount_cents")
    sub.txn_at = slip.get("txn_at")
    sub.txn_minute = minute_key(sub.txn_at) if sub.txn_at else None
    sub.receiving_account = slip.get("receiving_account")
    sub.reference_raw = slip.get("reference")
    sub.reference_folded = fold_reference(slip.get("reference"))
    sub.sender_account = slip.get("sender_account")
    sub.sender_name = slip.get("sender_name")


def current_slip(sub: Submission) -> SlipExtraction:
    return SlipExtraction.from_dict(sub.extraction or {}).with_corrections(sub.corrections)


def _same_details(a: Submission, b: Submission) -> bool:
    return (a.amount_cents is not None and a.amount_cents == b.amount_cents
            and a.txn_minute is not None and a.txn_minute == b.txn_minute)


def _priors(session: Session, sub: Submission) -> tuple[PriorSubmission | None, list[PriorSubmission]]:
    conds = []
    if sub.image_sha256:
        conds.append(Submission.image_sha256 == sub.image_sha256)
    if sub.amount_cents is not None and sub.txn_minute:
        conds.append((Submission.amount_cents == sub.amount_cents) & (Submission.txn_minute == sub.txn_minute))
    if sub.reference_folded:
        conds.append(Submission.reference_folded == sub.reference_folded)
    if not conds:
        return None, []
    rows = session.scalars(select(Submission).where(Submission.id != sub.id, or_(*conds))
                           .order_by(Submission.id)).all()
    same_order: PriorSubmission | None = None
    cross: list[PriorSubmission] = []
    for r in rows:
        if sub.image_sha256 and r.image_sha256 == sub.image_sha256:
            kind = "IMAGE"
        elif sub.reference_folded and r.reference_folded == sub.reference_folded:
            kind = "REFERENCE"
        else:
            kind = "CANONICAL"
            # Canonical match also needs compatible receiving accounts when both slips show one.
            if r.receiving_account and sub.receiving_account and not accounts_compatible(r.receiving_account, sub.receiving_account):
                continue
        same = _same_details(r, sub) or kind == "IMAGE"
        prior = PriorSubmission(r.id, r.order_id, r.customer_id, r.outcome, r.reason_code, kind, same)
        if r.order_id == sub.order_id:
            # Only earlier submissions make this one a duplicate (the earlier one is the original).
            if (r.id < sub.id and same_order is None and (same or kind == "IMAGE")
                    and r.reason_code not in SUPERSEDABLE):
                same_order = prior
        else:
            cross.append(prior)
    return same_order, cross


def _sms_candidates(session: Session, business_id: int, slip: SlipExtraction) -> list[SmsCandidate]:
    t = slip.get("txn_at")
    if t is None:
        return []
    rows = session.execute(
        select(SmsMessage, Claim)
        .outerjoin(Claim, Claim.sms_id == SmsMessage.id)
        .where(SmsMessage.business_id == business_id, SmsMessage.is_credit.is_(True),
               SmsMessage.txn_at.is_not(None),
               SmsMessage.txn_at >= t - timedelta(days=8), SmsMessage.txn_at <= t + timedelta(days=1))
    ).all()
    return [
        SmsCandidate(
            id=s.id, business_account_id=s.business_account_id, amount_cents=s.amount_cents, txn_at=s.txn_at,
            parse_confidence=s.parse_confidence,
            claim_kind=c.kind if c else None, claim_submission_id=c.submission_id if c else None,
            claim_order_id=c.order_id if c else None, claim_customer_id=c.customer_id if c else None,
        )
        for s, c in rows
    ]


def feed_is_stale(session: Session, business_id: int, clock: Clock, cfg: RulesConfig) -> bool:
    last = session.scalar(select(func.max(SmsMessage.received_at)).where(SmsMessage.business_id == business_id,
                                                                          SmsMessage.source != "cash"))
    if last is None:
        return True
    return clock.now() - last > timedelta(hours=cfg.sms_feed_stale_hours)


def recompute_order(session: Session, order: Order) -> None:
    paid = session.scalar(select(func.coalesce(func.sum(Claim.applied_cents), 0))
                          .where(Claim.order_id == order.id, Claim.kind == "ORDER_PAYMENT"))
    credit = session.scalar(select(func.coalesce(func.sum(CreditApplication.amount_cents), 0))
                            .where(CreditApplication.order_id == order.id))
    order.paid_cents = int(paid or 0) + int(credit or 0)
    if order.status in CLOSED_STATUSES:
        return
    if order.paid_cents <= 0:
        order.status = "AWAITING_PAYMENT"
    elif order.paid_cents < order.expected_cents:
        order.status = "PARTIALLY_PAID"
    else:
        order.status = "PAID"


def _known_senders(session: Session, sub: Submission) -> list[str]:
    rows = session.scalars(select(Submission.sender_account).where(
        Submission.customer_id == sub.customer_id, Submission.id != sub.id,
        Submission.outcome == "APPROVED", Submission.sender_account.is_not(None))).all()
    return sorted(set(rows))


def build_input(session: Session, sub: Submission, clock: Clock, cfg: RulesConfig) -> DecisionInput:
    # Read phase must not write: an early flush would take the SQLite write lock during evidence gathering.
    # Correctness under concurrency comes from UNIQUE(claims.sms_id) at write time, not from locking reads.
    with session.no_autoflush:
        return _build_input(session, sub, clock, cfg)


def _build_input(session: Session, sub: Submission, clock: Clock, cfg: RulesConfig) -> DecisionInput:
    order = session.get(Order, sub.order_id)
    slip = current_slip(sub)
    refresh_canonical(sub, slip)
    accounts = account_views(session, order.business_id)
    same_order, cross = _priors(session, sub)
    match = None
    if slip.get("amount_cents") is not None and slip.get("txn_at") is not None:
        match = match_slip(slip.get("amount_cents"), slip.get("txn_at"),
                           _sms_candidates(session, order.business_id, slip), cfg,
                           allowed_account_ids=_allowed_account_ids(slip, accounts, cfg),
                           own_submission_id=sub.id)
    # Payments already applied by OTHER submissions (a re-evaluation must not count its own claim).
    paid_by_others = session.scalar(select(func.coalesce(func.sum(Claim.applied_cents), 0)).where(
        Claim.order_id == order.id, Claim.kind == "ORDER_PAYMENT", Claim.submission_id != sub.id))
    paid_by_others = int(paid_by_others or 0) + int(session.scalar(
        select(func.coalesce(func.sum(CreditApplication.amount_cents), 0))
        .where(CreditApplication.order_id == order.id)) or 0)
    business = session.get(Business, order.business_id)
    customer = session.get(Customer, order.customer_id)
    # A re-evaluation must not see the balance deadline its own earlier underpayment decision created.
    own_partial = session.scalar(select(Claim.id).where(Claim.submission_id == sub.id, Claim.kind == "ORDER_PAYMENT"))
    return DecisionInput(
        now=clock.now(), cfg=cfg,
        order=OrderView(order.id, order.code, order.customer_id, order.expected_cents, int(paid_by_others or 0),
                        order.created_at, order.pay_to_account_id, order.status, order.expires_at,
                        None if own_partial and not paid_by_others else order.balance_due_by, customer.code),
        hotline=business.hotline or "", balance_window_min=business.balance_window_min,
        slip=slip, business_accounts=accounts, match=match,
        same_order_prior=same_order, cross_order_priors=cross,
        feed_stale=feed_is_stale(session, order.business_id, clock, cfg),
        waited_too_long=clock.now() - sub.created_at > timedelta(minutes=cfg.sms_wait_ttl_min),
        known_sender_accounts=_known_senders(session, sub),
    )


def _apply(session: Session, sub: Submission, d: Decision, clock: Clock, actor: str, note: str | None,
           match_dict: dict | None) -> None:
    order = session.get(Order, sub.order_id)
    existing = session.scalar(select(Claim).where(Claim.submission_id == sub.id))
    wanted = d.claim
    if existing and (wanted is None or existing.sms_id != wanted.sms_id):
        audit(session, clock, actor, "claim_released", "claim", existing.id,
              {"sms_id": existing.sms_id, "kind": existing.kind})
        session.delete(existing)
        session.flush()
        existing = None
    if wanted:
        if existing:
            existing.kind, existing.applied_cents, existing.excess_cents = wanted.kind, wanted.applied_cents, wanted.excess_cents
        else:
            # UNIQUE(sms_id) makes this the race-safe step: a concurrent claim raises IntegrityError.
            session.add(Claim(sms_id=wanted.sms_id, submission_id=sub.id, order_id=sub.order_id,
                              customer_id=sub.customer_id, kind=wanted.kind, applied_cents=wanted.applied_cents,
                              excess_cents=wanted.excess_cents, created_at=clock.now()))
        session.flush()
        audit(session, clock, actor, "claim_set", "submission", sub.id, vars(wanted))
    if d.close_order and order.status not in CLOSED_STATUSES:
        order.status = d.close_order
        order.closed_reason = d.reason_code
        audit(session, clock, actor, "order_closed", "order", order.id, {"status": d.close_order, "by_submission": sub.id})
    if d.balance_due_by is not None:
        order.balance_due_by = d.balance_due_by
    recompute_order(session, order)

    previous = (sub.outcome, sub.reason_code)
    sub.outcome = d.outcome.value
    sub.reason_code = d.reason_code
    sub.confidence = d.confidence
    sub.flags = [f.to_dict() for f in d.flags]
    sub.match = match_dict
    sub.duplicate_of = d.duplicate_of
    sub.decided_by = actor
    sub.updated_at = clock.now()
    session.add(DecisionRecord(
        submission_id=sub.id, outcome=d.outcome.value, reason_code=d.reason_code, confidence=d.confidence,
        reasons=d.reasons, flags=[f.to_dict() for f in d.flags], next_action=d.next_action,
        customer_message=d.customer_message, match=match_dict,
        evidence=current_slip(sub).to_dict()["fields"], engine_version=ENGINE_VERSION, actor=actor, note=note,
        created_at=clock.now()))
    audit(session, clock, actor, "decision", "submission", sub.id,
          {"outcome": d.outcome.value, "reason": d.reason_code, "confidence": round(d.confidence, 3)})

    for sid in d.contest_submission_ids:
        other = session.get(Submission, sid)
        if other and not other.contested:
            other.contested = True
            audit(session, clock, actor, "contested", "submission", sid, {"by_submission": sub.id})

    # Notify the customer only when what they would be told changes (no spam on silent re-checks).
    if previous != (sub.outcome, sub.reason_code):
        customer = session.get(Customer, sub.customer_id)
        session.add(OutboundMessage(customer_id=customer.id, order_id=sub.order_id, submission_id=sub.id,
                                    to_phone=customer.phone, body=d.customer_message, reason_code=d.reason_code,
                                    created_at=clock.now()))


def evaluate(session: Session, submission_id: int, clock: Clock, cfg: RulesConfig, actor: str = "system",
             note: str | None = None, _retries: int = 3) -> Decision:
    """Evaluate a submission and commit. Retries if a concurrent transaction claimed the same SMS first."""
    for attempt in range(_retries):
        try:
            sub = session.get(Submission, submission_id)
            inp = build_input(session, sub, clock, cfg)
            d = decide(inp)
            _apply(session, sub, d, clock, actor, note, inp.match.to_dict() if inp.match else None)
            session.commit()
            return d
        except (IntegrityError, OperationalError):
            session.rollback()
            if attempt == _retries - 1:
                raise
    raise RuntimeError("unreachable")


def create_submission(session: Session, order_id: int, extraction: SlipExtraction, clock: Clock,
                      cfg: RulesConfig, image_sha256: str | None = None, image_phash: str | None = None,
                      image_path: str | None = None, channel_message_id: str | None = None,
                      extraction_meta: dict | None = None) -> tuple[Submission, Decision | None]:
    """Idempotent on channel_message_id: a webhook retry returns the existing submission unchanged."""
    if channel_message_id:
        existing = session.scalar(select(Submission).where(Submission.channel_message_id == channel_message_id))
        if existing:
            return existing, None
    order = session.get(Order, order_id)
    now = clock.now()
    sub = Submission(order_id=order.id, customer_id=order.customer_id, channel_message_id=channel_message_id,
                     image_path=image_path, image_sha256=image_sha256, image_phash=image_phash,
                     extraction=extraction.to_dict(), extraction_meta=extraction_meta,
                     created_at=now, updated_at=now)
    session.add(sub)
    session.flush()
    audit(session, clock, "system", "submission_created", "submission", sub.id,
          {"order": order.code, "template": extraction.template})
    session.commit()
    return sub, evaluate(session, sub.id, clock, cfg)


def reevaluate_pending(session: Session, business_id: int, clock: Clock, cfg: RulesConfig,
                       amount_cents: int | None = None) -> list[int]:
    """Re-run system-decided NEEDS_VERIFICATION submissions that new SMS evidence could resolve."""
    q = (select(Submission.id).join(Order, Order.id == Submission.order_id)
         .where(Order.business_id == business_id, Submission.outcome == Outcome.NEEDS_VERIFICATION.value,
                Submission.reason_code.in_(REEVALUABLE), Submission.decided_by == "system")
         .order_by(Submission.id))
    if amount_cents is not None:
        q = q.where(Submission.amount_cents == amount_cents)
    ids = list(session.scalars(q).all())
    for sid in ids:
        evaluate(session, sid, clock, cfg)
    return ids
