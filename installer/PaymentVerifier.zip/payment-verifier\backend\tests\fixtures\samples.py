"""Golden samples.

SLIP TEXTS are *idealised OCR text* transcribed by hand from the real images in fixtures/images
(Phase 1 tests the templates; Phase 2 tests the real OCR output against the same fields).
'?' marks characters that were illegible on the photo. Nothing illegible has been invented.

SMS texts A and B are the real messages supplied by the business owner. SMS C is SYNTHETIC
(no real SMS was supplied for the Flash receipt) and is written in the real ComBank format.
"""

# proof online.jpeg: ComBank "Transfer within ComBank" e-Receipt
COMBANK_ERECEIPT = """e-Receipt Transfer within ComBank COMMERCIAL BANK
Bank Reference Number O600066186696
Sender’s Account Number 80******73
Sender's Name MR MOHAMED RIZAN ABDUR RASHEED
Transfer Amount 5,000.00
Transfer Currency LKR
Beneficiary Name MR MOHAMED RIZAN ATHAYEA RASOOL
Beneficiary's Account Currency LKR
Beneficiary Account Number 8026328795
Beneficiary's Account Narration rasool
Transaction Date/Time 26/09/2026 04:18 PM
Payment Date 26-09-26
Status Completed
[e-Receipt Reference CCE1-2AD2-6445-6ED6]
Generated at 9/26/26 4:18 PM Page 1 of 1
Commercial Bank of Ceylon PLC, No 21, Sir Razik Fareed Mawatha (Formerly known as Bristol Street),
P.O. Box 856 Colombo 1, Sri Lanka. Tel: +94 11 2353353,
email: DigitalBanking@combank.net, All rights reserved
"""

# proof online 2.jpeg: ComBank Flash app. The date/time wraps onto a second line in the app.
COMBANK_FLASH = """flash
Reference Number: WT33426219
From Account: 8028556219
To Account 8026328795
To Bank COMMERCIAL BANK
To Branch -
Transaction Amount : LKR 51,000.00
Beneficiary Name Athayee Kampu
Transaction Date/Time 2026-09-24/22:01:2
9
Status : Completed
Description/Reason : lap
COMMERCIAL BANK
Download Share
"""

# proof.jpeg: People's Bank cash deposit slip (photo rotated 90 degrees).
# The validation-stamp minute is 43 or 44 on the photo; the owner reads 13:44:42. The account on the machine
# line is only partly legible. Handwritten fields are deliberately omitted (untrusted).
PEOPLES_DEPOSIT = """PEOPLE'S BANK Deposit Slip Customer Copy Form No213 DP
1HC-203-02/ 2655931 201 2111 28AUG2026 13:44:42
CASH LKR 7,500.00 CR
065-2-002-?-00??90 MR ATHAYEA RASOOL LKR 7,500.00 CR
1.000000 1.000000
EFF.DATE 28AUG2026
"""

SMS_A = "Credit for Rs. 5,000.00 to 8026328795 at 16:18 at DIGITAL BANKING DIVISION"
SMS_B = ("Dear Sir/Madam, Your A/C 065-2002****90 has been Credited by Rs. 7500.00(Cash Depo. @13:44 28/08/2026)."
         "[Av_Bal: Rs. 36222.13 at SMS generated]")
SMS_C_SYNTHETIC = "Credit for Rs. 51,000.00 to 8026328795 at 22:01 at DIGITAL BANKING DIVISION"


def combank_sms(amount: str, hhmm: str, account: str = "8026328795", kind: str = "Credit") -> str:
    prep = "to" if kind == "Credit" else "from"
    return f"{kind} for Rs. {amount} {prep} {account} at {hhmm} at DIGITAL BANKING DIVISION"


def peoples_sms(amount: str, hhmm: str, ddmmyyyy: str, balance: str = "36222.13") -> str:
    return (f"Dear Sir/Madam, Your A/C 065-2002****90 has been Credited by Rs. {amount}(Cash Depo. @{hhmm} "
            f"{ddmmyyyy}).[Av_Bal: Rs. {balance} at SMS generated]")
