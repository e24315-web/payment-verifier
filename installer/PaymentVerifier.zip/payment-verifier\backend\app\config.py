"""Tunable thresholds. Every value here affects the safety/automation trade-off, so each is documented."""
from __future__ import annotations

import os
from dataclasses import dataclass


def _env_int(name: str, default: int) -> int:
    return int(os.getenv(name, default))


def _env_float(name: str, default: float) -> float:
    return float(os.getenv(name, default))


@dataclass(frozen=True)
class RulesConfig:
    # A payment timestamped up to this many minutes BEFORE order creation goes to review instead of
    # being rejected (customer may pay the instant the bot sends bank details, before the order row).
    old_payment_grace_min: int = 10
    # Minimum per-field confidence for the fields the decision depends on.
    min_time_conf: float = 0.90   # time is THE confirmation key, so strictest
    min_amount_conf: float = 0.85
    min_account_conf: float = 0.85
    # WRONG_ACCOUNT is a hard rejection, so only fire it when we are very sure we read the account.
    wrong_account_reject_conf: float = 0.90
    # Overall confidence needed to auto-approve.
    approve_min_conf: float = 0.85
    # Another unclaimed same-amount credit on the same account within this many minutes of the
    # chosen SMS makes the match ambiguous (two customers paying the same amount at nearly the same time).
    isolation_window_min: int = 2
    # Same account+amount SMS within this window but outside the match window = time conflict.
    conflict_window_min: int = 30
    # Slip time more than this far in the future (vs now) is impossible -> suspicious.
    future_tolerance_min: int = 5
    # WAITING_FOR_SMS escalates to human review after this long.
    sms_wait_ttl_min: int = 120
    # No SMS at all for this long -> feed considered stale.
    sms_feed_stale_hours: int = 6


def load_rules_config() -> RulesConfig:
    return RulesConfig(
        old_payment_grace_min=_env_int("PV_OLD_PAYMENT_GRACE_MIN", 10),
        min_time_conf=_env_float("PV_MIN_TIME_CONF", 0.90),
        min_amount_conf=_env_float("PV_MIN_AMOUNT_CONF", 0.85),
        min_account_conf=_env_float("PV_MIN_ACCOUNT_CONF", 0.85),
        wrong_account_reject_conf=_env_float("PV_WRONG_ACCOUNT_REJECT_CONF", 0.90),
        approve_min_conf=_env_float("PV_APPROVE_MIN_CONF", 0.85),
        isolation_window_min=_env_int("PV_ISOLATION_WINDOW_MIN", 2),
        conflict_window_min=_env_int("PV_CONFLICT_WINDOW_MIN", 30),
        future_tolerance_min=_env_int("PV_FUTURE_TOLERANCE_MIN", 5),
        sms_wait_ttl_min=_env_int("PV_SMS_WAIT_TTL_MIN", 120),
        sms_feed_stale_hours=_env_int("PV_SMS_FEED_STALE_HOURS", 6),
    )


ENGINE_VERSION = "rules-2026.09.28-1"
