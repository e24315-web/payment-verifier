"""Tiered slip extraction.

  T0  cache      identical bytes (SHA-256) seen before -> stored extraction, zero OCR
  T1  tesseract  ~0.2 s/pass. Upright screenshots. Several renderings, merged field-by-field.
  T1b rapidocr   ~2 s/pass. Only if T1 did not get the critical fields. Tries rotations.
  T2  vision LLM pluggable, DISABLED (no API key). Hook: VisionExtractor.
  T3  human      anything still incomplete reaches staff as UNREADABLE_SLIP; they read and correct fields.

Every tier is logged (engine, rotation, rendering, template, latency, cost) in the ExtractionReport.
"""
from __future__ import annotations

import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from typing import Protocol

from PIL import Image

from app.config import RulesConfig
from app.domain.normalize import minute_key
from app.domain.slip_parsers import detect_template, extract_slip
from app.domain.types import FieldValue, Flag, Severity, SlipExtraction, SlipType
from app.imaging.images import assess_quality, exif_flags, load_image, ocr_variants, perceptual_hash, sha256_bytes
from app.imaging.ocr import OcrDoc, OcrEngine, TesseractEngine

CRITICAL = ("amount_cents", "txn_at", "receiving_account")


class VisionExtractor(Protocol):
    """T2/T3 hook: returns field values as validated structured data. Never makes decisions."""
    name: str

    def extract(self, im: Image.Image, hint_template: str | None) -> tuple[SlipExtraction | None, dict]:
        ...


@dataclass
class Attempt:
    tier: str
    engine: str
    rotation: int
    rendering: str
    template: str
    template_score: int
    fields: list[str]
    latency_ms: int

    def to_dict(self) -> dict:
        return vars(self)


@dataclass
class ExtractionReport:
    sha256: str
    phash: str
    extraction: SlipExtraction
    tier: str                       # most expensive tier that ran: CACHE | T1 | T1b | T2 | NONE
    attempts: list[Attempt] = field(default_factory=list)
    tiers_run: list[str] = field(default_factory=list)
    result_tier: str | None = None  # tier whose extraction was used (+ '(incomplete->staff)')
    quality: dict = field(default_factory=dict)
    latency_ms: int = 0
    cost_usd: float = 0.0
    tokens_in: int = 0
    tokens_out: int = 0
    rotation: int = 0

    def to_dict(self) -> dict:
        return {
            "sha256": self.sha256, "phash": self.phash, "tier": self.tier, "result_tier": self.result_tier,
            "tiers_run": self.tiers_run, "rotation": self.rotation,
            "latency_ms": self.latency_ms, "cost_usd": self.cost_usd, "tokens_in": self.tokens_in,
            "tokens_out": self.tokens_out, "quality": self.quality,
            "attempts": [a.to_dict() for a in self.attempts], "extraction": self.extraction.to_dict(),
        }


# --------------------------------------------------------------------------- merging

def _vote_key(name: str, v):
    if isinstance(v, datetime):
        return minute_key(v)          # 22:01 and 22:01:29 agree at the minute (the confirmation key)
    return v


def merge_extractions(exs: list[SlipExtraction]) -> SlipExtraction:
    """Field-by-field consensus across OCR passes of the SAME image with the SAME template.

    * agreeing readings raise confidence a little (+0.03 per extra agreeing pass, max 0.99)
    * a disagreeing reading of a critical field scales confidence by its vote share; a tie drops the field
    * MEDIUM/HIGH flags survive only if at least half the passes raised them (one noisy pass must not
      create a fraud signal); LOW flags are kept if any pass raised them
    """
    if len(exs) == 1:
        return exs[0]
    base = exs[0]
    out = SlipExtraction(base.template, base.slip_type, raw_text="\n---\n".join(e.raw_text for e in exs))
    names = {k for e in exs for k in e.fields}
    for name in names:
        groups: dict = defaultdict(list)
        for e in exs:
            fv = e.fields.get(name)
            if fv is not None and fv.value is not None:
                groups[_vote_key(name, fv.value)].append(fv)
        if not groups:
            continue
        ranked = sorted(groups.values(), key=lambda g: (len(g), max(f.confidence for f in g)), reverse=True)
        top = ranked[0]
        total = sum(len(g) for g in ranked)
        if len(ranked) > 1 and len(ranked[1]) == len(top) and name in CRITICAL:
            out.flags.append(Flag("OCR_DISAGREEMENT", Severity.LOW,
                                  f"{name}: passes disagree ({[str(g[0].value) for g in ranked]})"))
            continue
        best = max(top, key=lambda f: (getattr(f.value, "second", 0) != 0, f.confidence))  # prefer value with seconds
        conf = max(f.confidence for f in top)
        if len(ranked) == 1:
            conf = min(0.99, conf + 0.03 * (len(top) - 1))
        elif name in CRITICAL:
            conf *= len(top) / total
            out.flags.append(Flag("OCR_DISAGREEMENT", Severity.LOW,
                                  f"{name}: minority reading(s) {[str(g[0].value) for g in ranked[1:]]}"))
        out.fields[name] = FieldValue(best.value, conf, best.raw, best.source)

    counts: dict[str, list[Flag]] = defaultdict(list)
    for e in exs:
        for f in {f.code: f for f in e.flags}.values():
            counts[f.code].append(f)
    for code, fl in counts.items():
        if fl[0].severity == Severity.LOW or len(fl) * 2 >= len(exs):
            out.flags.append(fl[0])
    return out


def best_per_field(a: SlipExtraction, b: SlipExtraction) -> SlipExtraction:
    """Combine two readings of the same unknown-layout image: highest-confidence value per field, union of flags."""
    out = SlipExtraction(a.template, a.slip_type if a.slip_type != SlipType.UNKNOWN else b.slip_type,
                         raw_text=a.raw_text + "\n---\n" + b.raw_text)
    for k in set(a.fields) | set(b.fields):
        fa, fb = a.fields.get(k), b.fields.get(k)
        out.fields[k] = max((f for f in (fa, fb) if f is not None),
                            key=lambda f: (round(f.confidence, 2), len(str(f.value))))   # tie -> fuller reading
    out.flags = list({f.code: f for f in a.flags + b.flags}.values())
    return out


# --------------------------------------------------------------------------- pipeline

def is_complete(ex: SlipExtraction, cfg: RulesConfig) -> bool:
    if ex.template == "generic":
        return False
    ok = ex.conf("amount_cents") >= cfg.min_amount_conf and ex.conf("txn_at") >= cfg.min_time_conf
    if ex.slip_type != SlipType.CASH_DEPOSIT:
        ok = ok and ex.conf("receiving_account") >= cfg.min_account_conf
    return ok


def _score(ex: SlipExtraction) -> float:
    return sum(ex.conf(k) for k in CRITICAL) + 0.1 * len(ex.fields)


class SlipExtractor:
    def __init__(self, engines: list[OcrEngine], cfg: RulesConfig, vision: VisionExtractor | None = None):
        self.engines = engines
        self.cfg = cfg
        self.vision = vision

    def _run_engine(self, eng: OcrEngine, im: Image.Image, tier: str, rotations: list[int],
                    attempts: list[Attempt]) -> tuple[SlipExtraction | None, int]:
        """Returns the best merged extraction over rotations for this engine."""
        best, best_rot = None, 0
        renderings = ocr_variants if isinstance(eng, TesseractEngine) else (lambda i: [("rgb", i)])
        for rot in rotations:
            img = im.rotate(rot, expand=True) if rot else im
            docs: list[tuple[str, OcrDoc]] = []
            for rname, r in renderings(img):
                docs.append((rname, eng.read(r)))
            # One template for all renderings: the one the most informative rendering points at.
            tpl, score = max((detect_template(d.text) for _, d in docs), key=lambda ts: ts[1])
            exs = []
            for rname, d in docs:
                ex = extract_slip(d, template=tpl.name)
                attempts.append(Attempt(tier, eng.name, rot, rname, tpl.name, detect_template(d.text)[1],
                                        sorted(k for k in ex.fields), d.latency_ms))
                if ex.fields:
                    exs.append(ex)
            if not exs:
                continue
            merged = merge_extractions(exs)
            if best is None or _score(merged) > _score(best):
                best, best_rot = merged, rot
            if score > 0 and is_complete(merged, self.cfg):
                break
        return best, best_rot

    def extract_bytes(self, data: bytes) -> ExtractionReport:
        t0 = time.perf_counter()
        im = load_image(data)
        sha = sha256_bytes(data)
        q = assess_quality(im)
        report = ExtractionReport(sha, perceptual_hash(im), SlipExtraction("generic", SlipType.UNKNOWN), "NONE",
                                  quality=q.to_dict())
        attempts: list[Attempt] = []
        best: SlipExtraction | None = None

        for i, eng in enumerate(self.engines):
            tier = "T1" if i == 0 else "T1b"
            report.tiers_run.append(tier)
            # Tesseract only reads upright text: a confident template match, or several fields read, proves it.
            upright_proven = any(a.tier == "T1" and a.rotation == 0 and (a.template_score >= 3 or len(a.fields) >= 4)
                                 for a in attempts)
            if i == 0:
                rotations = [0]            # cheap tier: upright only (screenshots, the common case)
            elif upright_proven:
                # Tesseract only recognises upright text, so a confident template match already proves the
                # orientation. Rotating cannot recover a field that was cropped out (was 25 s wasted, DEBUGGING #8).
                rotations = [0]
            else:
                rotations = [0, 90, 270, 180]
                # Orientation detection costs seconds, so it only runs once the cheap tier has failed, and
                # only a confident answer reorders the tries (it was wrong at conf 0.46 on the real slip).
                tess = next((e for e in self.engines if isinstance(e, TesseractEngine)), None)
                hint = tess.orientation_hint(im) if tess else None
                if hint and hint[1] >= 2.0:
                    rotations = [hint[0]] + [r for r in rotations if r != hint[0]]
            ex, rot = self._run_engine(eng, im, tier, rotations, attempts)
            if ex is not None and best is not None and ex.template == "generic" and best.template == "generic":
                # Unknown layout read by both engines: keep the more confident reading of EACH field
                # (e.g. RapidOCR reads handwriting better, Tesseract the printed labels).
                ex = best_per_field(best, ex)
            if ex is not None and (best is None or _score(ex) >= _score(best)):
                best, report.rotation, report.result_tier = ex, rot, tier
            if best is not None and is_complete(best, self.cfg):
                break

        if self.vision is not None and (best is None or not is_complete(best, self.cfg)):
            vex, meta = self.vision.extract(im, best.template if best else None)
            report.cost_usd += meta.get("cost_usd", 0.0)
            report.tokens_in += meta.get("tokens_in", 0)
            report.tokens_out += meta.get("tokens_out", 0)
            report.tiers_run.append("T2")
            if vex is not None:
                best, report.result_tier = vex, "T2"

        ex = best or SlipExtraction("generic", SlipType.UNKNOWN)
        for issue in q.issues:
            ex.flags.append(Flag(f"IMAGE_{issue}", Severity.LOW, f"image quality: {issue.lower()}"))
        ex.flags.extend(exif_flags(data))
        report.extraction = ex
        report.attempts = attempts
        # `tier` = the most expensive tier that RAN (what it cost); `result_tier` = the tier whose reading was used.
        report.tier = report.tiers_run[-1] if report.tiers_run else "NONE"
        if not is_complete(ex, self.cfg):
            report.result_tier = f"{report.result_tier or 'NONE'}(incomplete->staff)"
        report.latency_ms = int((time.perf_counter() - t0) * 1000)
        return report
