"""One command to run everything:  python run.py

  --reset   delete the local database and uploads first
  --port    default 8000

Creates the database, seeds the business accounts, builds the UI if needed (and Node is installed), and serves
API + UI on http://127.0.0.1:8000
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
FRONTEND = HERE.parent / "frontend"


def build_ui() -> None:
    dist = FRONTEND / "dist" / "index.html"
    if dist.exists() or not (FRONTEND / "package.json").exists():
        return
    npm = shutil.which("npm")
    if not npm:
        print("! UI not built and npm not found: API only. (Install Node, or use the prebuilt frontend/dist.)")
        return
    print("Building UI (first run only)...")
    subprocess.run([npm, "install", "--no-audit", "--no-fund"], cwd=FRONTEND, check=True, shell=os.name == "nt")
    subprocess.run([npm, "run", "build"], cwd=FRONTEND, check=True, shell=os.name == "nt")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--reset", action="store_true")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--demo-start", default="", help='demo clock, e.g. "2026-09-26T16:10:00" (Asia/Colombo)')
    args = ap.parse_args()
    os.chdir(HERE)
    sys.path.insert(0, str(HERE))
    if args.demo_start:
        os.environ["PV_DEMO_START"] = args.demo_start
    if args.reset:
        for p in ("payment_verifier.db", "payment_verifier.db-wal", "payment_verifier.db-shm"):
            Path(p).unlink(missing_ok=True)
        shutil.rmtree("uploads", ignore_errors=True)

    from datetime import datetime

    from app.clock import OffsetClock, SystemClock
    from app.db.session import init_db, make_engine, make_session_factory
    from app.seed import seed_business
    from app.settings import Settings

    settings = Settings()
    engine = make_engine(settings.database_url)
    init_db(engine)
    s = make_session_factory(engine)()
    seed_business(s, OffsetClock(datetime.fromisoformat(settings.demo_start)) if settings.demo_start else SystemClock())
    s.close()
    engine.dispose()

    build_ui()
    import uvicorn
    print(f"\n  Payment Verifier running:  http://{args.host}:{args.port}   (API docs: /docs)\n")
    uvicorn.run("app.main:create_app", factory=True, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
