"""Bank SMS ingestion: store raw, dedupe, parse, map to a business account, balance-chain check, then
re-evaluate pending submissions (SMS may arrive after the slip).

The same function backs every source (signed webhook from the Android forwarder, manual paste, CSV upload,
simulator); `source` is recorded so staff can see which SMS were typed in by a person.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import datetime

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.clock import Clock
from app.config import RulesConfig
from app.db.models import BusinessAccount, SmsMessage
from app.domain.normalize import accounts_compatible, format_rs
from app.domain.sms_parsers import parse_sms
from app.services.verification import account_views, audit, reevaluate_pending


@dataclass
class IngestResult:
    sms: SmsMessage
    created: bool
    reevaluated: list[int] = field(default_factory=list)


def normalize_sender(sender: str | None) -> str:
    s = (sender or "").upper().replace(" ", "").replace("-", "")
    return s[1:] if s.startswith("+") else s


def accounts_for_sender(session: Session, business_id: int, sender: str | None) -> set[int]:
    s = normalize_sender(sender)
    if not s:
        return set()
    return {a.id for a in session.scalars(select(BusinessAccount).where(BusinessAccount.business_id == business_id)).all()
            if any(normalize_sender(x) == s for x in (a.sms_senders or []))}


def sender_allowlist(session: Session, business_id: int) -> list[str]:
    """All SMS senders configured on the business's accounts (the UI's 'SMS numbers' per bank account)."""
    out = []
    for a in session.scalars(select(BusinessAccount).where(BusinessAccount.business_id == business_id)).all():
        out.extend(normalize_sender(x) for x in (a.sms_senders or []) if x)
    return out


def content_hash(body: str) -> str:
    return hashlib.sha256(" ".join(body.split()).encode("utf-8")).hexdigest()


def _balance_check(session: Session, sms: SmsMessage) -> str | None:
    """previous Av_Bal + this credit should equal this Av_Bal. A gap means an SMS we never received
    (or an un-forwarded debit). Informational only: it never changes a decision."""
    if sms.balance_cents is None or sms.business_account_id is None or sms.txn_at is None:
        return None
    prev = session.scalar(
        select(SmsMessage).where(SmsMessage.business_account_id == sms.business_account_id,
                                 SmsMessage.balance_cents.is_not(None), SmsMessage.id != sms.id,
                                 SmsMessage.txn_at <= sms.txn_at)
        .order_by(SmsMessage.txn_at.desc(), SmsMessage.id.desc()).limit(1))
    if prev is None:
        return None
    signed = sms.amount_cents if sms.is_credit else -(sms.amount_cents or 0)
    expected = prev.balance_cents + (signed or 0)
    if expected != sms.balance_cents:
        return (f"balance gap: previous balance {format_rs(prev.balance_cents)} + this "
                f"{format_rs(signed or 0)} = {format_rs(expected)}, but SMS says {format_rs(sms.balance_cents)} "
                f"(missing SMS or un-forwarded debit)")
    return None


def ingest_sms(session: Session, business_id: int, body: str, received_at: datetime, clock: Clock,
               cfg: RulesConfig, source: str = "manual", sender: str | None = None, device_id: str = "",
               actor: str = "system", reevaluate: bool = True) -> IngestResult:
    h = content_hash(body)
    existing = session.scalar(select(SmsMessage).where(SmsMessage.content_hash == h,
                                                       SmsMessage.received_at == received_at,
                                                       SmsMessage.device_id == device_id))
    if existing:
        return IngestResult(existing, False)

    parsed = parse_sms(body, received_at)
    sms = SmsMessage(business_id=business_id, source=source, sender=sender, device_id=device_id, body=body,
                     content_hash=h, received_at=received_at, created_at=clock.now(), issues=[])
    issues: list[str] = []
    if parsed is None:
        issues.append("no parser recognised this message")
    else:
        sms.parser = parsed.parser
        sms.is_credit = parsed.is_credit
        sms.amount_cents = parsed.amount_cents
        sms.account = parsed.account
        sms.txn_at = parsed.txn_at
        sms.date_source = parsed.date_source
        sms.reference = parsed.reference
        sms.balance_cents = parsed.balance_cents
        sms.channel = parsed.channel
        sms.parse_confidence = parsed.confidence
        issues.extend(parsed.issues)
        by_sender = accounts_for_sender(session, business_id, sender)
        if parsed.account:
            matches = [a for a in account_views(session, business_id) if accounts_compatible(parsed.account, a.account)]
            if len(matches) > 1 and by_sender:
                matches = [a for a in matches if a.id in by_sender] or matches   # sender disambiguates
            if len(matches) == 1:
                sms.business_account_id = matches[0].id
                if by_sender and matches[0].id not in by_sender:
                    issues.append(f"SMS from sender '{sender}' names an account configured under a different sender")
            elif len(matches) > 1:
                issues.append("account mask matches more than one business account")
            else:
                issues.append(f"account {parsed.account} is not a registered business account")
        elif len(by_sender) == 1:
            sms.business_account_id = next(iter(by_sender))
            issues.append("no account in SMS text; account taken from the configured sender")
    if source == "manual":
        issues.append("entered manually by staff (not from the phone forwarder)")
    session.add(sms)
    try:
        session.flush()
    except IntegrityError:
        session.rollback()
        existing = session.scalar(select(SmsMessage).where(SmsMessage.content_hash == h,
                                                           SmsMessage.received_at == received_at,
                                                           SmsMessage.device_id == device_id))
        return IngestResult(existing, False)
    if gap := _balance_check(session, sms):
        issues.append(gap)
    sms.issues = issues
    audit(session, clock, actor, "sms_ingested", "sms", sms.id,
          {"source": source, "parser": sms.parser, "credit": sms.is_credit, "issues": issues})
    session.commit()

    reevaluated: list[int] = []
    if reevaluate and sms.is_credit:
        reevaluated = reevaluate_pending(session, business_id, clock, cfg)
    return IngestResult(sms, True, reevaluated)
