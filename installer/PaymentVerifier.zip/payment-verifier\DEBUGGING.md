# Debugging log

Real problems hit while building, in the order they happened. Nothing here is invented.

---

## 1. A "Completed" slip sent after a "Pending" slip was stuck as a duplicate

**What failed.** `test_26_pending_or_scheduled_transfer_not_accepted` submitted two slips for the same order in a loop
(status PENDING, then SCHEDULED). The second came back `DUPLICATE_SUBMISSION` instead of `NOT_COMPLETED`.

**Why.** Duplicate detection for the same order keys on the canonical transaction identity (amount + minute + account).
A pending screenshot and the later completed screenshot of the *same* transfer have identical identity, so the second
slip inherited the first slip's result. In real use this means: customer sends "Pending" screenshot, gets told to
send the completed one, sends it, and is told "we already have this slip" forever. Same for an unreadable photo
followed by a clearer photo.

**How I found it.** The assertion message showed `DUPLICATE_SUBMISSION` on the loop's second iteration. The test itself
was slightly wrong (reusing one order), but thinking about *why* the engine said duplicate exposed the real-world
dead end.

**What changed.** `SUPERSEDABLE` in `app/domain/decision.py`: prior results a better slip can fix (`UNREADABLE_SLIP`,
`INCOMPLETE_SLIP`, `NOT_COMPLETED`, `ACCOUNT_UNCERTAIN`, `NEW_SLIP_REQUESTED`) no longer make a later slip a duplicate.
Results that a resubmission cannot fix (approved, rejected, waiting for SMS, suspicious) still do.
Added `test_26b` (pending then completed, now APPROVED) and `test_26c` (unreadable then clear, now APPROVED).

**Result.** Both new tests pass; the original duplicate tests (`test_10`, `test_17`) still pass, so exact
resubmissions are still short-circuited.

---

## 2. The race-condition test passed without ever racing

**What failed.** Nothing visibly: the concurrent double-claim test was green. That was the problem. I wanted evidence
that the `UNIQUE(claims.sms_id)` + retry path had actually been exercised.

**Why.** Two reasons:
1. The two threads effectively ran one after the other; the second always saw the first one's committed claim, so it
   was decided by normal matching logic, not by the database constraint.
2. `build_input` called `session.flush()` during evidence gathering, which takes SQLite's write lock. Even with
   perfect timing, the second thread would block on the lock instead of reaching the dangerous "both think the SMS
   is free" state.

**How I found it.** Instrumented `_apply` to count `IntegrityError`/`OperationalError` retries and ran the race tests
15 rounds: `RETRY EVENTS: {}`. Zero retries means the protection under test was never hit.

**What changed.**
- The read phase of an evaluation no longer writes (`session.no_autoflush`, no early flush). Concurrency safety
  comes from the unique constraint at write time, which is also how it will work on Postgres.
- New test `test_forced_interleaving_both_read_unclaimed_then_both_write` wraps `decide()` with a barrier so both
  threads have *decided to approve and claim SMS #1* before either writes. It then asserts the dangerous state
  was reached (two `APPROVED_PAID` decisions), a retry happened (three `decide` calls), and exactly one approval
  and one claim survived, with the winner marked contested.

**Result.** The test now proves the protection instead of assuming it. The loser ends REJECTED `ALREADY_USED` and
the winner is flagged for review. My first assertion expected the loser to be NEEDS_VERIFICATION; the engine's
answer (ALREADY_USED, per the decision table) was right and the test expectation was corrected.

---

## 3. Tesseract returned nothing at all on the dev machine

**What failed.** `tesseract receipt.jpeg -` printed an empty result for every image.

**Why.** `TESSDATA_PREFIX` pointed at `C:\Program Files\Tesseract-OCR\` but the language data lives in
`...\Tesseract-OCR\tessdata\`. Tesseract could not load `eng` and wrote the error to stderr, which my first
command had hidden with `2>$null`.

**How I found it.** Re-ran without discarding stderr: `Error opening data file ...\eng.traineddata`.

**What changed.** `app/imaging/ocr.py::_fix_tessdata_prefix` corrects the path for the app's own process when the
data is in the `tessdata` sub-folder (the user's global environment is left alone). Lesson kept: never hide stderr
while diagnosing.

**Result.** OCR works; the fix travels with the app instead of being a manual machine step.

---

## 4. One OCR rendering never gets every field of the Flash receipt

**What failed.** On the real Flash receipt, colour OCR read the labels but turned the time into `200 OO AEN`.
Grayscale read the time perfectly (`2026-09-24/22:01:2` + `9`) but the light-grey labels vanished completely, so
the label-based template found nothing.

**Why.** The labels are low-contrast grey; the timestamp sits on a shaded row and wraps onto two lines.

**How I found it.** A probe script ran each rendering x page-segmentation mode and printed the output side by side.

**What changed.**
- The pipeline OCRs several renderings and **merges field by field** (`merge_extractions`): agreement raises
  confidence, a disagreeing critical field is scaled down or dropped, and a MEDIUM/HIGH flag must be raised by at
  least half the passes (one noisy pass cannot invent a fraud signal).
- Self-identifying values (`yyyy-mm-dd/hh:mm:ss`, `LKR n,nnn.nn`) are also recognised without their label.

**Result.** Tesseract alone still did not reach the thresholds on Flash, but the second OCR tier (below) reads all
10 fields at 0.95; the merge logic is what makes the e-receipt reach 0.98-0.99 on the cheap tier.

---

## 5. The real deposit slip: wrong orientation, then unreadable by Tesseract

**What failed.** (a) Tesseract's orientation detector said "rotate 90" with confidence 0.46. Following it produced an
**upside-down** image. (b) At the correct rotation, Tesseract still read the teller stamp as `2eaug20cs` at every
scale, threshold and segmentation mode (36 combinations tried).

**Why.** Faint dot-matrix print, on a folded slip, photographed at an angle. Tesseract is built for clean scans.

**How I found it.** Saved the rotated image and looked at it. Then a grid probe over scale x preprocessing x PSM.

**What changed.**
- Orientation detection is only trusted at confidence >= 2, otherwise all four rotations are tried and the one
  whose text best fits a known template wins. It also only runs after the cheap upright pass fails (it was costing
  ~5 s on every clean screenshot).
- Benchmarked **RapidOCR** (local, free, ONNX): it read `28Aug2026 13:43:42` and `CASH LKH 7,500.00 DH` from the same
  photo. It became tier T1b, used only when Tesseract misses critical fields (~2 s vs ~0.2 s).
- Dot-matrix label confusions (LKR->LKH, CR->DH/CH, EFF.DATE->EHF.UAIE) are tolerated in *labels only*; digits
  are never "repaired".

**Result.** All three real images now extract every critical field correctly with zero API cost:
e-receipt on T1 (Tesseract, ~1.8 s), Flash and the deposit slip on T1b. RapidOCR read the stamp minute as **43**,
confirming the ambiguity noted in Phase 0; with the SMS at 13:44 this is the tested one-minute-lag case.

---

## 6. OCR confidently misread the year on a rotated copy of the deposit slip

**What failed.** The degradation test `peoples_deposit.jpeg/rot90` asserted "no critical field is confidently
wrong" and failed: `txn_at` read as **2028**-08-28 13:43 with confidence 0.93.

**Why.** On dot-matrix print 6 and 8 (and 6 and 0: `28Aug2020` also appeared in probe output) differ by a few dots.
OCR confidence does not capture that. A misread into the future only produces FUTURE_DATED (review), but a misread
into the *past* would have hard-REJECTED a genuine payer as OLD_PAYMENT. That is a false rejection, which the brief
asks us to measure.

**How I found it.** The safety assertion in the degradation test, which checks every confidently-read value against
ground truth rather than only checking the final decision.

**What changed.**
- New principle: **a hard rejection needs corroborated evidence.** Templates set `date_corroborated` when a second
  date on the slip agrees (ComBank "Payment Date"/"Generated at", People's Bank "EFF.DATE"; staff corrections count).
- OLD_PAYMENT rejects only if corroborated, otherwise `OLD_PAYMENT_UNCONFIRMED` (review).
- New decision-level test: seven degradations of the real deposit slip must never be REJECTED, and any APPROVED
  must have read amount and time correctly.

**Result.** All degradation tests pass. Scenario `test_19b` shows a single-date Flash receipt going to review, then
being rejected as OLD_PAYMENT once staff confirm the date. Cost of the change: old single-date slips now need a
human click instead of an automatic rejection. I think that trade is right.

---

## 7. Every first-time slip was logged as a free cache hit

**What failed.** Live smoke test over HTTP with real OCR: the very first slip ever sent came back with
`extraction_meta.tier = "CACHE"` and `latency_ms = 0`. The decision was correct, but the cost/latency log was wrong.

**Why.** WhatsApp routing extracts the image once to read the amount (used to pick the right order when a customer
has several open orders). That stored the result in the image cache. The submission step then extracted "again",
hit the cache, and recorded CACHE instead of the tier that actually ran.

**How I found it.** Printing the submission detail in the live smoke script; the API tests had never asserted the tier.

**What changed.** `submit_slip_image(..., pre_extracted=...)`: the router passes its extraction through, so an image
is extracted exactly once per new message. Regression assertions: first sight logs `T1`; a new message with the
same image logs `CACHE` with zero OCR calls.

**Result.** The cost report (Phase 5) now reflects real tier usage; without this fix it would have claimed near-100%
free cache hits.

---

## 8. A cropped slip took 26 seconds and was reported as the cheap tier

**What failed.** In the first evaluation run, case I10 (real e-receipt cropped to its top 30%, so no time) was logged
as tier `T1` (Tesseract, ~1 s) but took **25.9 s**. The cost report's T1 row showed a max of 25.9 s.

**Why.** Two separate faults.
1. *Wrong attribution:* `report.tier` recorded the tier whose reading was **used**. Tesseract's partial reading scored
   best, so the label stayed T1 even though RapidOCR had also run.
2. *Wasted work:* after T1 failed, T1b ran RapidOCR at all four rotations (~6 s each). But Tesseract had already
   recognised the e-receipt layout upright with high confidence, so the orientation was proven. The missing field
   was cropped out, and no rotation can recover it.

**How I found it.** The outlier in the cost table; printing per-case `tier / ocr_ms / attempts` from
`eval/results.json` showed 7 attempts on a "T1" case.

**What changed.**
- `tier` now means the most expensive tier that **ran** (the cost); `result_tier` is the one whose reading was used,
  suffixed `(incomplete->staff)` when nothing reached the thresholds.
- If Tesseract recognised the layout upright (template score ≥ 3), T1b only tries rotation 0. A sideways photo still
  gets the full search, because Tesseract cannot recognise its layout.
- Regression assertion in `test_cropped_slip_without_time_is_not_complete`.

**Result.** I10: 25.9 s → 4.2 s, correctly labelled `T1b`. The rotated real cash slip still finds rotation 90.
Decisions for all 53 evaluation cases are unchanged (0 false approvals, 0 false rejections).

---

## 9. A customer re-sending a slip after payment got "we couldn't find an open order"

**What failed.** While checking every step of the demo script against the running server, step 4 ("send the same
receipt again to show duplicate detection") would have replied *"We couldn't find an open order for you"* instead of
*"We have already received this payment slip"*.

**Why.** WhatsApp routing only considered orders that were still open (awaiting payment / partially paid). Once the
first slip was approved, the order was PAID, so the re-sent slip had nowhere to go and was never evaluated. The same
gap hit a real business rule: a payment arriving for an **expired or cancelled** order was ignored instead of being
recorded as a refund with the customer ID and hotline.

**How I found it.** Walking through the demo script against the code before publishing it, instead of assuming the
steps worked. The unit tests had covered duplicates at the service level, where the order is passed in directly,
not through the WhatsApp routing.

**What changed.** With no open order (and no order code in the caption), a slip is routed to the customer's most
recent order. The decision table then answers correctly: duplicate, `ORDER_ALREADY_PAID` or `ORDER_CLOSED` (refund due).
New API test `test_resend_after_order_is_paid_is_answered_as_duplicate`.

**Result.** Demo step 4 now replies with the duplicate message at zero OCR cost (image cache hit), verified on the
live demo server.

---

## 10. Slips from an unknown bank: OCR read them, the parser threw almost everything away

**What failed.** The owner tested two AI-generated cash-deposit slips ("Lanka Demo Bank" and an HNB-branded one). The
app answered "couldn't read the slip", and the review screen showed **no extracted fields at all**, just one bogus
`reference = ORDER`. It also took 18 s.

**Why.** Four separate causes, found by printing the raw OCR text next to the extraction:
1. OCR was fine: RapidOCR read `28/09/2026`, `25,000.00`, `XXXXXX1234`, `A. Kumar`, `LD202609280153`. But the
   **generic parser** expected each value directly after its label. On two-column forms the value lands elsewhere
   ("Account Number Test Books (Pvt) Ltd XXXXXX1234 500 100 50").
2. **Digits written one per box** ("1 2 3 4 1 2 3 4") were not recognised. My first fix then over-matched across the
   line break and produced `0123412345` from the neighbouring "100" and "50" rows.
3. At one rotation the words "Deposit Slip" + "Cash Depositor" were enough to classify the page as a **People's
   Bank** slip.
4. When both OCR engines produced a generic reading, the pipeline kept one engine's whole reading instead of the best
   value per field. And it searched all four rotations even though Tesseract had already read fields upright.

**What changed.**
- The generic parser finds values by their shape near their labels: Total amount (or the largest money-shaped number),
  date (and time if printed), masked or boxed account on one line, depositor name, transaction number, reference, bank
  name. A date with no time is kept as `txn_date` and flagged `NO_TIME_ON_SLIP`. A cash slip without a machine-printed
  teller stamp is flagged `NO_TELLER_VALIDATION`.
- People's Bank classification now requires the bank's name or its teller stamp.
- Generic readings from both engines are combined per field (highest confidence; ties go to the fuller reading), and
  several fields read upright by Tesseract prove the orientation.
- Decision reasons say *why*: "Slip layout not recognised (HATTON NATIONAL BANK)", "Cash slip without a teller stamp:
  every value is customer-written", "Amount read as Rs. 25,000.00 but confidence 0.66 is below 0.85", "Slip shows only
  a date, no transaction time".
- Regression tests built from the exact OCR text of both images.

**Result.** Both slips are now read almost completely (the HNB boxed date stays blank: OCR read it as "28 9 202", and
the parser does not guess), in ~6 s instead of 18 s. The decision is unchanged and correct: **needs a person**,
because the layout is unknown, there is no transaction time to match a bank SMS, and every value is handwritten.
The 53-case evaluation is unchanged (0 false approvals, 0 false rejections).
