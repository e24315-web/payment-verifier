# Payment Verifier: can I safely accept this payment?

A WhatsApp payment-slip verifier for Sri Lankan businesses. A customer orders on WhatsApp, the agent sends one of the
business's bank accounts, the customer pays and sends a photo or screenshot of the slip. The system decides
**APPROVED / REJECTED / NEEDS VERIFICATION**, explains why, tells the customer what to do next, and gives staff a
review screen.

**Core idea:** the slip is only the customer's *claim*. The **bank SMS** that arrives on the business phone is the
evidence. A payment is approved only when exactly one unclaimed bank credit matches the slip on **amount + business
account + transaction time (to the minute)**, and each credit can be used by only one order (enforced by the database).
Sri Lankan bank SMS carry the time but usually no reference, sender or even date, so time is the confirmation key and
amount alone never proves who paid.

| | |
|---|---|
| False approvals in evaluation | **0 of 53** labelled cases (10 through real OCR) |
| Automated tests | 229 (`python -m pytest`) |
| Paid API calls | none: local OCR only (Tesseract, then RapidOCR) |
| Setup | `python run.py` |

Docs: [Engineering report](docs/ENGINEERING_REPORT.md) · [Test report](docs/TEST_REPORT.md) ·
[Cost report](docs/COST_REPORT.md) · [Demo script](docs/DEMO_SCRIPT.md) · [Production at 100k/month](docs/PRODUCTION.md) ·
[Debugging log](DEBUGGING.md)

---

## Quick start

**Needs:** Python 3.11+ (developed on 3.13). **Tesseract 5** for the fast OCR tier
(Windows: [UB-Mannheim installer](https://github.com/UB-Mannheim/tesseract/wiki); Ubuntu: `apt install tesseract-ocr`).
Node.js only if you want to change the UI; the built UI is committed in `frontend/dist`.

```bash
python -m venv venv
venv\Scripts\activate            # Windows  (Linux/macOS: source venv/bin/activate)
pip install -r backend/requirements.txt
cd backend
python run.py                    # http://127.0.0.1:8000   (API docs: /docs)
```

`run.py` creates the SQLite database, seeds the business's two bank accounts, builds the UI if it is missing and Node
is available, and serves API + UI. `python run.py --reset` starts from an empty database.

**Demo mode** (replays the real sample slips, which are dated 26/09/2026, with a 10-minute payment window):

```bash
python run.py --reset --demo-start 2026-09-26T16:17:00
python ../tools/demo_seed.py              # in a second terminal: 8 scenarios through the real API
```

Then follow [docs/DEMO_SCRIPT.md](docs/DEMO_SCRIPT.md).

**Docker** (not built on the dev machine, which had no Docker): `docker build -t payment-verifier .` then
`docker run -p 8000:8000 -v pv-data:/data payment-verifier`.

**Tests and evaluation**

```bash
cd backend
python -m pytest                   # 229 tests, ~4 min (real OCR tests included)
python -m eval.run_eval            # writes docs/TEST_REPORT.md and docs/COST_REPORT.md
```

---

## How the business uses it

1. **Settings:** business name, hotline, time windows (10 min to pay, 10 min for a balance), and each bank account
   with its holder names and the **SMS sender numbers** its credit alerts come from.
2. **New order:** staff enter the customer's name, WhatsApp number, amount, and which account to send. The WhatsApp
   agent sends the account, the amount, the order code and the deadline.
3. The customer transfers and sends the slip. The bank SMS arrives from the business phone (before or after the slip).
4. The system decides and replies on WhatsApp:
   - paid in full on time: **approved**
   - paid less: amount applied, customer told the balance and given 10 more minutes; if not paid, the order is
     cancelled and the customer gets their **customer ID (e.g. C00012) and the hotline** for a refund
   - paid more: approved; customer ID + hotline for the refund of the excess
   - transfer after the deadline: order closed, money held as a refund due
5. **Payments to review:** anything uncertain, sorted by risk. Staff see the image next to the extracted fields, the
   Slip / Bank SMS / Order comparison, the reasons and warning flags, and act (approve with a note, reject, ask for a new
   slip, correct fields, link a bank SMS). Every action is in an append-only audit log.

---

## Architecture

```mermaid
flowchart LR
  WA[WhatsApp customer] -->|slip image| IN[Intake<br/>idempotent on message id]
  IN --> H{SHA-256<br/>seen before?}
  H -->|yes, cost 0| EX
  H -->|no| T1[T1 Tesseract<br/>3 renderings merged]
  T1 -->|critical fields missing| T1b[T1b RapidOCR<br/>+ rotation search]
  T1b -->|still missing| HUM[staff read the image]
  T1 --> EX[Slip extraction<br/>fields + confidence]
  T1b --> EX
  PH[Business phone] -->|signed webhook / paste / CSV| SMS[SMS parsers per bank]
  SMS --> DB[(SQLite / Postgres)]
  EX --> M[Matcher<br/>account + amount + minute]
  DB --> M
  M --> D[Decision table<br/>plain code, ordered rows]
  D --> C[Claim bank SMS<br/>UNIQUE per credit]
  C --> OUT[WhatsApp reply<br/>+ staff queue + audit]
  SMS -->|late SMS| M
```

- **Deterministic first.** The decision is plain, tested Python ([app/domain/decision.py](backend/app/domain/decision.py)).
  OCR (and, if ever enabled, an AI model) only *extracts fields*; nothing but the decision table decides.
- **Money is integer cents; time is timezone-aware** (Asia/Colombo), stored as UTC.
- **An injectable clock** everywhere makes every scenario reproducible in tests, and powers demo mode.

| Part | File(s) |
|---|---|
| Normalisation (amounts, account masks, O/0 in references, day-first / month-first dates, names) | `app/domain/normalize.py` |
| Bank SMS parsers (ComBank, People's Bank, generic), one class per bank | `app/domain/sms_parsers.py` |
| Slip templates (ComBank e-receipt, ComBank Flash, People's Bank deposit slip, generic) | `app/domain/slip_parsers.py` |
| Matcher (time/amount/account, lag, isolation, conflicts) | `app/domain/matching.py` |
| Decision table + reason codes + customer messages | `app/domain/decision.py`, `app/domain/reasons.py` |
| Image hashing, quality, OCR engines, tiered extraction with field merging | `app/imaging/` |
| Verification service (evidence gathering, atomic claim, re-evaluation), SMS ingestion, staff actions, jobs | `app/services/` |
| HTTP API and presenters | `app/api/` |
| React UI | `frontend/src/` |
| Evaluation harness | `backend/eval/` |

**Why this stack.** Python has the strongest local OCR and image tooling (Tesseract, RapidOCR/ONNX, Pillow,
imagehash) and FastAPI gives typed request validation for free. SQLite keeps setup to one command yet still enforces
the unique constraint that makes "one bank credit, one order" race-safe; the models are written for SQLAlchemy 2 and
move to Postgres by changing `PV_DATABASE_URL`. React + Vite + Tailwind gave the review screen (image zoom and rotate,
side-by-side comparison, dialogs) without a heavy framework; the build is committed so running it needs no Node.

---

## Verification approach

The decision table is evaluated top to bottom; the first row that fires decides. APPROVED is only reachable at the end.

| # | Row | Result |
|---|---|---|
| 1 | Same image or same transaction already submitted for this order | earlier result (duplicate, no reprocessing) |
| 2 | Amount or time unreadable, or online slip without its account | NEEDS VERIFICATION: ask for a clearer slip |
| 3 | Online slip paid to an account that is not the business's | REJECTED (only at ≥ 0.90 confidence; lower = review) |
| 4 | Transaction already used by another order | REJECTED `ALREADY_USED` (earlier approval flagged "contested") or review variants |
| 5 | Transaction before the order / in the future | REJECTED `OLD_PAYMENT` (needs a second date on the slip to agree) or review |
| 6 | Transfer status not Completed | NEEDS VERIFICATION |
| 7 | No bank SMS / several candidates / SMS disagrees | NEEDS VERIFICATION (waiting, ambiguous, conflict; feed-stale aware) |
| 8 | SMS matches but the slip has warning signs | NEEDS VERIFICATION, the SMS is **held** for this order |
| 9 | SMS matches but overall confidence < 0.85 | NEEDS VERIFICATION, SMS held |
| 10 | Transfer after the payment window / order already closed | REJECTED `LATE_PAYMENT`, money recorded as refund due |
| 11 | Amount vs balance due | APPROVED paid / underpaid (balance window starts) / overpaid (refund due) |

**Matching rules.** SMS minute − slip minute: `0` exact, `+1` accepted (SMS lag); anything else is a conflict, never an
approval. An SMS never precedes the transaction. A match is refused if another same-amount credit sits within ±2 minutes
on the same account ("two customers paid Rs 5,000 at the same time" goes to a person). ComBank SMS have no date, so the
date comes from when the phone received it (latest matching HH:MM before arrival; handles midnight).

**Confidence.** Every extracted field carries the OCR confidence of the exact characters it was read from, merged
across several renderings. Thresholds: time 0.90 (the confirmation key), amount 0.85, account 0.85.

**Customers never see internals.** Replies come only from templates with safe placeholders (their order, amounts,
customer ID, hotline). No SMS, matching, fraud or balance details; a test checks every outbound message.

---

## Fraud handling

| Attack | Defence |
|---|---|
| Same slip sent twice | SHA-256 per image and transaction identity per order: returns the earlier result |
| Slip reused for another customer / business order | transaction identity (amount + minute + account), folded reference (O/0, I/1), and the one-claim-per-SMS database rule |
| Same payment, different image (crop, recompress, photo of screen) | identity is the *transaction*, not the pixels; caught even with the reference cropped out |
| Edited amount / time / date | no SMS agrees: never approved; conflict flagged for review |
| Edited reference on a known slip | reference seen before with different details: flagged high-risk |
| Receipt "generated" before the transaction; Payment Date ≠ transaction date | template cross-checks: flagged |
| Old payment for a new order | time vs order creation, only rejected when a second date corroborates it |
| Pending / scheduled transfer screenshot | status check: held |
| Wrong beneficiary account | mask-aware account check against the business's accounts |
| Fake "credit" SMS injected | webhook HMAC with a replay window (or per-device token), registered devices, bank sender allowlist per account; manual SMS entries are labelled and audited |
| Two orders claiming one SMS at once | `UNIQUE(claims.sms_id)` + retry; proven by a forced-interleaving test |
| Fraudster claims a victim's payment first | the victim is not rejected: the earlier claim is flagged "contested" and both go to a person |
| New sender account / beneficiary name mismatch / edited-in-editor image | soft flags shown to staff |
| Missing SMS feed disguising non-payment | "SMS feed stale" banner and reason code |
| Balance of the business account (`Av_Bal`) | internal only; used to detect gaps in the SMS sequence, never shown to customers |

Forensic signals only **hold** a payment for review. They never approve and never reject by themselves.

---

## Bank SMS: getting them into the system

- **Automatic:** an SMS-forwarder app on the business phone POSTs each bank SMS to `/webhooks/sms`
  (`{"sender": "COMBANK", "body": "...", "received_at": "..."}`). Use HMAC signing when the app or script can compute
  it (see `tools/sms_forwarder_client.py`); off-the-shelf forwarder apps can use a per-device token header (weaker,
  documented). Only the sender IDs configured per account in Settings are accepted.
- **Manual:** paste an SMS or upload a CSV on the Bank SMS page (marked "manual" everywhere).
- A late SMS automatically re-checks every slip waiting for it. A slip still waiting after 2 hours escalates to staff.

## WhatsApp

The **WhatsApp simulator** page drives the same code path as the real channel. `/webhooks/whatsapp` implements Meta's
WhatsApp Cloud API webhook (verify handshake, `X-Hub-Signature-256`, idempotent on message id, media download via the
Graph API when `PV_WA_ACCESS_TOKEN` is set). Outbound replies are queued in `outbound_messages`; the sender for the
real API is not wired up in this prototype.

---

## Cost

No paid API is used. Measured on the real slips: Tesseract ~1.2 s per screenshot; the RapidOCR fallback ~5 s for
photos. That is roughly **$0.03 of server time per 1,000 submissions**, versus ≈ $3.31 (Claude Haiku 4.5) to
$16.53 (Claude Opus 5) per 1,000 if every slip went to an AI model. Exact re-sends cost nothing (hash cache). Details,
assumptions and where extra spend would be justified: [docs/COST_REPORT.md](docs/COST_REPORT.md).

---

## Configuration (environment variables)

| Variable | Default | Meaning |
|---|---|---|
| `PV_DATABASE_URL` | `sqlite:///./payment_verifier.db` | any SQLAlchemy URL (Postgres in production) |
| `PV_UPLOAD_DIR` | `./uploads` | where slip images are stored |
| `PV_STAFF_API_KEY` | empty (open) | shared key the UI must send; **set it outside local demos** |
| `PV_SMS_HMAC_SECRET` | empty | enables HMAC-signed SMS webhook |
| `PV_SMS_DEVICE_TOKENS` | empty | `device-id:token,...` for token-mode forwarders |
| `PV_SMS_SENDER_ALLOWLIST` | empty | extra allowed senders (normally set per account in Settings) |
| `PV_WA_VERIFY_TOKEN`, `PV_WA_APP_SECRET`, `PV_WA_ACCESS_TOKEN` | empty | WhatsApp Cloud API webhook |
| `PV_OCR_ENGINES` | `tesseract,rapidocr` | OCR tiers in order |
| `TESSERACT_CMD` | auto | path to `tesseract` if not on PATH |
| `PV_DEMO_START` | empty | demo clock start (Asia/Colombo) |
| `PV_JOB_INTERVAL_S` | 60 | how often expiry / escalation runs |
| `PV_MIN_TIME_CONF`, `PV_MIN_AMOUNT_CONF`, `PV_MIN_ACCOUNT_CONF`, `PV_APPROVE_MIN_CONF`, `PV_WRONG_ACCOUNT_REJECT_CONF` | 0.90, 0.85, 0.85, 0.85, 0.90 | confidence thresholds |
| `PV_ISOLATION_WINDOW_MIN`, `PV_CONFLICT_WINDOW_MIN`, `PV_OLD_PAYMENT_GRACE_MIN`, `PV_FUTURE_TOLERANCE_MIN` | 2, 30, 10, 5 | matching windows (minutes) |
| `PV_SMS_WAIT_TTL_MIN`, `PV_SMS_FEED_STALE_HOURS` | 120, 6 | escalation and feed-health timers |

---

## Known limitations

- **Three real slip samples** (one per layout). Other banks and app versions need a new template each, written from
  real samples. Unknown layouts fall back to a generic parser with low confidence, so they reach a person.
- **Real cash-slip photos often need one staff click.** The folded dot-matrix photo matched its SMS but finished at
  confidence 0.82, under the 0.85 auto-approve line. That is deliberate.
- **Residual risk:** someone who knows the exact amount, minute and account of another customer's credit and claims it
  first. Mitigated (contested flag, sender history), not eliminated. Without a bank API this cannot be closed fully.
- **Trust in the SMS feed:** a staff member can type a fake SMS. Manual entries are labelled and audited, not prevented.
- **Prototype scope:** one business per install (the data model supports more), a shared-key staff login, OCR runs
  inside the request (2–7 s), the WhatsApp reply sender is not connected, English replies only (Sinhala/Tamil
  templates not written), no moiré detector or pixel-level (ELA) forensics.
- **The People's Bank account is stored as the SMS mask** `065-2002****90` until the owner enters the full number (the
  real one is not legible on the sample slip). A masked account cannot be sent to customers.
- The Dockerfile has not been built (no Docker on the dev machine).

---

## Repository layout

```
backend/      FastAPI app (app/), tests (tests/), evaluation (eval/), run.py
frontend/     React UI (src/), committed build (dist/), sample slips (public/samples/)
tools/        demo seed, synthetic test-slip generator, SMS forwarder reference client
docs/         engineering report, test report, cost report, demo script, production notes
legacy/       the first prototype, kept for reference (not used)
DEBUGGING.md  real problems found while building, and how each was fixed
```
