"""Per-bank slip templates: OCR document -> SlipExtraction with per-field confidence.

Rules used throughout:
* Never guess. A value that does not parse cleanly is left empty (and flagged), not "repaired".
* Field confidence = template base x OCR confidence of the exact characters the value was read from.
* Cross-field consistency checks (payment date vs transaction date, generated-at vs transaction time)
  produce Flags, never decisions.
"""
from __future__ import annotations

import re
from datetime import datetime

from app.domain.normalize import (
    local_dt,
    normalize_account,
    parse_amount_cents,
    parse_date_dmony,
    parse_date_dmy,
    parse_date_iso,
    parse_date_mdy,
    parse_hm,
)
from app.domain.types import Flag, Severity, SlipExtraction, SlipType
from app.imaging.ocr import OcrDoc

_I = re.I


def _clean_line_value(v: str | None) -> str | None:
    if v is None:
        return None
    v = v.strip().strip(":").strip()
    return v or None


def _normalize_status(raw: str | None) -> str | None:
    if not raw:
        return None
    s = raw.strip().upper()
    if s in {"COMPLETED", "COMPLETE", "SUCCESS", "SUCCESSFUL"}:
        return "COMPLETED"
    return s


class _Ctx:
    """Helper bound to one document: regex search + confidence of matched groups."""

    def __init__(self, doc: OcrDoc, ocr_conf: float):
        self.doc, self.text, self.ocr_conf = doc, doc.text, ocr_conf

    def find(self, pattern: str, flags: int = _I) -> re.Match | None:
        return re.search(pattern, self.text, flags)

    def conf(self, m: re.Match, *groups: int, base: float = 0.95) -> float:
        spans = [m.span(g) for g in (groups or (0,)) if m.group(g) is not None]
        c = min((self.doc.span_conf(s, e) for s, e in spans), default=1.0)
        return base * c * self.ocr_conf


class SlipTemplate:
    name = "base"
    slip_type = SlipType.UNKNOWN

    def score(self, text: str) -> int:
        raise NotImplementedError

    def parse(self, doc: OcrDoc, ocr_conf: float = 1.0) -> SlipExtraction:
        raise NotImplementedError


# --------------------------------------------------------------------------- ComBank e-Receipt

class ComBankEReceipt(SlipTemplate):
    """'Transfer within ComBank' e-Receipt (online banking PDF/screenshot)."""
    name = "combank_ereceipt"
    slip_type = SlipType.ONLINE_TRANSFER

    def score(self, text: str) -> int:
        kws = (r"Transfer\s+within\s+ComBank", r"e-?Receipt", r"Beneficiary\s+Account\s+Number",
               r"Commercial\s+Bank", r"Bank\s+Reference\s+Number")
        s = sum(1 for kw in kws if re.search(kw, text, _I))
        return s if s >= 3 else 0

    def parse(self, doc: OcrDoc, ocr_conf: float = 1.0) -> SlipExtraction:
        x = _Ctx(doc, ocr_conf)
        ex = SlipExtraction(self.name, self.slip_type, raw_text=doc.text)
        ex.set("bank", "COMMERCIAL BANK", 0.95)

        # Real OCR splits this reference at a visual gap ('06000661 86696'), so allow inner spaces.
        if m := x.find(r"Bank\s+Reference\s+(?:Number|No\.?)\s*[:\-]?\s*([A-Z0-9](?:[A-Z0-9]| (?=[A-Z0-9])){6,24})"):
            ex.set("reference", m.group(1).replace(" ", "").upper(), x.conf(m, 1), m.group(1))
        if m := x.find(r"Sender.?s\s+Account\s+(?:Number|No\.?)\s*[:\-]?\s*([0-9Xx*\-]{4,24})\b"):
            ex.set("sender_account", normalize_account(m.group(1)), x.conf(m, 1), m.group(1))
        if m := x.find(r"Sender.?s\s+Name\s*[:\-]?\s*([^\n]+)"):
            ex.set("sender_name", _clean_line_value(m.group(1)), x.conf(m, 1, base=0.9), m.group(1))

        if m := x.find(r"Transfer\s+Amount\s*[:\-]?\s*(?:LKR\s*)?([^\s\n]+)"):
            cents = parse_amount_cents(m.group(1))
            if cents is None:
                ex.flags.append(Flag("AMOUNT_UNPARSEABLE", Severity.LOW, f"amount text '{m.group(1)}' is not a clean number"))
            ex.set("amount_cents", cents, x.conf(m, 1), m.group(1))
        if (m := x.find(r"Transfer\s+Currency\s*[:\-]?\s*([A-Z]{3})\b")) and m.group(1).upper() != "LKR":
            ex.flags.append(Flag("NON_LKR_CURRENCY", Severity.MEDIUM, f"currency {m.group(1)}"))

        if m := x.find(r"Beneficiary\s+Name\s*[:\-]?\s*([^\n]+)"):
            ex.set("beneficiary_name", _clean_line_value(m.group(1)), x.conf(m, 1, base=0.9), m.group(1))
        if m := x.find(r"Beneficiary(?:.?s)?\s+Account\s+(?:Number|No\.?)\s*[:\-]?\s*([0-9Xx*\-]{6,24})"):
            ex.set("receiving_account", normalize_account(m.group(1)), x.conf(m, 1), m.group(1))
        if m := x.find(r"Beneficiary.?s\s+Account\s+Narration[ \t]*[:\-]?[ \t]*([^\n]*)"):
            ex.set("narration", _clean_line_value(m.group(1)), x.conf(m, 1), m.group(1))

        txn_at = None
        if m := x.find(r"Transaction\s+Date\s*/?\s*Time\s*[:\-]?\s*(\d{1,2}/\d{1,2}/\d{4})\s+(\d{1,2}:\d{2}(?::\d{2})?\s*[AP]\.?M\.?)"):
            d, hm = parse_date_dmy(m.group(1)), parse_hm(m.group(2))
            if d and hm:
                txn_at = local_dt(d, hm[0], hm[1], hm[2])
                ex.set("txn_at", txn_at, x.conf(m, 1, 2), m.group(0))
                ex.set("txn_has_seconds", hm[2] is not None, 1.0)

        if (m := x.find(r"Payment\s+Date\s*[:\-]?\s*(\d{1,2}-\d{1,2}-\d{2,4})")) and txn_at:
            pd = parse_date_dmy(m.group(1))
            if pd and pd != txn_at.date() and x.conf(m, 1) >= 0.8:
                ex.flags.append(Flag("DATE_FIELDS_DISAGREE", Severity.MEDIUM,
                                     f"Payment Date {pd} differs from Transaction Date {txn_at.date()}"))
            elif pd == txn_at.date():
                ex.set("date_corroborated", True, x.conf(m, 1), "Payment Date agrees")

        if m := x.find(r"\bStatus\s*[:\-]?\s*([A-Za-z]+)"):
            ex.set("status", _normalize_status(m.group(1)), x.conf(m, 1), m.group(1))
        if m := x.find(r"e-?Receipt\s+Reference\s*[:\-]?\s*([A-Z0-9]{4}(?:-[A-Z0-9]{4}){3})"):
            ex.set("secondary_reference", m.group(1).upper(), x.conf(m, 1), m.group(1))

        # 'Generated at 9/26/26 4:18 PM' is MONTH-first, unlike the rest of the receipt.
        if m := x.find(r"Generated\s+at\s+(\d{1,2}/\d{1,2}/\d{2,4})\s+(\d{1,2}:\d{2}\s*[AP]M)"):
            gd, gh = parse_date_mdy(m.group(1)), parse_hm(m.group(2))
            if gd and gh:
                gen = local_dt(gd, gh[0], gh[1])
                ex.set("generated_at", gen, x.conf(m, 1, 2), m.group(0))
                if txn_at and gd == txn_at.date() and "date_corroborated" not in ex.fields:
                    ex.set("date_corroborated", True, x.conf(m, 1), "Generated-at date agrees")
                if txn_at and gen < txn_at.replace(second=0) and x.conf(m, 1, 2) >= 0.8:
                    ex.flags.append(Flag("GENERATED_BEFORE_TXN", Severity.HIGH,
                                         f"receipt generated {gen:%d/%m/%Y %H:%M} before transaction {txn_at:%d/%m/%Y %H:%M}"))
        return ex


# --------------------------------------------------------------------------- ComBank Flash app

class ComBankFlash(SlipTemplate):
    """ComBank 'Flash' mobile app transfer confirmation.

    Labels are light grey and vanish in some OCR renderings, so the self-identifying values (the
    'yyyy-mm-dd/hh:mm:ss' timestamp, 'LKR n,nnn.nn') are also recognised without their label."""
    name = "combank_flash"
    slip_type = SlipType.ONLINE_TRANSFER

    def score(self, text: str) -> int:
        kws = (r"\bf.?ash\b", r"From\s+Account", r"To\s+Account", r"To\s+Bank", r"Description\s*/\s*Reason",
               r"\b\d{4}-\d{2}-\d{2}/\d{1,2}:\d{2}")
        s = sum(1 for kw in kws if re.search(kw, text, _I))
        return s if s >= 3 else 0

    def parse(self, doc: OcrDoc, ocr_conf: float = 1.0) -> SlipExtraction:
        x = _Ctx(doc, ocr_conf)
        ex = SlipExtraction(self.name, self.slip_type, raw_text=doc.text)

        if m := x.find(r"Reference\s+Number\s*:?\s*([A-Z0-9]{6,20})\b"):
            ex.set("reference", m.group(1).upper(), x.conf(m, 1), m.group(1))
        if m := x.find(r"From\s+Account\s*:?\s*([0-9Xx*\-]{6,24})\b"):
            ex.set("sender_account", normalize_account(m.group(1)), x.conf(m, 1), m.group(1))
        if m := x.find(r"To\s+Account\s*:?\s*([0-9Xx*\-]{6,24})\b"):
            ex.set("receiving_account", normalize_account(m.group(1)), x.conf(m, 1), m.group(1))
        if (m := x.find(r"To\s+Bank\s*:?\s*([^\n]+)")) and (bank := _clean_line_value(m.group(1))):
            ex.set("bank", bank.upper(), x.conf(m, 1), m.group(1))

        m = x.find(r"Transaction\s+Amount\s*:?\s*(?:LKR\s*)?([^\s\n]+)")
        base = 0.95
        if not m:
            hits = list(re.finditer(r"\bLKR\s*([0-9][0-9,]*\.\d{2})\b", x.text, _I))
            m, base = (hits[0], 0.9) if len(hits) == 1 else (None, 0)
        if m:
            cents = parse_amount_cents(m.group(1))
            if cents is None:
                ex.flags.append(Flag("AMOUNT_UNPARSEABLE", Severity.LOW, f"amount text '{m.group(1)}' is not a clean number"))
            ex.set("amount_cents", cents, x.conf(m, 1, base=base), m.group(1))

        if m := x.find(r"Beneficiary\s+Name\s*:?\s*([^\n]+)"):
            ex.set("beneficiary_name", _clean_line_value(m.group(1)), x.conf(m, 1, base=0.9), m.group(1))

        # '2026-09-24/22:01:2' + '9' on the next line (the app wraps the seconds).
        ts = list(re.finditer(r"(\d{4}-\d{1,2}-\d{1,2})\s*/\s*(\d{1,2}):(\d{2})(?::(\d{1,2}))?(?:[ \t]*\n[ \t]*(\d)(?=\s|$))?",
                              x.text))
        if len(ts) == 1:
            m = ts[0]
            d = parse_date_iso(m.group(1))
            sec_txt = m.group(4)
            if sec_txt and len(sec_txt) == 1 and m.group(5):
                sec_txt += m.group(5)
            elif sec_txt and len(sec_txt) == 1:
                # RapidOCR puts the label row between the value and its wrapped digit:
                # '2026-09-24/22:01:2' / 'Transaction Date/Time' / '9'. Look two lines ahead for a lone digit.
                after = x.text[m.end():].split("\n")[1:4]
                lone = [ln.strip() for ln in after if re.fullmatch(r"\s*\d\s*", ln)]
                if len(lone) == 1:
                    sec_txt += lone[0]
            sec = int(sec_txt) if sec_txt and len(sec_txt) == 2 else None
            h, mi = int(m.group(2)), int(m.group(3))
            if d and 0 <= h <= 23 and 0 <= mi <= 59 and (sec is None or sec <= 59):
                ex.set("txn_at", local_dt(d, h, mi, sec), x.conf(m, 1, 2, 3), m.group(0))
                ex.set("txn_has_seconds", sec is not None, 1.0)

        if m := x.find(r"\bStatus\s*:?\s*([A-Za-z]+)"):
            ex.set("status", _normalize_status(m.group(1)), x.conf(m, 1), m.group(1))
        elif m := x.find(r"^\s*(Completed|Pending|Failed|Scheduled|Processing)\s*$", _I | re.M):
            ex.set("status", _normalize_status(m.group(1)), x.conf(m, 1, base=0.9), m.group(1))
        if m := x.find(r"Description\s*/\s*Reason[ \t]*:?[ \t]*([^\n]*)"):
            ex.set("narration", _clean_line_value(m.group(1)), x.conf(m, 1), m.group(1))
        return ex


# --------------------------------------------------------------------------- People's Bank deposit slip

class PeoplesBankDepositSlip(SlipTemplate):
    """People's Bank cash deposit slip (Form 213 DP).

    Only the teller-machine validation lines are trusted. Handwritten fields (name, account boxes, amount
    boxes, denominations) are written by the customer and ignored for the decision. There is no sender
    account and no bank reference on a cash slip.
    """
    name = "peoples_deposit_slip"
    slip_type = SlipType.CASH_DEPOSIT

    _stamp = r"(\d{2}\s?[A-Z]{3}\s?\d{4})\s+(\d{2}):(\d{2}):(\d{2})"

    def score(self, text: str) -> int:
        kws = (r"PEOPLE.?S\s+BANK", r"Deposit\s+Slip", r"Form\s*No\.?\s*213", r"CASH\s+LK[RH]", self._stamp,
               r"E[FH]F\.?\s*[DU]ATE", r"Cash\s+Depositor")
        s = sum(1 for kw in kws if re.search(kw, text, _I))
        # Generic words ("Deposit Slip") appear on every bank's form; require the bank's name or its teller stamp.
        if not (re.search(r"PEOPLE.?S\s+BANK", text, _I) or re.search(self._stamp, text, _I)):
            return 0
        return s if s >= 2 else 0

    def parse(self, doc: OcrDoc, ocr_conf: float = 1.0) -> SlipExtraction:
        x = _Ctx(doc, ocr_conf)
        ex = SlipExtraction(self.name, self.slip_type, raw_text=doc.text)
        ex.set("bank", "PEOPLE'S BANK", 0.9)

        stamp = x.find(self._stamp)
        if stamp:
            d = parse_date_dmony(stamp.group(1).replace(" ", ""))
            if d:
                h, mi, sec = int(stamp.group(2)), int(stamp.group(3)), int(stamp.group(4))
                if h <= 23 and mi <= 59 and sec <= 59:
                    ex.set("txn_at", local_dt(d, h, mi, sec), x.conf(stamp), stamp.group(0))
                    ex.set("txn_has_seconds", True, 1.0)
            ex.set("status", "COMPLETED", 0.9 * x.conf(stamp, base=1.0), "teller validation line present")
        else:
            ex.flags.append(Flag("NO_TELLER_VALIDATION", Severity.LOW,
                                 "no readable machine-printed teller validation line"))

        # Amount appears on several machine lines ('CASH LKR 7,500.00 CR' and '... LKR 7,500.00 CR').
        # Dot-matrix OCR confuses the LABEL letters (LKR->LKH, CR->DH/CH); only labels are relaxed, never digits.
        hits = list(re.finditer(r"LK[RH]\s*([0-9/|][0-9,O]*[.,]\d{2}|[0-9/|][0-9,O]*\.\d{2})\s*[CD][RH]\b", x.text, _I))
        clean = [(parse_amount_cents(h.group(1)), h) for h in hits]
        good = [(c, h) for c, h in clean if c is not None]
        if good and len({c for c, _ in good}) == 1:
            best_conf = max(x.conf(h, 1) for _, h in good)
            ex.set("amount_cents", good[0][0], best_conf if len(good) >= 2 else best_conf * 0.95,
                   ", ".join(h.group(1) for h in hits))
        elif good:
            ex.flags.append(Flag("AMOUNT_LINES_DISAGREE", Severity.HIGH,
                                 f"machine-printed amounts disagree: {[h.group(1) for h in hits]}"))
        elif hits:
            ex.flags.append(Flag("AMOUNT_UNPARSEABLE", Severity.LOW,
                                 f"machine-printed amount not readable: {[h.group(1) for h in hits]}"))

        # Account on the validation line is partially legible at best -> low confidence, never used to reject.
        if m := x.find(r"\b(\d{3}\s?-\s?\d\s?-\s?\d{3}\s?-\s?[0-9?]\s?-\s?[0-9?]{4,8})\b"):
            ex.set("receiving_account", normalize_account(m.group(1)), 0.6 * x.conf(m, 1, base=1.0), m.group(1))
        if m := x.find(r"\b(?:MR|MRS|MS|MISS)\.?\s+([A-Z][A-Z .]+?)\s+LKR\b", 0):
            ex.set("beneficiary_name", m.group(1).strip(), 0.7 * x.conf(m, 1, base=1.0), m.group(0))
        if m := x.find(r"^\s*([0-9A-Z]{2,4}-\d{2,4}-\d{2})\s*/?\s*(\d{5,8})\b", _I | re.M):
            ex.set("teller_sequence", f"{m.group(1)}/{m.group(2)}", 0.6 * x.conf(m, base=1.0), m.group(0))

        # EFF.DATE is a second machine-printed date. OCR reads it as 'EHF.UAIE 28AUg2026' on the real photo.
        if (m := x.find(r"E[FH]F\.?\s*[DU]A[TI]E\s*(\d{2}\s?[A-Z]{3}\s?\d{4})")) and ex.get("txn_at"):
            eff = parse_date_dmony(m.group(1).replace(" ", ""))
            if eff and eff == ex.get("txn_at").date():
                ex.set("date_corroborated", True, x.conf(m, 1), "EFF.DATE agrees")
            elif eff and x.conf(m, 1) >= 0.8:
                # Either may be an OCR misread of dot-matrix digits: disagreement means "don't trust the date".
                ex.flags.append(Flag("DATE_FIELDS_DISAGREE", Severity.LOW,
                                     f"EFF.DATE {eff} differs from validation stamp {ex.get('txn_at').date()}"))
        return ex


# --------------------------------------------------------------------------- generic fallback

class GenericSlip(SlipTemplate):
    """Unknown layout (a bank we have no template for).

    Reads whatever it can so staff see the fields pre-filled, but with a LOW base confidence on purpose: an unknown
    format is never auto-approved and always reaches a person. Values are found by their own shape (dates, amounts
    with decimals, masked accounts, long transaction numbers) near their labels, because on two-column forms OCR
    often puts the value far from its label.
    """
    name = "generic"
    slip_type = SlipType.UNKNOWN
    _money = r"(\d{1,3}(?:,\d{3})+\.\d{2}|\d{3,}\.\d{2})"

    def score(self, text: str) -> int:
        return 1

    def _after(self, x: _Ctx, label: str, value: str, span: int = 120, flags: int = _I) -> re.Match | None:
        """First `value` match within `span` characters after `label`."""
        lbl = x.find(label, flags)
        if not lbl:
            return None
        return re.compile(value, flags).search(x.text, lbl.end(), min(len(x.text), lbl.end() + span))

    def parse(self, doc: OcrDoc, ocr_conf: float = 1.0) -> SlipExtraction:
        x = _Ctx(doc, ocr_conf)
        text = x.text
        cash = bool(re.search(r"\bCASH\s+DEPOSIT\b|\bDeposit\s+Slip\b", text, _I))
        ex = SlipExtraction(self.name, SlipType.CASH_DEPOSIT if cash else SlipType.UNKNOWN, raw_text=text)
        base = 0.6

        if m := re.search(r"\b([A-Z][A-Za-z]+(?:\s+[A-Z][A-Za-z]+){0,3}\s+(?:Bank|BANK))\b", text):
            ex.set("bank", m.group(1).upper(), x.conf(m, 1, base=base), m.group(1))

        # Amount: prefer the Total, then an amount after Amount/LKR/Rs, then the largest money-shaped number.
        m = (self._after(x, r"\bTotal\b", self._money, 60)
             or x.find(r"(?:amount|LKR|Rs\.?)\s*[:\-]?\s*(?:LKR|Rs\.?)?\s*([0-9][0-9,]*\.\d{2})"))
        if not m:
            cands = [c for c in re.finditer(self._money, text) if parse_amount_cents(c.group(1))]
            m = max(cands, key=lambda c: parse_amount_cents(c.group(1)), default=None)
        if m:
            ex.set("amount_cents", parse_amount_cents(m.group(1)), x.conf(m, 1, base=base), m.group(1))

        # Date and time. A slip with a date but NO time cannot be matched to a bank SMS; record the date anyway.
        dt, mm = None, None
        if mm := x.find(r"(\d{1,2}\s*[/\-.]\s*\d{1,2}\s*[/\-.]\s*\d{4})\s*[, ]?\s*(\d{1,2}:\d{2}(?::\d{2})?\s*(?:[AP]M)?)"):
            d, hm = parse_date_dmy(re.sub(r"\s", "", mm.group(1))), parse_hm(mm.group(2))
            dt = local_dt(d, hm[0], hm[1], hm[2]) if d and hm else None
        elif mm := x.find(r"(\d{4}-\d{1,2}-\d{1,2})[ T/](\d{1,2}:\d{2}(?::\d{2})?)"):
            d, hm = parse_date_iso(mm.group(1)), parse_hm(mm.group(2))
            dt = local_dt(d, hm[0], hm[1], hm[2]) if d and hm else None
        if dt:
            ex.set("txn_at", dt, x.conf(mm, base=base))
        else:
            d, m = None, x.find(r"\b(\d{1,2}\s*/\s*\d{1,2}\s*/\s*\d{4})\b")
            if m:
                d = parse_date_dmy(re.sub(r"\s", "", m.group(1)))
            elif m := self._after(x, r"\bDate\b", r"((?:\d[\s|/.\-]{0,3}){8})", 60):
                # dates written one digit per box: "2 8 | 0 9 | 2 0 2 6"
                digits = re.sub(r"\D", "", m.group(1))
                d = parse_date_dmy(f"{digits[:2]}/{digits[2:4]}/{digits[4:8]}") if digits[4:6] == "20" else None
            if d:
                ex.set("txn_date", d.isoformat(), x.conf(m, 1, base=base), m.group(1))
                ex.flags.append(Flag("NO_TIME_ON_SLIP", Severity.LOW,
                                     f"slip shows a date ({d:%d/%m/%Y}) but no transaction time"))

        acc = r"([0-9Xx*][0-9Xx*\-]{4,22}[0-9])"
        # one digit per box on ONE line: "1 2 3 4 1 2 3 4" (not swallowing "100" / "50" from the next rows)
        boxed = r"(?<![0-9])((?:[0-9][ \t|]{1,4}){5,19}[0-9])(?![0-9])"
        if m := (self._after(x, r"(?:To|Beneficiary)\s+(?:A/C|Account)", acc, 60)
                 or self._after(x, r"\bAccount\s*(?:Number|No\.?)", acc, 90)
                 or self._after(x, r"\bAccount\s*(?:Number|No\.?)", boxed, 90)):
            norm = normalize_account(m.group(1))
            if norm and sum(ch.isdigit() for ch in norm) >= 4:
                ex.set("receiving_account", norm, x.conf(m, 1, base=base), m.group(1))

        if m := self._after(x, r"\bDepositor\s+Name\b", r"([A-Z][A-Za-z.]*(?![\w-])(?:\s+[A-Z][A-Za-z.]*(?![\w-])){0,3})",
                            40, 0):
            ex.set("sender_name", m.group(1).strip(), x.conf(m, 1, base=0.5), m.group(1))
        if m := self._after(x, r"\bTransaction\s*(?:No\.?|Number|ID)\b", r"\b([A-Z]{0,4}\d{8,20})\b", 120, 0):
            ex.set("reference", m.group(1), x.conf(m, 1, base=base), m.group(1))
        if m := self._after(x, r"\bRef(?:erence)?\b", r"\b([A-Z]{2,}[-/][A-Z0-9][A-Z0-9\-/]{2,28})\b", 120, 0):
            if "reference" in ex.fields:
                ex.set("narration", m.group(1), x.conf(m, 1, base=base), m.group(1))
            else:
                ex.set("reference", m.group(1), x.conf(m, 1, base=base), m.group(1))
        if m := x.find(r"\bStatus\s*[:\-]?\s*([A-Za-z]+)"):
            ex.set("status", _normalize_status(m.group(1)), x.conf(m, 1, base=base), m.group(1))
        if cash and not re.search(PeoplesBankDepositSlip._stamp, text, _I):
            ex.flags.append(Flag("NO_TELLER_VALIDATION", Severity.LOW,
                                 "cash slip without a machine-printed teller stamp: values are customer-written"))
        return ex


TEMPLATES: list[SlipTemplate] = [ComBankEReceipt(), ComBankFlash(), PeoplesBankDepositSlip()]
_GENERIC = GenericSlip()
_BY_NAME = {t.name: t for t in TEMPLATES + [_GENERIC]}


def detect_template(text: str) -> tuple[SlipTemplate, int]:
    best, best_score = _GENERIC, 0
    for t in TEMPLATES:
        sc = t.score(text)
        if sc > best_score:
            best, best_score = t, sc
    return best, best_score


def extract_slip(source: str | OcrDoc, ocr_conf: float = 1.0, template: str | None = None) -> SlipExtraction:
    doc = source if isinstance(source, OcrDoc) else OcrDoc(source)
    tpl = _BY_NAME[template] if template else detect_template(doc.text)[0]
    return tpl.parse(doc, ocr_conf)


def slip_from_fields(template: str, slip_type: SlipType, values: dict, source: str = "human",
                     confidence: float = 1.0) -> SlipExtraction:
    """Build an extraction from structured values (human correction, vision tier, or tests)."""
    ex = SlipExtraction(template, slip_type)
    for k, v in values.items():
        if k == "txn_at" and isinstance(v, str):
            v = datetime.fromisoformat(v)
        ex.set(k, v, confidence, source=source)
    return ex
