"""Generate SYNTHETIC test slips (ComBank e-receipt layout, always watermarked "TEST SLIP - NOT A REAL RECEIPT").

1) The fixed demo set used by tools/demo_seed.py:
    python tools/make_demo_slips.py                -> frontend/public/samples/test/*.jpg

2) Your own test slip (prints the matching bank SMS to paste into the simulator):
    python tools/make_demo_slips.py --amount 8,000 --time now
    python tools/make_demo_slips.py --amount 2,500 --time "26/09/2026 04:50 PM" --out my_slips/a.jpg
    python tools/make_demo_slips.py --amount 5,000 --time now --account 8026328799      # wrong account
    python tools/make_demo_slips.py --amount 5,000 --time now --status Pending          # not completed
    python tools/make_demo_slips.py --amount 5,000 --time now --blur 4                  # unclear photo
    python tools/make_demo_slips.py --amount 5,000 --time now --rotate 90               # sideways photo

--time now   = the RUNNING APP's current minute (works with the demo clock), from http://127.0.0.1:8000/api/health.
--time now+2 = two minutes after that.
"""
from __future__ import annotations

import argparse
import random
import re
from datetime import datetime, timedelta
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "frontend" / "public" / "samples" / "test"

SLIPS = [
    # file, reference, amount, time (dd/mm/yyyy hh:mm AM/PM), sender, sender account, narration, extra
    ("underpaid_3000_0419pm.jpg", "O600066190301", "3,000.00", "26/09/2026 04:19 PM", "MR NIMAL PERERA", "80******41", "order", {}),
    ("balance_5000_0424pm.jpg", "O600066190302", "5,000.00", "26/09/2026 04:24 PM", "MR NIMAL PERERA", "80******41", "balance", {}),
    ("edited_amount_20000_0420pm.jpg", "O600066190303", "20,000.00", "26/09/2026 04:20 PM", "MR SAMAN SILVA", "80******52", "", {}),
    ("unclear_5000_0420pm.jpg", "O600066190304", "5,000.00", "26/09/2026 04:20 PM", "MS DILANI FERNANDO", "80******63", "", {"blur": 5}),
    ("no_sms_4000_0421pm.jpg", "O600066190305", "4,000.00", "26/09/2026 04:21 PM", "MS PRIYA RAJ", "80******74", "", {}),
    ("overpaid_1800_0421pm.jpg", "O600066190306", "1,800.00", "26/09/2026 04:21 PM", "MR RUWAN DIAS", "80******85", "", {}),
]


def font(size: int) -> ImageFont.FreeTypeFont:
    for name in ("arial.ttf", "DejaVuSans.ttf", "LiberationSans-Regular.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


def render(ref, amount, when, sender, sender_acc, narration, extra) -> Image.Image:
    W, H = 904, 1100
    im = Image.new("RGB", (W, H), "white")
    d = ImageDraw.Draw(im)
    f, fb, ft = font(20), font(20), font(30)
    d.text((100, 40), "e-Receipt", font=font(17), fill="black")
    d.text((270, 30), "Transfer within ComBank", font=ft, fill="black")
    d.line((30, 78, W - 30, 78), fill="black", width=2)
    date_part, time_part = when.split(" ", 1)
    dd, mm, yyyy = date_part.split("/")
    rows = [
        ("Bank Reference Number", ref), ("Sender's Account Number", sender_acc), ("Sender's Name", sender),
        ("Transfer Amount", amount), ("Transfer Currency", "LKR"),
        ("Beneficiary Name", "MR MOHAMED RIZAN ATHAYEA RASOOL"), ("Beneficiary's Account Currency", "LKR"),
        ("Beneficiary Account Number", extra.get("account", "8026328795")),
        ("Beneficiary's Account Narration", narration or "-"),
        ("Transaction Date/Time", when), ("Payment Date", f"{dd}-{mm}-{yyyy[2:]}"),
        ("Status", extra.get("status", "Completed")),
    ]
    y = 105
    for label, value in rows:
        d.text((35, y), label, font=fb, fill="black")
        d.text((450, y), value, font=f, fill="black")
        y += 30
    d.text((30, y + 15), f"[e-Receipt Reference TEST-{ref[-4:]}-0000-0000]", font=font(16), fill="black")
    gen = f"{int(mm)}/{int(dd)}/{yyyy[2:]} {time_part.lstrip('0')}"
    d.rectangle((30, y + 45, W - 30, y + 75), fill=(238, 234, 220))
    d.text((35, y + 50), f"Generated at {gen}", font=font(17), fill=(90, 90, 90))
    # Watermark, away from the fields. Always present.
    d.text((60, H - 170), "TEST SLIP - NOT A REAL RECEIPT", font=font(46), fill=(200, 30, 30))
    d.text((60, H - 110), "Synthetic image generated for the payment-verifier demo", font=font(20), fill=(200, 30, 30))
    if extra.get("blur"):
        im = im.filter(ImageFilter.GaussianBlur(extra["blur"]))
    if extra.get("rotate"):
        im = im.rotate(extra["rotate"], expand=True, fillcolor="white")
    return im


def app_now(url: str) -> datetime:
    """The running app's clock (honours the demo clock). Falls back to this computer's time."""
    try:
        import httpx
        return datetime.fromisoformat(httpx.get(f"{url}/api/health", timeout=5).json()["now"]).replace(tzinfo=None)
    except Exception:
        print("! app not reachable, using this computer's clock")
        return datetime.now()


def parse_time(value: str, url: str) -> datetime:
    m = re.fullmatch(r"now([+-]\d+)?", value.strip().lower())
    if m:
        return app_now(url).replace(second=0, microsecond=0) + timedelta(minutes=int(m.group(1) or 0))
    return datetime.strptime(value.strip(), "%d/%m/%Y %I:%M %p")


def custom(args) -> None:
    t = parse_time(args.time, args.app)
    cents = int(round(float(args.amount.replace(",", "")) * 100))
    amount = f"{cents / 100:,.2f}"
    when = t.strftime("%d/%m/%Y %I:%M %p")
    ref = args.ref or f"O6000{random.randint(10**7, 10**8 - 1)}"
    extra = {k: v for k, v in (("account", args.account), ("status", args.status), ("blur", args.blur),
                               ("rotate", args.rotate)) if v}
    out = Path(args.out) if args.out else ROOT / "my_slips" / f"slip_{amount.replace(',', '')}_{t:%H%M}.jpg"
    out.parent.mkdir(parents=True, exist_ok=True)
    render(ref, amount, when, args.sender, "80******99", args.narration, extra).save(out, "JPEG", quality=90)
    sms_account = args.account or "8026328795"
    print(f"\nSlip written:  {out}")
    print(f"  amount {amount} | transfer {when} | to account {sms_account} | ref {ref}")
    print("\nMatching bank SMS (WhatsApp simulator -> 'Bank: simulate an SMS'):")
    print(f"  Text:        Credit for Rs. {amount} to {sms_account} at {t:%H:%M} at DIGITAL BANKING DIVISION")
    print(f"  Sender:      COMBANK")
    print(f"  Received at: {t:%d/%m/%Y} {(t + timedelta(seconds=40)):%I:%M %p}")
    print("\nSend the slip from the simulator with 'Send slip image...' as the customer who owns the order.")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--amount", help="e.g. 5,000 or 2500.50  (omit all options to build the demo set)")
    ap.add_argument("--time", default="now", help='"now", "now+2", "now-3" or "26/09/2026 04:50 PM"')
    ap.add_argument("--account", help="beneficiary account (default: the business's ComBank 8026328795)")
    ap.add_argument("--status", help="transfer status (default Completed), e.g. Pending, Scheduled")
    ap.add_argument("--ref", help="bank reference (default: random)")
    ap.add_argument("--sender", default="MR TEST CUSTOMER")
    ap.add_argument("--narration", default="")
    ap.add_argument("--blur", type=int, help="blur radius, e.g. 4 (unreadable photo)")
    ap.add_argument("--rotate", type=int, help="degrees, e.g. 90")
    ap.add_argument("--out", help="output file (default my_slips/...)")
    ap.add_argument("--app", default="http://127.0.0.1:8000", help="running app, for --time now")
    args = ap.parse_args()
    if args.amount:
        custom(args)
        return
    OUT.mkdir(parents=True, exist_ok=True)
    for name, *rest in SLIPS:
        render(*rest).save(OUT / name, "JPEG", quality=90)
        print("wrote", OUT / name)


if __name__ == "__main__":
    main()
