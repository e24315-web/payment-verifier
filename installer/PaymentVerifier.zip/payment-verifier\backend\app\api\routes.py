"""HTTP API. Staff endpoints under /api, machine webhooks under /webhooks."""
from __future__ import annotations

import csv
import io
import json
from datetime import datetime, timezone
from typing import Annotated

from fastapi import APIRouter, Depends, File, Form, Header, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse, PlainTextResponse
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.presenters import iso, needs_action, queue_item, risk_score, sms_view, submission_detail
from app.clock import LK_TZ
from app.db.models import (
    Business,
    BusinessAccount,
    Claim,
    Customer,
    Order,
    OutboundMessage,
    SmsMessage,
    Submission,
)
from app.domain.normalize import normalize_account, parse_amount_cents
from app.services import actions
from app.services.jobs import tick
from app.services.sms_auth import verify_sms_webhook
from app.services.sms_ingest import ingest_sms, sender_allowlist
from app.services.verification import audit, evaluate, feed_is_stale
from app.services.whatsapp import (
    GraphMediaFetcher,
    OrderError,
    create_order,
    handle_inbound_image,
    parse_cloud_webhook,
    random_message_id,
    verify_meta_signature,
)

router = APIRouter()


# --------------------------------------------------------------------------- dependencies

def state(request: Request):
    return request.app.state.pv


def db(request: Request):
    s = request.app.state.pv.session_factory()
    try:
        yield s
    finally:
        s.close()


def staff(request: Request, x_staff_key: Annotated[str | None, Header()] = None,
          x_staff_name: Annotated[str | None, Header()] = None) -> str:
    key = request.app.state.pv.settings.staff_api_key
    if key and x_staff_key != key:
        raise HTTPException(401, "staff key required")
    return f"staff:{(x_staff_name or 'staff').strip()[:40]}"


DB = Annotated[Session, Depends(db)]
Staff = Annotated[str, Depends(staff)]


def business(session: Session) -> Business:
    b = session.scalar(select(Business).order_by(Business.id))
    if b is None:
        raise HTTPException(409, "no business configured yet: POST /api/business first")
    return b


def parse_received_at(v) -> datetime:
    """ISO 8601 (naive = Asia/Colombo) or epoch seconds/milliseconds."""
    if v is None or v == "":
        return datetime.now(timezone.utc)
    if isinstance(v, (int, float)) or (isinstance(v, str) and v.isdigit()):
        n = float(v)
        return datetime.fromtimestamp(n / 1000 if n > 1e11 else n, tz=timezone.utc)
    dt = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    return dt if dt.tzinfo else dt.replace(tzinfo=LK_TZ)


# --------------------------------------------------------------------------- business setup

class BusinessIn(BaseModel):
    name: str
    whatsapp_number: str | None = None
    hotline: str | None = None
    payment_window_min: int | None = Field(10, ge=1, le=1440, description="minutes to pay after the account is sent; null = no limit")
    balance_window_min: int | None = Field(10, ge=1, le=1440, description="minutes to pay a balance after underpaying")


class AccountIn(BaseModel):
    bank: str
    account: str = Field(description="full number, or a mask like 065-2002****90")
    holder_names: list[str] = []
    sms_senders: list[str] = Field([], description="SMS sender numbers/IDs this account's alerts come from")
    is_active: bool = True


def account_out(a: BusinessAccount) -> dict:
    return {"id": a.id, "bank": a.bank, "account": a.display_account, "normalized": a.account_number,
            "holder_names": a.holder_names, "sms_senders": a.sms_senders or [], "is_active": a.is_active,
            "masked": "*" in a.account_number}


@router.get("/api/business")
def get_business(s: DB):
    b = s.scalar(select(Business).order_by(Business.id))
    if b is None:
        return None
    accs = s.scalars(select(BusinessAccount).where(BusinessAccount.business_id == b.id)).all()
    return {"id": b.id, "name": b.name, "whatsapp_number": b.whatsapp_number, "hotline": b.hotline,
            "payment_window_min": b.payment_window_min, "balance_window_min": b.balance_window_min,
            "accounts": [account_out(a) for a in accs]}


@router.put("/api/business")
def put_business(body: BusinessIn, s: DB, actor: Staff, request: Request):
    clock = state(request).clock
    b = s.scalar(select(Business).order_by(Business.id))
    if b is None:
        b = Business(name=body.name, created_at=clock.now())
        s.add(b)
    b.name, b.whatsapp_number, b.hotline = body.name, body.whatsapp_number, body.hotline
    b.payment_window_min, b.balance_window_min = body.payment_window_min, body.balance_window_min
    s.flush()
    audit(s, clock, actor, "business_saved", "business", b.id, body.model_dump())
    s.commit()
    return get_business(s)


@router.post("/api/accounts")
def add_account(body: AccountIn, s: DB, actor: Staff, request: Request):
    clock = state(request).clock
    b = business(s)
    norm = normalize_account(body.account)
    if not norm or sum(ch.isdigit() for ch in norm) < 4:
        raise HTTPException(422, "account needs at least 4 visible digits")
    a = BusinessAccount(business_id=b.id, bank=body.bank.strip(), account_number=norm,
                        display_account=body.account.strip(), holder_names=[h.strip() for h in body.holder_names if h.strip()],
                        sms_senders=[x.strip() for x in body.sms_senders if x.strip()], is_active=body.is_active)
    s.add(a)
    s.flush()
    audit(s, clock, actor, "account_added", "business_account", a.id, body.model_dump())
    s.commit()
    return account_out(a)


@router.patch("/api/accounts/{account_id}")
def update_account(account_id: int, body: AccountIn, s: DB, actor: Staff, request: Request):
    a = s.get(BusinessAccount, account_id)
    if a is None:
        raise HTTPException(404)
    before = account_out(a)
    a.bank, a.display_account = body.bank, body.account
    a.account_number = normalize_account(body.account)
    a.holder_names, a.is_active = body.holder_names, body.is_active
    a.sms_senders = [x.strip() for x in body.sms_senders if x.strip()]
    audit(s, state(request).clock, actor, "account_updated", "business_account", a.id, {"before": before})
    s.commit()
    return account_out(a)


# --------------------------------------------------------------------------- customers & orders

class OrderIn(BaseModel):
    customer_name: str
    phone: str
    amount: str = Field(description="e.g. '5000' or '5,000.00'")
    description: str | None = None
    account_id: int | None = Field(None, description="business account to send to the customer")


def order_out(s: Session, o: Order) -> dict:
    c = s.get(Customer, o.customer_id)
    acc = s.get(BusinessAccount, o.pay_to_account_id) if o.pay_to_account_id else None
    return {"id": o.id, "code": o.code, "customer": {"id": c.id, "code": c.code, "name": c.name, "phone": c.phone},
            "pay_to_account": {"id": acc.id, "bank": acc.bank, "account": acc.display_account} if acc else None,
            "description": o.description, "expected_cents": o.expected_cents, "paid_cents": o.paid_cents,
            "balance_due_cents": max(0, o.expected_cents - o.paid_cents), "status": o.status,
            "created_at": iso(o.created_at), "expires_at": iso(o.expires_at), "balance_due_by": iso(o.balance_due_by),
            "closed_reason": o.closed_reason,
            "submissions": s.scalar(select(func.count(Submission.id)).where(Submission.order_id == o.id))}


@router.post("/api/orders")
def post_order(body: OrderIn, s: DB, actor: Staff, request: Request):
    cents = parse_amount_cents(body.amount)
    if not cents or cents <= 0:
        raise HTTPException(422, "amount must be a positive number like 5000 or 5,000.00")
    try:
        o = create_order(s, state(request).clock, business(s).id, body.customer_name, body.phone, cents,
                         body.description, actor, body.account_id)
    except OrderError as e:
        raise HTTPException(422, str(e))
    return order_out(s, o)


@router.get("/api/orders")
def list_orders(s: DB, status: str | None = None, limit: int = 200):
    q = select(Order).order_by(Order.created_at.desc()).limit(limit)
    if status:
        q = q.where(Order.status == status)
    return [order_out(s, o) for o in s.scalars(q).all()]


def customer_out(s: Session, c: Customer) -> dict:
    return {"id": c.id, "code": c.code, "name": c.name, "phone": c.phone,
            "credit": actions.customer_credit(s, c.id), "refunds": actions.refund_summary(s, c.id)}


@router.get("/api/customers")
def list_customers(s: DB, q: str | None = None):
    out = [customer_out(s, c) for c in s.scalars(select(Customer).order_by(Customer.name)).all()]
    if q:   # hotline lookup by customer ID, phone or name
        ql = q.strip().lower()
        out = [c for c in out if ql in c["code"].lower() or ql in c["phone"] or ql in c["name"].lower()]
    return out


class RefundIn(BaseModel):
    amount: str
    note: str | None = None


@router.post("/api/customers/{customer_id}/refunds")
def refund(customer_id: int, body: RefundIn, s: DB, actor: Staff, request: Request):
    cents = parse_amount_cents(body.amount)
    if not cents:
        raise HTTPException(422, "amount must be a number like 1000 or 1,000.00")
    _act(actions.record_refund, s, state(request).clock, customer_id, cents, actor, body.note)
    return customer_out(s, s.get(Customer, customer_id))


# --------------------------------------------------------------------------- submissions (review queue)

@router.get("/api/submissions")
def list_submissions(s: DB, outcome: str | None = None, reason: str | None = None,
                     needs_action_only: bool = False, q: str | None = None, limit: int = 300):
    stmt = select(Submission).order_by(Submission.id.desc()).limit(limit)
    if outcome:
        stmt = stmt.where(Submission.outcome == outcome)
    if reason:
        stmt = stmt.where(Submission.reason_code == reason)
    items = [queue_item(s, x) for x in s.scalars(stmt).all()]
    if needs_action_only:
        items = [i for i in items if i["needs_action"]]
    if q:
        ql = q.lower()
        items = [i for i in items if ql in i["customer"]["name"].lower() or ql in i["order"]["code"].lower()
                 or ql in i["customer"]["phone"]]
    # needs-action first, then highest risk, then newest
    items.sort(key=lambda i: (not i["needs_action"], -i["risk"], -(i["id"])))
    return items


@router.get("/api/submissions/{sub_id}")
def get_submission(sub_id: int, s: DB):
    sub = s.get(Submission, sub_id)
    if sub is None:
        raise HTTPException(404)
    return submission_detail(s, sub)


@router.get("/api/submissions/{sub_id}/image")
def get_image(sub_id: int, s: DB):
    sub = s.get(Submission, sub_id)
    if sub is None or not sub.image_path:
        raise HTTPException(404)
    return FileResponse(sub.image_path)


class NoteIn(BaseModel):
    note: str | None = None


class ApproveIn(NoteIn):
    sms_id: int | None = None


class CashIn(NoteIn):
    amount: str


class CorrectionIn(NoteIn):
    fields: dict


def _act(fn, *a, **k):
    try:
        return fn(*a, **k)
    except actions.ActionError as e:
        raise HTTPException(e.status, str(e))


@router.post("/api/submissions/{sub_id}/approve")
def approve(sub_id: int, body: ApproveIn, s: DB, actor: Staff, request: Request):
    _act(actions.staff_approve, s, state(request).clock, sub_id, actor, body.note, body.sms_id)
    return submission_detail(s, s.get(Submission, sub_id))


@router.post("/api/submissions/{sub_id}/cash")
def cash(sub_id: int, body: CashIn, s: DB, actor: Staff, request: Request):
    _act(actions.record_cash, s, state(request).clock, sub_id, actor, parse_amount_cents(body.amount), body.note)
    return submission_detail(s, s.get(Submission, sub_id))


@router.post("/api/submissions/{sub_id}/reject")
def reject(sub_id: int, body: NoteIn, s: DB, actor: Staff, request: Request):
    _act(actions.staff_reject, s, state(request).clock, sub_id, actor, body.note)
    return submission_detail(s, s.get(Submission, sub_id))


@router.post("/api/submissions/{sub_id}/request-new-slip")
def new_slip(sub_id: int, body: NoteIn, s: DB, actor: Staff, request: Request):
    _act(actions.request_new_slip, s, state(request).clock, sub_id, actor, body.note)
    return submission_detail(s, s.get(Submission, sub_id))


@router.post("/api/submissions/{sub_id}/corrections")
def corrections(sub_id: int, body: CorrectionIn, s: DB, actor: Staff, request: Request):
    fields = dict(body.fields)
    if "amount" in fields:                       # UI convenience: '5,000.00' -> cents
        fields["amount_cents"] = parse_amount_cents(str(fields.pop("amount")))
    if fields.get("txn_at"):
        fields["txn_at"] = parse_received_at(fields["txn_at"]).isoformat()
    if fields.get("receiving_account"):
        fields["receiving_account"] = normalize_account(fields["receiving_account"])
    st = state(request)
    _act(actions.correct_fields, s, st.clock, st.cfg, sub_id, actor, fields, body.note)
    return submission_detail(s, s.get(Submission, sub_id))


@router.post("/api/submissions/{sub_id}/reevaluate")
def reevaluate(sub_id: int, s: DB, actor: Staff, request: Request):
    sub = s.get(Submission, sub_id)
    if sub is None:
        raise HTTPException(404)
    sub.decided_by = "system"
    audit(s, state(request).clock, actor, "reevaluate_requested", "submission", sub_id, None)
    s.commit()
    st = state(request)
    evaluate(s, sub_id, st.clock, st.cfg)
    return submission_detail(s, s.get(Submission, sub_id))


class CreditIn(NoteIn):
    claim_id: int
    order_id: int
    amount: str | None = None


@router.post("/api/credits/apply")
def apply_credit(body: CreditIn, s: DB, actor: Staff, request: Request):
    cents = parse_amount_cents(body.amount) if body.amount else None
    a = _act(actions.apply_credit, s, state(request).clock, body.claim_id, body.order_id, actor, body.note, cents)
    return {"id": a.id, "amount_cents": a.amount_cents, "order": order_out(s, s.get(Order, body.order_id))}


# --------------------------------------------------------------------------- SMS

class SmsIn(BaseModel):
    body: str
    received_at: str | None = None
    sender: str | None = None


def _ingest(s: Session, request: Request, body: str, received_at, source: str, sender=None, device_id="",
            actor="system") -> dict:
    st = state(request)
    res = ingest_sms(s, business(s).id, body, parse_received_at(received_at), st.clock, st.cfg,
                     source=source, sender=sender, device_id=device_id, actor=actor)
    accs = {a.id: a for a in s.scalars(select(BusinessAccount)).all()}
    return {"sms": sms_view(res.sms, None, accs), "created": res.created, "reevaluated_submissions": res.reevaluated}


@router.post("/webhooks/sms")
async def sms_webhook(request: Request):
    """Android SMS-forwarder endpoint. JSON: {"sender": "COMBANK", "body": "...", "received_at": "..."}"""
    raw = await request.body()
    try:
        payload = json.loads(raw)
    except ValueError:
        raise HTTPException(400, "JSON body required")
    st = state(request)
    s0 = st.session_factory()
    try:
        b = s0.scalar(select(Business).order_by(Business.id))
        allow = sender_allowlist(s0, b.id) if b else []
    finally:
        s0.close()
    auth = verify_sms_webhook(st.settings, raw, dict(request.headers), payload.get("sender"), allowlist=allow)
    if not auth.ok:
        s = st.session_factory()
        try:
            audit(s, st.clock, "webhook", "sms_webhook_refused", "sms", None,
                  {"reason": auth.reason, "device": request.headers.get("x-device-id"), "sender": payload.get("sender")})
            s.commit()
        finally:
            s.close()
        raise HTTPException(auth.status, auth.reason)
    s = st.session_factory()
    try:
        return _ingest(s, request, payload.get("body", ""), payload.get("received_at"), "webhook",
                       payload.get("sender"), auth.device_id)
    finally:
        s.close()


@router.post("/api/sms/manual")
def sms_manual(body: SmsIn, s: DB, actor: Staff, request: Request):
    return _ingest(s, request, body.body, body.received_at, "manual", body.sender, actor=actor)


@router.post("/api/sms/simulate")
def sms_simulate(body: SmsIn, s: DB, request: Request):
    return _ingest(s, request, body.body, body.received_at, "simulator", body.sender or "SIMULATOR")


@router.post("/api/sms/csv")
async def sms_csv(s: DB, actor: Staff, request: Request, file: UploadFile = File(...)):
    """CSV with header: received_at,sender,body (e.g. exported from the phone's SMS backup)."""
    text = (await file.read()).decode("utf-8-sig")
    results = []
    for row in csv.DictReader(io.StringIO(text)):
        if not (row.get("body") or "").strip():
            continue
        results.append(_ingest(s, request, row["body"], row.get("received_at"), "csv", row.get("sender"), actor=actor))
    return {"rows": len(results), "created": sum(r["created"] for r in results),
            "reevaluated_submissions": sorted({i for r in results for i in r["reevaluated_submissions"]})}


@router.get("/api/sms")
def list_sms(s: DB, unclaimed_only: bool = False, limit: int = 300):
    accs = {a.id: a for a in s.scalars(select(BusinessAccount)).all()}
    rows = s.execute(select(SmsMessage, Claim).outerjoin(Claim, Claim.sms_id == SmsMessage.id)
                     .order_by(SmsMessage.received_at.desc()).limit(limit)).all()
    out = [sms_view(m, c, accs) for m, c in rows]
    if unclaimed_only:
        out = [x for x in out if x["is_credit"] and x["claim"] is None]
    return out


def setup_warnings(s: Session, b: Business | None) -> list[str]:
    if b is None:
        return ["No business configured."]
    w = []
    accs = s.scalars(select(BusinessAccount).where(BusinessAccount.business_id == b.id,
                                                   BusinessAccount.is_active.is_(True))).all()
    for a in accs:
        if not a.sms_senders:
            w.append(f"{a.bank} {a.display_account}: no SMS sender number set, so its bank SMS cannot be accepted "
                     f"from the phone forwarder.")
        if "*" in a.account_number:
            w.append(f"{a.bank} {a.display_account}: only a masked number is stored, so it cannot be sent to customers.")
    if not b.hotline:
        w.append("No hotline number: customers are told to contact 'our hotline' for refunds.")
    return w


@router.get("/api/health")
def health(s: DB, request: Request):
    st = state(request)
    b = s.scalar(select(Business).order_by(Business.id))
    last = s.scalar(select(func.max(SmsMessage.received_at)))
    return {
        "ok": True, "now": iso(st.clock.now()),
        "sms_feed": {"last_received_at": iso(last), "stale": feed_is_stale(s, b.id, st.clock, st.cfg) if b else True,
                     "stale_after_hours": st.cfg.sms_feed_stale_hours,
                     "senders_configured": bool(sender_allowlist(s, b.id)) if b else False},
        "setup_warnings": setup_warnings(s, b),
        "ocr_engines": st.engine_names(),
        "counts": {k: v for k, v in s.execute(select(Submission.outcome, func.count()).group_by(Submission.outcome)).all()},
        "needs_action": sum(1 for x in s.scalars(select(Submission)).all() if needs_action(x)),
    }


# --------------------------------------------------------------------------- WhatsApp

@router.post("/api/whatsapp/simulate")
def whatsapp_simulate(request: Request, s: DB, phone: str = Form(...), caption: str | None = Form(None),
                      message_id: str | None = Form(None), image: UploadFile = File(...)):
    """Simulates a customer sending a slip image to the business WhatsApp number (same code path as the webhook)."""
    st = state(request)
    data = image.file.read()
    res = handle_inbound_image(s, st.clock, st.cfg, st.extractor(), business(s).id, phone, data,
                               message_id or random_message_id(), caption, st.settings.upload_dir)
    return {"submission_id": res.submission.id if res.submission else None,
            "reply": res.reply, "duplicate_delivery": res.duplicate_delivery, "order_guessed": res.order_guessed,
            "outcome": res.submission.outcome if res.submission else None}


@router.get("/api/whatsapp/conversations")
def conversations(s: DB, phone: str | None = None):
    """Simulator chat view: inbound slips + outbound bot messages per customer."""
    custs = s.scalars(select(Customer)).all()
    out = []
    for c in custs:
        if phone and c.phone != phone:
            continue
        msgs = [{"at": iso(m.created_at), "dir": "out", "text": m.body, "reason_code": m.reason_code}
                for m in s.scalars(select(OutboundMessage).where(OutboundMessage.customer_id == c.id)).all()]
        msgs += [{"at": iso(x.created_at), "dir": "in", "text": "[payment slip image]", "submission_id": x.id,
                  "image_url": f"/api/submissions/{x.id}/image" if x.image_path else None}
                 for x in s.scalars(select(Submission).where(Submission.customer_id == c.id)).all()]
        msgs.sort(key=lambda m: (m["at"], 0 if m["dir"] == "in" else 1))
        out.append({"customer": {"id": c.id, "name": c.name, "phone": c.phone}, "messages": msgs})
    return out


@router.get("/webhooks/whatsapp")
def whatsapp_verify(request: Request, mode: str = Query(alias="hub.mode", default=""),
                    token: str = Query(alias="hub.verify_token", default=""),
                    challenge: str = Query(alias="hub.challenge", default="")):
    vt = state(request).settings.whatsapp_verify_token
    if vt and mode == "subscribe" and token == vt:
        return PlainTextResponse(challenge)
    raise HTTPException(403)


@router.post("/webhooks/whatsapp")
async def whatsapp_webhook(request: Request):
    st = state(request)
    raw = await request.body()
    if not verify_meta_signature(st.settings.whatsapp_app_secret, raw, request.headers.get("x-hub-signature-256")):
        raise HTTPException(401, "bad signature")
    msgs = parse_cloud_webhook(json.loads(raw))
    fetcher = st.media_fetcher or (GraphMediaFetcher(st.settings.whatsapp_access_token)
                                   if st.settings.whatsapp_access_token else None)
    handled = []
    s = st.session_factory()
    try:
        for m in msgs:
            if fetcher is None:
                handled.append({"message_id": m.message_id, "status": "no media fetcher configured"})
                continue
            res = handle_inbound_image(s, st.clock, st.cfg, st.extractor(), business(s).id, m.phone,
                                       fetcher.fetch(m.media_id), m.message_id, m.caption, st.settings.upload_dir)
            handled.append({"message_id": m.message_id, "submission_id": res.submission.id if res.submission else None,
                            "duplicate_delivery": res.duplicate_delivery})
    finally:
        s.close()
    # Always 200 quickly so Meta does not retry-storm; idempotency covers genuine retries.
    return {"handled": handled}


# --------------------------------------------------------------------------- jobs & stats

@router.post("/api/jobs/tick")
def jobs_tick(s: DB, request: Request):
    st = state(request)
    return tick(s, st.clock, st.cfg)


@router.get("/api/stats")
def stats(s: DB):
    subs = s.scalars(select(Submission)).all()
    tiers: dict[str, int] = {}
    lat = []
    cost = 0.0
    for x in subs:
        m = x.extraction_meta or {}
        t = m.get("tier") or "manual/none"
        tiers[t] = tiers.get(t, 0) + 1
        if m.get("latency_ms") is not None:
            lat.append(m["latency_ms"])
        cost += float(m.get("cost_usd") or 0)
    by_reason: dict[str, int] = {}
    for x in subs:
        by_reason[x.reason_code or "-"] = by_reason.get(x.reason_code or "-", 0) + 1
    lat.sort()
    pct = lambda p: lat[min(len(lat) - 1, int(p * len(lat)))] if lat else None
    return {"submissions": len(subs), "tiers": tiers, "by_reason": by_reason, "api_cost_usd": round(cost, 4),
            "latency_ms": {"p50": pct(0.5), "p95": pct(0.95), "max": lat[-1] if lat else None},
            "needs_action": sum(1 for x in subs if needs_action(x)),
            "high_risk": sum(1 for x in subs if risk_score(x) >= 3)}
