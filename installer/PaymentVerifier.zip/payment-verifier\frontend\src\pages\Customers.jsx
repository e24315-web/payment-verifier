import React, { useState } from "react";
import { api, rs } from "../lib.js";
import { Empty, ErrorLine, Modal, usePoll } from "../ui.jsx";

function RefundDialog({ customer, onClose, onDone }) {
  const [amount, setAmount] = useState((customer.refunds.outstanding_cents / 100).toFixed(2));
  const [note, setNote] = useState("");
  const [err, setErr] = useState("");
  return (
    <Modal title={`Record refund for ${customer.name} (${customer.code})`} onClose={onClose}>
      <p className="text-sm text-slate-600 mb-3">Outstanding: <b>{rs(customer.refunds.outstanding_cents)}</b>. Record the refund after you have actually sent the money back.</p>
      <label className="label">Amount refunded (Rs.)</label>
      <input className="input tabular mb-2" value={amount} onChange={(e) => setAmount(e.target.value)} />
      <label className="label">Note (required: how and when it was refunded)</label>
      <textarea className="input h-20" value={note} onChange={(e) => setNote(e.target.value)} />
      <ErrorLine error={err} />
      <div className="flex justify-end gap-2 mt-3">
        <button className="btn-ghost" onClick={onClose}>Cancel</button>
        <button className="btn-primary" disabled={note.trim().length < 3} onClick={async () => {
          try { await api.post(`/api/customers/${customer.id}/refunds`, { amount, note }); onDone(); onClose(); } catch (e) { setErr(e.message); }
        }}>Record refund</button>
      </div>
    </Modal>
  );
}

export default function Customers() {
  const [q, setQ] = useState("");
  const [list, setList] = useState([]);
  const [refund, setRefund] = useState(null);
  const [onlyDue, setOnlyDue] = useState(false);
  const load = () => api.get(`/api/customers${q ? `?q=${encodeURIComponent(q)}` : ""}`).then(setList).catch(() => {});
  usePoll(load, 8000, [q]);
  const shown = onlyDue ? list.filter((c) => c.refunds.outstanding_cents > 0) : list;

  return (
    <div className="card">
      <div className="px-4 py-3 border-b border-slate-200 flex items-center gap-3">
        <h2 className="font-semibold mr-auto">Customers & refunds</h2>
        <label className="text-xs flex items-center gap-1.5"><input type="checkbox" checked={onlyDue} onChange={(e) => setOnlyDue(e.target.checked)} /> refund due only</label>
        <input className="input !w-80" placeholder="Hotline lookup: customer ID (C00012), phone or name" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      {shown.length === 0 ? <Empty>No customers found.</Empty> : (
        <table className="w-full text-sm">
          <thead><tr className="border-b border-slate-200">
            <th className="th">Customer ID</th><th className="th">Name</th><th className="th">Phone</th>
            <th className="th">Refund due: why</th><th className="th text-right">Refunded</th><th className="th text-right">Outstanding</th><th className="th"></th>
          </tr></thead>
          <tbody className="divide-y divide-slate-100">
            {shown.map((c) => (
              <tr key={c.id}>
                <td className="td font-mono font-medium">{c.code}</td>
                <td className="td">{c.name}</td>
                <td className="td text-xs">{c.phone}</td>
                <td className="td text-xs">{c.refunds.items.length === 0 ? <span className="text-slate-400">–</span> :
                  c.refunds.items.map((i, k) => <div key={k}>{rs(i.amount_cents)} · {i.source} · order {i.order_code}</div>)}</td>
                <td className="td text-right tabular text-xs">{rs(c.refunds.refunded_cents)}</td>
                <td className={`td text-right tabular font-semibold ${c.refunds.outstanding_cents > 0 ? "text-amber-700" : "text-slate-400"}`}>{rs(c.refunds.outstanding_cents)}</td>
                <td className="td text-right">{c.refunds.outstanding_cents > 0 && <button className="btn-ghost !py-1 text-xs" onClick={() => setRefund(c)}>Record refund</button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {refund && <RefundDialog customer={refund} onClose={() => setRefund(null)} onDone={load} />}
    </div>
  );
}
