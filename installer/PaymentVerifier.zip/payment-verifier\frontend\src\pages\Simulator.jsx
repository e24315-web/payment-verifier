import React, { useState } from "react";
import { api, dtSec, timeOnly } from "../lib.js";
import { ErrorLine, OutcomeBadge, usePoll } from "../ui.jsx";
import { NewOrderForm } from "./Orders.jsx";

const SAMPLE_SLIPS = [
  ["ComBank e-receipt (Rs 5,000, 26/09 4:18 PM)", "/samples/combank_ereceipt.jpeg"],
  ["ComBank Flash (Rs 51,000, 24/09 10:01 PM)", "/samples/combank_flash.jpeg"],
  ["People's Bank cash deposit photo (Rs 7,500, 28/08 1:43 PM)", "/samples/peoples_deposit.jpeg"],
  ["TEST slip Rs 3,000 at 4:19 PM", "/samples/test/underpaid_3000_0419pm.jpg"],
  ["TEST slip Rs 5,000 at 4:24 PM (balance)", "/samples/test/balance_5000_0424pm.jpg"],
  ["TEST slip Rs 20,000 at 4:20 PM (edited)", "/samples/test/edited_amount_20000_0420pm.jpg"],
  ["TEST slip, blurred", "/samples/test/unclear_5000_0420pm.jpg"],
  ["TEST slip Rs 4,000 at 4:21 PM", "/samples/test/no_sms_4000_0421pm.jpg"],
  ["TEST slip Rs 1,800 at 4:21 PM", "/samples/test/overpaid_1800_0421pm.jpg"],
];
const SAMPLE_SMS = [
  ["ComBank credit (real sample A)", "Credit for Rs. 5,000.00 to 8026328795 at 16:18 at DIGITAL BANKING DIVISION", "COMBANK"],
  ["People's Bank cash deposit (real sample B)", "Dear Sir/Madam, Your A/C 065-2002****90 has been Credited by Rs. 7500.00(Cash Depo. @13:44 28/08/2026).[Av_Bal: Rs. 36222.13 at SMS generated]", "PEOPLESBANK"],
  ["ComBank credit for the Flash receipt (synthetic)", "Credit for Rs. 51,000.00 to 8026328795 at 22:01 at DIGITAL BANKING DIVISION", "COMBANK"],
];

function Bubble({ m }) {
  const out = m.dir === "out";
  return (
    <div className={`flex ${out ? "justify-start" : "justify-end"}`}>
      <div className={`max-w-[80%] rounded-lg px-3 py-2 text-sm shadow-sm ${out ? "bg-white" : "bg-emerald-100"}`}>
        {m.image_url ? <img src={m.image_url} alt="slip" className="max-h-48 rounded mb-1" /> : null}
        <div className="whitespace-pre-line">{m.text}</div>
        <div className="text-[10px] text-slate-400 text-right mt-0.5">
          {out ? "Business bot" : "Customer"} · {timeOnly(m.at)}
          {m.submission_id && <> · <a className="underline" href={`#/queue/${m.submission_id}`}>review #{m.submission_id}</a></>}
        </div>
      </div>
    </div>
  );
}

export default function Simulator({ business }) {
  const [convs, setConvs] = useState([]);
  const [sel, setSel] = useState(null);         // phone
  const [newChat, setNewChat] = useState({ name: "", phone: "" });
  const [caption, setCaption] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [last, setLast] = useState(null);
  const [sms, setSms] = useState({ body: "", sender: "", received_at: "" });
  const [smsRes, setSmsRes] = useState("");
  const load = () => api.get("/api/whatsapp/conversations").then(setConvs).catch(() => {});
  usePoll(load, 3000);

  const conv = convs.find((c) => c.customer.phone === sel);
  const phone = sel || newChat.phone;

  const sendImage = async (blob, name) => {
    if (!phone) { setErr("Pick a conversation or enter a phone number first."); return; }
    setBusy(true); setErr(""); setLast(null);
    const fd = new FormData();
    fd.append("phone", phone);
    if (caption) fd.append("caption", caption);
    fd.append("image", blob, name);
    try { setLast(await api.form("/api/whatsapp/simulate", fd)); load(); } catch (e) { setErr(e.message); } finally { setBusy(false); }
  };
  const sendSample = async (url) => {
    const b = await (await fetch(url)).blob();
    sendImage(b, url.split("/").pop());
  };
  const sendSms = async () => {
    setSmsRes("");
    try {
      const r = await api.post("/api/sms/simulate", { body: sms.body, sender: sms.sender || null, received_at: sms.received_at ? sms.received_at + ":00+05:30" : null });
      setSmsRes(r.created ? `SMS stored (#${r.sms.id}). ${r.reevaluated_submissions.length ? `Re-checked: ${r.reevaluated_submissions.map((x) => "#" + x).join(", ")}` : ""}` : "Duplicate SMS ignored.");
    } catch (e) { setSmsRes(e.message); }
  };

  return (
    <div className="grid grid-cols-[240px_1fr_380px] gap-4 items-start">
      <div className="card">
        <div className="px-3 py-2 border-b border-slate-200 font-medium text-sm">Chats</div>
        <div className="divide-y divide-slate-100 max-h-[70vh] overflow-y-auto">
          {convs.map((c) => (
            <button key={c.customer.id} onClick={() => setSel(c.customer.phone)}
              className={`w-full text-left px-3 py-2 text-sm cursor-pointer hover:bg-slate-50 ${sel === c.customer.phone ? "bg-slate-100" : ""}`}>
              <div className="font-medium">{c.customer.name}</div>
              <div className="text-xs text-slate-500">{c.customer.phone}</div>
            </button>
          ))}
        </div>
        <div className="p-3 border-t border-slate-200 space-y-2">
          <div className="text-xs font-medium text-slate-500">New customer chat</div>
          <input className="input" placeholder="Name" value={newChat.name} onChange={(e) => setNewChat({ ...newChat, name: e.target.value })} />
          <input className="input" placeholder="077 123 4567" value={newChat.phone} onChange={(e) => { setNewChat({ ...newChat, phone: e.target.value }); setSel(null); }} />
        </div>
      </div>

      <div className="card flex flex-col h-[78vh]">
        <div className="px-4 py-2 border-b border-slate-200 text-sm">
          <b>{conv?.customer.name || newChat.name || "Customer"}</b> <span className="text-slate-500">{phone}</span>
          <span className="text-xs text-slate-400 ml-2">(what the customer sees on WhatsApp)</span>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-2 bg-[#efeae2]">
          {(conv?.messages || []).map((m, i) => <Bubble key={i} m={m} />)}
          {!conv && <div className="text-center text-slate-500 text-sm mt-10">Create an order for this customer (right) to start the conversation.</div>}
        </div>
        <div className="p-3 border-t border-slate-200 space-y-2">
          <div className="flex gap-2">
            <input className="input" placeholder="Caption (optional, e.g. the order code)" value={caption} onChange={(e) => setCaption(e.target.value)} />
            <label className="btn-ghost whitespace-nowrap">Send slip image…
              <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files[0] && sendImage(e.target.files[0], e.target.files[0].name)} />
            </label>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {SAMPLE_SLIPS.map(([label, url]) => (
              <button key={url} className="btn-ghost !py-1 text-xs" disabled={busy} onClick={() => sendSample(url)}>Send: {label}</button>
            ))}
          </div>
          {busy && <div className="text-xs text-slate-500">Reading the slip (local OCR)…</div>}
          <ErrorLine error={err} />
          {last && <div className="text-xs flex items-center gap-2">Result: <OutcomeBadge outcome={last.outcome} />
            {last.submission_id && <a className="underline" href={`#/queue/${last.submission_id}`}>open in review</a>}
            {last.duplicate_delivery && <span className="text-slate-500">(duplicate delivery ignored)</span>}</div>}
        </div>
      </div>

      <div className="space-y-4">
        <div className="card p-4">
          <h3 className="font-semibold text-sm mb-2">Staff: create order from this chat</h3>
          <NewOrderForm business={business} preset={{ name: conv?.customer.name || newChat.name, phone }} onCreated={(o) => { setSel(o.customer.phone); load(); }} />
        </div>
        <div className="card p-4 space-y-2">
          <h3 className="font-semibold text-sm">Bank: simulate an SMS to the business phone</h3>
          <div className="flex flex-col gap-1">
            {SAMPLE_SMS.map(([label, body, sender]) => (
              <button key={label} className="text-left text-xs underline text-slate-600 cursor-pointer" onClick={() => setSms({ ...sms, body, sender })}>{label}</button>
            ))}
          </div>
          <textarea className="input h-24 font-mono text-xs" value={sms.body} onChange={(e) => setSms({ ...sms, body: e.target.value })} placeholder="SMS text (edit the time or amount to try other cases)" />
          <div className="grid grid-cols-2 gap-2">
            <input className="input" placeholder="Sender" value={sms.sender} onChange={(e) => setSms({ ...sms, sender: e.target.value })} />
            <input type="datetime-local" className="input" title="received at (empty = now)" value={sms.received_at} onChange={(e) => setSms({ ...sms, received_at: e.target.value })} />
          </div>
          <button className="btn-primary w-full" disabled={!sms.body.trim()} onClick={sendSms}>Deliver SMS</button>
          {smsRes && <div className="text-xs text-slate-600">{smsRes}</div>}
          <p className="text-[11px] text-slate-400">ComBank SMS carry no date: it is taken from the "received at" time, so set it to the day of the transfer.</p>
        </div>
      </div>
    </div>
  );
}
