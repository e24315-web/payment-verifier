"""Cheap image layer (no OCR, no network): hashes, quality metrics, preprocessing variants, EXIF check.

Everything here runs in milliseconds and is the first line of cost control: an exact re-upload is caught by
SHA-256 before any OCR runs.
"""
from __future__ import annotations

import hashlib
import io
from dataclasses import dataclass, field

import imagehash
import numpy as np
from PIL import Image, ImageOps

from app.domain.types import Flag, Severity

EDITING_SOFTWARE = ("photoshop", "gimp", "snapseed", "picsart", "canva", "lightroom", "pixlr", "facetune",
                    "meitu", "affinity", "paint.net", "illustrator")


@dataclass
class Quality:
    width: int
    height: int
    brightness: float     # 0..255 mean
    contrast: float       # std dev
    sharpness: float      # variance of Laplacian (on <=1000px image)
    issues: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"width": self.width, "height": self.height, "brightness": round(self.brightness, 1),
                "contrast": round(self.contrast, 1), "sharpness": round(self.sharpness, 1), "issues": self.issues}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_image(data: bytes) -> Image.Image:
    im = Image.open(io.BytesIO(data))
    im = ImageOps.exif_transpose(im)
    return im.convert("RGB")


def perceptual_hash(im: Image.Image) -> str:
    return str(imagehash.phash(im))


def phash_distance(a: str | None, b: str | None) -> int | None:
    if not a or not b:
        return None
    return imagehash.hex_to_hash(a) - imagehash.hex_to_hash(b)


def _laplacian_var(gray: np.ndarray) -> float:
    g = gray.astype(np.float32)
    lap = (-4 * g[1:-1, 1:-1] + g[:-2, 1:-1] + g[2:, 1:-1] + g[1:-1, :-2] + g[1:-1, 2:])
    return float(lap.var())


def assess_quality(im: Image.Image) -> Quality:
    small = im.copy()
    small.thumbnail((1000, 1000))
    gray = np.asarray(ImageOps.grayscale(small))
    q = Quality(im.width, im.height, float(gray.mean()), float(gray.std()), _laplacian_var(gray))
    if min(im.width, im.height) < 400:
        q.issues.append("LOW_RESOLUTION")
    if q.brightness < 60:
        q.issues.append("TOO_DARK")
    if q.brightness > 245 and q.contrast < 20:
        q.issues.append("WASHED_OUT")
    if q.contrast < 18:
        q.issues.append("LOW_CONTRAST")
    if q.sharpness < 40:
        q.issues.append("BLURRY")
    return q


def exif_flags(data: bytes) -> list[Flag]:
    """Editing software recorded in EXIF. WhatsApp usually strips EXIF, so absence proves nothing."""
    try:
        exif = Image.open(io.BytesIO(data)).getexif()
    except Exception:
        return []
    software = str(exif.get(305, "") or "")   # 305 = Software
    if any(s in software.lower() for s in EDITING_SOFTWARE):
        return [Flag("EDITING_SOFTWARE", Severity.MEDIUM, f"image metadata says it was saved by '{software}'")]
    return []


# --------------------------------------------------------------------------- OCR preprocessing variants

def _upscale(g: Image.Image, target_min: int = 1600) -> Image.Image:
    scale = max(1.0, target_min / min(g.size))
    if scale <= 1.0:
        return g
    return g.resize((int(g.width * scale), int(g.height * scale)), Image.LANCZOS)


def ocr_variants(im: Image.Image) -> list[tuple[str, Image.Image]]:
    """Complementary renderings. Found on the real Flash receipt: grayscale reads the values perfectly but
    loses the light-grey labels; a high threshold keeps the labels but garbles a value on a shaded row.
    The pipeline OCRs several and merges field-by-field (see extraction.merge)."""
    g = ImageOps.grayscale(im)
    up = _upscale(g)
    return [
        ("gray", g),
        ("up_autocontrast", ImageOps.autocontrast(up, cutoff=1)),
        ("up_bin200", up.point(lambda p: 255 if p > 200 else 0)),
    ]
