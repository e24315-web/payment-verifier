"""Deployment settings (secrets, paths). Business rules live in config.RulesConfig."""
from __future__ import annotations

import os
from dataclasses import dataclass, field


def _list(name: str) -> list[str]:
    return [x.strip() for x in os.getenv(name, "").split(",") if x.strip()]


@dataclass
class Settings:
    database_url: str = field(default_factory=lambda: os.getenv("PV_DATABASE_URL", "sqlite:///./payment_verifier.db"))
    upload_dir: str = field(default_factory=lambda: os.getenv("PV_UPLOAD_DIR", "./uploads"))
    # Staff UI auth. Empty = open (local demo only; the README says so).
    staff_api_key: str = field(default_factory=lambda: os.getenv("PV_STAFF_API_KEY", ""))

    # SMS forwarder webhook. Two modes:
    #   HMAC  : X-Signature = hex(HMAC-SHA256(secret, f"{X-Timestamp}.{raw body}")), timestamp within 5 min
    #   token : X-Device-Token header equals the configured token for X-Device-Id (off-the-shelf forwarder
    #           apps can only send static headers; weaker, documented)
    sms_hmac_secret: str = field(default_factory=lambda: os.getenv("PV_SMS_HMAC_SECRET", ""))
    # "device-id:token,device-id2:token2"
    sms_device_tokens: dict = field(default_factory=lambda: dict(
        p.split(":", 1) for p in _list("PV_SMS_DEVICE_TOKENS") if ":" in p))
    # Bank sender IDs allowed through the webhook (e.g. COMBANK,PEOPLESBANK). Empty = allow any sender.
    sms_sender_allowlist: list = field(default_factory=lambda: [s.upper() for s in _list("PV_SMS_SENDER_ALLOWLIST")])
    sms_max_clock_skew_s: int = 300

    # WhatsApp Cloud API (Meta). Empty = webhook disabled; the simulator is used instead.
    whatsapp_verify_token: str = field(default_factory=lambda: os.getenv("PV_WA_VERIFY_TOKEN", ""))
    whatsapp_app_secret: str = field(default_factory=lambda: os.getenv("PV_WA_APP_SECRET", ""))
    whatsapp_access_token: str = field(default_factory=lambda: os.getenv("PV_WA_ACCESS_TOKEN", ""))

    ocr_engines: str = field(default_factory=lambda: os.getenv("PV_OCR_ENGINES", "tesseract,rapidocr"))
    # Demo only: e.g. "2026-09-26T16:10:00" (Asia/Colombo). The app clock starts there and runs forward.
    demo_start: str = field(default_factory=lambda: os.getenv("PV_DEMO_START", ""))
    job_interval_s: int = field(default_factory=lambda: int(os.getenv("PV_JOB_INTERVAL_S", "60")))
