"""Normalisation of money, accounts, references, names and Sri Lankan date/time formats.

Money is always integer cents. Datetimes are always timezone-aware.
"""
from __future__ import annotations

import re
from datetime import date, datetime, time, timedelta
from decimal import Decimal, InvalidOperation
from difflib import SequenceMatcher

from app.clock import LK_TZ

# ---------------------------------------------------------------- money

_AMOUNT_RE = re.compile(r"^\d{1,3}(?:,\d{3})*(?:\.\d{1,2})?$|^\d+(?:\.\d{1,2})?$")


def parse_amount_cents(raw: str | None) -> int | None:
    """'5,000.00' / 'Rs. 7500.00' / 'LKR 51,000.00' -> cents. Returns None for anything not clean.

    Deliberately strict: an OCR-garbled amount such as '/,500.00' returns None rather than a guess.
    """
    if raw is None:
        return None
    s = str(raw).strip().upper()
    s = re.sub(r"^(?:LKR|RS\.?|R\.S\.?)\s*[:.]?\s*", "", s)
    s = s.rstrip(" .")
    s = s.replace(" ", "")
    if not _AMOUNT_RE.match(s):
        return None
    try:
        value = Decimal(s.replace(",", ""))
    except InvalidOperation:
        return None
    return int((value * 100).to_integral_value())


def format_rs(cents: int) -> str:
    return f"Rs. {cents / 100:,.2f}"


# ---------------------------------------------------------------- accounts

def normalize_account(raw: str | None) -> str | None:
    """Keep digits and mask characters. 'X', 'x', '*', '?', '#' all become '*'. Hyphens/spaces dropped."""
    if not raw:
        return None
    s = str(raw).upper()
    s = re.sub(r"[X?#]", "*", s)
    s = re.sub(r"[^0-9*]", "", s)
    return s or None


def _mask_parts(acc: str) -> tuple[str, str, bool]:
    """Return (visible prefix, visible suffix, is_masked)."""
    if "*" not in acc:
        return acc, acc, False
    first = acc.index("*")
    last = acc.rindex("*")
    return acc[:first], acc[last + 1:], True


def visible_digits(acc: str) -> int:
    pre, suf, masked = _mask_parts(acc)
    return len(pre) + len(suf) if masked else len(acc)


def accounts_compatible(a: str | None, b: str | None, min_visible: int = 4) -> bool:
    """Mask-aware account comparison.

    Banks mask with a variable number of stars ('065-2002****90' may hide more or fewer than 4 digits),
    so we compare visible prefix and suffix only, not length. Needs >= min_visible known digits on the
    more-masked side, otherwise we refuse to call it a match.
    """
    a, b = normalize_account(a), normalize_account(b)
    if not a or not b:
        return False
    pa, sa, ma = _mask_parts(a)
    pb, sb, mb = _mask_parts(b)
    if not ma and not mb:
        return a == b
    if min(visible_digits(a), visible_digits(b)) < min_visible:
        return False
    if not ma:  # a full, b masked
        return a.startswith(pb) and a.endswith(sb) and len(a) >= len(pb) + len(sb)
    if not mb:
        return b.startswith(pa) and b.endswith(sa) and len(b) >= len(pa) + len(sa)
    prefix_ok = pa.startswith(pb) or pb.startswith(pa)
    suffix_ok = sa.endswith(sb) or sb.endswith(sa)
    return prefix_ok and suffix_ok


def mask_for_display(acc: str | None) -> str:
    acc = normalize_account(acc) or ""
    if "*" in acc or len(acc) <= 4:
        return acc
    return "*" * (len(acc) - 4) + acc[-4:]


# ---------------------------------------------------------------- references

_REF_FOLD = str.maketrans({"O": "0", "Q": "0", "I": "1", "L": "1"})


def fold_reference(raw: str | None) -> str | None:
    """Comparison key for a reference: uppercase alnum with OCR-confusable letters folded.

    Only the O/0 and I/L/1 confusions are folded. Wider folding (S/5, B/8) would make distinct
    references collide, and a collision here can cause a false ALREADY_USED rejection.
    The raw reference is always stored separately for display.
    """
    if not raw:
        return None
    s = re.sub(r"[^0-9A-Z]", "", str(raw).upper())
    if len(s) < 5:
        return None
    return s.translate(_REF_FOLD)


# ---------------------------------------------------------------- names

_TITLES = {"MR", "MRS", "MS", "MISS", "DR", "REV", "MASTER"}


def normalize_name(raw: str | None) -> str | None:
    if not raw:
        return None
    tokens = re.sub(r"[^A-Z ]", " ", str(raw).upper()).split()
    tokens = [t for t in tokens if t not in _TITLES]
    return " ".join(tokens) or None


def name_similarity(a: str | None, b: str | None) -> float:
    """0..1. Token-aware: 'ATHAYEA RASOOL' vs 'MOHAMED RIZAN ATHAYEA RASOOL' scores high."""
    na, nb = normalize_name(a), normalize_name(b)
    if not na or not nb:
        return 0.0
    ta, tb = set(na.split()), set(nb.split())
    small, big = (ta, tb) if len(ta) <= len(tb) else (tb, ta)
    # Fuzzy containment: each token of the shorter name has a close token in the longer name.
    hits = 0.0
    for t in small:
        hits += max(SequenceMatcher(None, t, u).ratio() for u in big)
    containment = hits / len(small)
    whole = SequenceMatcher(None, na, nb).ratio()
    return max(containment, whole)


# ---------------------------------------------------------------- date / time

_MONTHS = {m: i for i, m in enumerate(
    ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"], start=1)}


def parse_hm(raw: str) -> tuple[int, int, int | None] | None:
    """'04:18 PM' / '16:18' / '13:44:42' / '4:18PM' -> (hour24, minute, second|None)."""
    m = re.match(r"^\s*(\d{1,2})[:.](\d{2})(?:[:.](\d{2}))?\s*([AaPp]\.?[Mm]\.?)?\s*$", raw or "")
    if not m:
        return None
    h, mi = int(m.group(1)), int(m.group(2))
    sec = int(m.group(3)) if m.group(3) else None
    ampm = (m.group(4) or "").upper().replace(".", "")
    if ampm:
        if not 1 <= h <= 12:
            return None
        if ampm == "PM" and h != 12:
            h += 12
        if ampm == "AM" and h == 12:
            h = 0
    if not (0 <= h <= 23 and 0 <= mi <= 59 and (sec is None or 0 <= sec <= 59)):
        return None
    return h, mi, sec


def parse_date_dmy(raw: str) -> date | None:
    """dd/mm/yyyy, dd-mm-yyyy, dd.mm.yyyy, dd/mm/yy, dd-mm-yy (Sri Lankan day-first)."""
    m = re.match(r"^\s*(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2}|\d{4})\s*$", raw or "")
    if not m:
        return None
    d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
    if y < 100:
        y += 2000
    try:
        return date(y, mo, d)
    except ValueError:
        return None


def parse_date_mdy(raw: str) -> date | None:
    """m/d/yy as printed in ComBank 'Generated at 9/26/26'. Only use where the template says so."""
    m = re.match(r"^\s*(\d{1,2})/(\d{1,2})/(\d{2}|\d{4})\s*$", raw or "")
    if not m:
        return None
    mo, d, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
    if y < 100:
        y += 2000
    try:
        return date(y, mo, d)
    except ValueError:
        return None


def parse_date_iso(raw: str) -> date | None:
    m = re.match(r"^\s*(\d{4})-(\d{1,2})-(\d{1,2})\s*$", raw or "")
    if not m:
        return None
    try:
        return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except ValueError:
        return None


def parse_date_dmony(raw: str) -> date | None:
    """'28AUG2026' as printed by People's Bank teller machines."""
    m = re.match(r"^\s*(\d{1,2})\s*([A-Za-z]{3})\s*(\d{4})\s*$", raw or "")
    if not m or m.group(2).upper() not in _MONTHS:
        return None
    try:
        return date(int(m.group(3)), _MONTHS[m.group(2).upper()], int(m.group(1)))
    except ValueError:
        return None


def local_dt(d: date, h: int, mi: int, sec: int | None = None) -> datetime:
    return datetime.combine(d, time(h, mi, sec or 0), tzinfo=LK_TZ)


def infer_date_from_received(hour: int, minute: int, received_at: datetime) -> datetime:
    """SMS gives only HH:MM. The transaction is the latest HH:MM at or before the SMS received time.

    e.g. 'at 23:59' received 00:01 next day -> previous day 23:59.
    """
    rec_local = received_at.astimezone(LK_TZ)
    candidate = rec_local.replace(hour=hour, minute=minute, second=0, microsecond=0)
    # Allow the phone clock to be up to 1 minute behind the bank clock.
    if candidate > rec_local + timedelta(minutes=1):
        candidate -= timedelta(days=1)
    return candidate


def minute_floor(dt: datetime) -> datetime:
    return dt.replace(second=0, microsecond=0)


def minute_key(dt: datetime) -> str:
    """Local-time minute key used in canonical transaction identity: 'YYYYMMDDHHMM'."""
    return dt.astimezone(LK_TZ).strftime("%Y%m%d%H%M")
