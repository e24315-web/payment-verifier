from datetime import date

import pytest

from app.clock import lk
from app.domain.normalize import (
    accounts_compatible,
    fold_reference,
    infer_date_from_received,
    name_similarity,
    normalize_account,
    parse_amount_cents,
    parse_date_dmony,
    parse_date_dmy,
    parse_date_mdy,
    parse_hm,
)


@pytest.mark.parametrize("raw,cents", [
    ("5,000.00", 500000), ("Rs. 7500.00", 750000), ("LKR 51,000.00", 5100000), ("7500", 750000),
    ("1,234,567.5", 123456750), ("Rs.25,000", 2500000),
])
def test_amounts(raw, cents):
    assert parse_amount_cents(raw) == cents


@pytest.mark.parametrize("raw", ["/,500.00", "7,50,0.00", "5.000,00", "", None, "abc", "5,00.00"])
def test_garbled_amounts_are_not_guessed(raw):
    assert parse_amount_cents(raw) is None


def test_account_normalisation_and_masks():
    assert normalize_account("065-2002****90") == "0652002****90"
    assert normalize_account("XXXX1234") == "****1234"
    assert accounts_compatible("8026328795", "8026328795")
    assert not accounts_compatible("8026328795", "8026328799")
    # Real People's Bank SMS mask vs partially legible machine line on the slip (different lengths)
    assert accounts_compatible("065-2002****90", "065-2-002-?-00??90")
    assert accounts_compatible("0652002****90", "0652002123490")
    assert not accounts_compatible("0652002****90", "0652003123490")
    assert not accounts_compatible("0652002****90", "0652002123491")
    # Too few visible digits to call it a match
    assert not accounts_compatible("****90", "0652002123490")


def test_reference_folding_handles_o_zero_and_i_one():
    assert fold_reference("O600066186696") == fold_reference("0600066186696")
    assert fold_reference("WT3342621I") == fold_reference("WT33426211")
    assert fold_reference("O600066186696") != fold_reference("O600066186697")
    assert fold_reference("CCE1-2AD2-6445-6ED6") == "CCE12AD264456ED6"


@pytest.mark.parametrize("raw,expected", [
    ("04:18 PM", (16, 18, None)), ("4:18PM", (16, 18, None)), ("16:18", (16, 18, None)),
    ("13:44:42", (13, 44, 42)), ("12:05 AM", (0, 5, None)), ("12:05 PM", (12, 5, None)),
    ("22:01:29", (22, 1, 29)),
])
def test_times(raw, expected):
    assert parse_hm(raw) == expected


@pytest.mark.parametrize("raw", ["25:00", "13:61", "13:44 PM", "0:00 AM"])
def test_invalid_times(raw):
    assert parse_hm(raw) is None


def test_dates_day_first_and_month_first():
    assert parse_date_dmy("26/09/2026") == date(2026, 9, 26)
    assert parse_date_dmy("26-09-26") == date(2026, 9, 26)
    assert parse_date_dmy("28/08/2026") == date(2026, 8, 28)
    assert parse_date_mdy("9/26/26") == date(2026, 9, 26)   # ComBank "Generated at" is month-first
    assert parse_date_dmy("9/26/26") is None                 # would be month 26 -> invalid, not silently swapped
    assert parse_date_dmony("28AUG2026") == date(2026, 8, 28)


def test_sms_date_inferred_from_received_time_across_midnight():
    t = infer_date_from_received(23, 59, lk(2026, 9, 27, 0, 1))
    assert t == lk(2026, 9, 26, 23, 59)
    t = infer_date_from_received(16, 18, lk(2026, 9, 26, 16, 18, 40))
    assert t == lk(2026, 9, 26, 16, 18)
    # phone clock 30s behind the bank clock: still same day
    t = infer_date_from_received(16, 19, lk(2026, 9, 26, 16, 18, 40))
    assert t == lk(2026, 9, 26, 16, 19)


def test_name_similarity_handles_aliases():
    assert name_similarity("MR ATHAYEA RASOOL", "MR MOHAMED RIZAN ATHAYEA RASOOL") > 0.9
    assert name_similarity("Athayee Kampu", "ATHAYEE KAMPU") == 1.0
    assert name_similarity("JOHN PERERA", "MR MOHAMED RIZAN ATHAYEA RASOOL") < 0.75
