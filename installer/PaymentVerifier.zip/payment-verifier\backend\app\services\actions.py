"""Staff actions. Every action needs an actor; approve/reject/link/apply-credit need a written note.
Every action writes an append-only DecisionRecord and/or AuditLog entry.

Design rule: every APPROVED payment is backed by a bank credit record (SMS). If the SMS never arrived, staff first
add the credit manually (source='manual', visibly marked), then link it. Accounting always balances.
"""
from __future__ import annotations

import hashlib

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.clock import Clock
from app.config import ENGINE_VERSION, RulesConfig
from app.db.models import (
    Claim,
    CreditApplication,
    Customer,
    DecisionRecord,
    Order,
    OutboundMessage,
    Refund,
    SmsMessage,
    Submission,
)
from app.domain.normalize import format_rs
from app.domain.reasons import REASONS, customer_message
from app.services.verification import audit, current_slip, evaluate, recompute_order


class ActionError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


def _require_note(note: str | None) -> str:
    if not note or len(note.strip()) < 3:
        raise ActionError("a note explaining the decision is required", 422)
    return note.strip()


def _record(session: Session, clock: Clock, sub: Submission, outcome: str, code: str, actor: str, note: str,
            reasons: list[str], msg: str, confidence: float = 1.0) -> None:
    before = (sub.outcome, sub.reason_code)
    sub.outcome, sub.reason_code, sub.confidence = outcome, code, confidence
    sub.decided_by = actor
    sub.updated_at = clock.now()
    session.add(DecisionRecord(
        submission_id=sub.id, outcome=outcome, reason_code=code, confidence=confidence, reasons=reasons,
        flags=sub.flags or [], next_action=REASONS[code].next_action, customer_message=msg, match=sub.match,
        evidence=current_slip(sub).to_dict()["fields"], engine_version=ENGINE_VERSION, actor=actor, note=note,
        created_at=clock.now()))
    audit(session, clock, actor, f"staff_{code.lower()}", "submission", sub.id,
          {"before": list(before), "after": [outcome, code], "note": note})
    customer = session.get(Customer, sub.customer_id)
    session.add(OutboundMessage(customer_id=customer.id, order_id=sub.order_id, submission_id=sub.id,
                                to_phone=customer.phone, body=msg, reason_code=code, created_at=clock.now()))


def _get_sub(session: Session, sub_id: int) -> Submission:
    sub = session.get(Submission, sub_id)
    if sub is None:
        raise ActionError("submission not found", 404)
    return sub


def staff_approve(session: Session, clock: Clock, sub_id: int, actor: str, note: str | None,
                  sms_id: int | None = None) -> Submission:
    """Approve override / manual SMS link. Uses the SMS held for this submission unless another is given."""
    note = _require_note(note)
    sub = _get_sub(session, sub_id)
    order = session.get(Order, sub.order_id)
    held = session.scalar(select(Claim).where(Claim.submission_id == sub.id))
    if sms_id is None:
        if held is None:
            raise ActionError("no bank credit is linked to this submission. Add the credit (manual SMS entry) "
                              "and link it, so every approved payment is backed by a bank record", 409)
        sms_id = held.sms_id
    sms = session.get(SmsMessage, sms_id)
    if sms is None or not sms.is_credit or sms.amount_cents is None:
        raise ActionError("SMS not found or not a credit", 404)
    other = session.scalar(select(Claim).where(Claim.sms_id == sms_id, Claim.submission_id != sub.id))
    if other is not None:
        raise ActionError(f"this bank credit is already claimed by submission #{other.submission_id} "
                          f"({other.kind}); release it there first", 409)
    if held is not None and held.sms_id != sms_id:
        audit(session, clock, actor, "claim_released", "claim", held.id, {"sms_id": held.sms_id})
        session.delete(held)
        session.flush()
        held = None

    paid_other = session.scalar(select(func.coalesce(func.sum(Claim.applied_cents), 0)).where(
        Claim.order_id == order.id, Claim.kind == "ORDER_PAYMENT", Claim.submission_id != sub.id)) or 0
    paid_other += session.scalar(select(func.coalesce(func.sum(CreditApplication.amount_cents), 0))
                                 .where(CreditApplication.order_id == order.id)) or 0
    balance = max(0, order.expected_cents - int(paid_other))
    amount = sms.amount_cents
    applied, excess = min(amount, balance), max(0, amount - balance)
    kind = "ORDER_PAYMENT" if applied > 0 else "UNAPPLIED_CREDIT"
    if held:
        held.kind, held.applied_cents, held.excess_cents = kind, applied, excess
    else:
        session.add(Claim(sms_id=sms_id, submission_id=sub.id, order_id=order.id, customer_id=sub.customer_id,
                          kind=kind, applied_cents=applied, excess_cents=excess, created_at=clock.now()))
    session.flush()
    recompute_order(session, order)
    params = {"order_code": order.code, "amount": format_rs(amount)}
    reasons = [f"Approved by {actor} using bank credit #{sms_id} ({format_rs(amount)}, source: {sms.source})"]
    if order.paid_cents < order.expected_cents:
        code = "APPROVED_UNDERPAID"
        params["balance"] = format_rs(order.expected_cents - order.paid_cents)
    else:
        code = "MANUAL_APPROVED"
    if excess:
        reasons.append(f"Excess {format_rs(excess)} held as customer credit")
    _record(session, clock, sub, "APPROVED", code, actor, note, reasons, customer_message(code, **params))
    session.commit()
    return sub


def record_cash(session: Session, clock: Clock, sub_id: int, actor: str, amount_cents: int | None,
                note: str | None) -> Submission:
    """Cash handed to staff in person: there is no bank SMS, so staff record the cash as a credit
    (source='cash', no business account, so the matcher never pairs it with a slip) and approve with it."""
    note = _require_note(note)
    sub = _get_sub(session, sub_id)
    if not amount_cents or amount_cents <= 0:
        raise ActionError("enter the cash amount received", 422)
    order = session.get(Order, sub.order_id)
    now = clock.now()
    body = f"Cash received by {actor}: {format_rs(amount_cents)} for order {order.code}. Note: {note}"
    sms = SmsMessage(business_id=order.business_id, source="cash", sender=actor, device_id=f"cash:{sub.id}",
                     body=body, content_hash=hashlib.sha256(body.encode()).hexdigest(), received_at=now,
                     parser="cash", is_credit=True, amount_cents=amount_cents, txn_at=now, date_source="cash",
                     parse_confidence=1.0, issues=[], created_at=now)
    session.add(sms)
    session.flush()
    audit(session, clock, actor, "cash_recorded", "sms", sms.id,
          {"submission_id": sub.id, "amount_cents": amount_cents, "note": note})
    return staff_approve(session, clock, sub_id, actor, f"[cash] {note}", sms_id=sms.id)


def staff_reject(session: Session, clock: Clock, sub_id: int, actor: str, note: str | None) -> Submission:
    note = _require_note(note)
    sub = _get_sub(session, sub_id)
    held = session.scalar(select(Claim).where(Claim.submission_id == sub.id))
    if held is not None:
        audit(session, clock, actor, "claim_released", "claim", held.id, {"sms_id": held.sms_id, "kind": held.kind})
        session.delete(held)
        session.flush()
    order = session.get(Order, sub.order_id)
    recompute_order(session, order)
    _record(session, clock, sub, "REJECTED", "MANUAL_REJECTED", actor, note, [f"Rejected by {actor}"],
            customer_message("MANUAL_REJECTED", order_code=order.code), confidence=1.0)
    session.commit()
    return sub


def request_new_slip(session: Session, clock: Clock, sub_id: int, actor: str, note: str | None) -> Submission:
    sub = _get_sub(session, sub_id)
    held = session.scalar(select(Claim).where(Claim.submission_id == sub.id, Claim.kind == "HOLD"))
    if held is not None:
        session.delete(held)
        session.flush()
    order = session.get(Order, sub.order_id)
    _record(session, clock, sub, "NEEDS_VERIFICATION", "NEW_SLIP_REQUESTED", actor, note or "new slip requested",
            [f"{actor} asked the customer for a new slip"],
            customer_message("NEW_SLIP_REQUESTED", order_code=order.code), confidence=0.0)
    session.commit()
    return sub


EDITABLE_FIELDS = {"amount_cents", "txn_at", "receiving_account", "reference", "sender_account", "sender_name",
                   "beneficiary_name", "narration", "status"}


def correct_fields(session: Session, clock: Clock, cfg: RulesConfig, sub_id: int, actor: str,
                   fields: dict, note: str | None = None):
    """Staff read the image and fix fields; the SYSTEM then re-decides (so automatic re-checks keep working)."""
    bad = set(fields) - EDITABLE_FIELDS
    if bad:
        raise ActionError(f"fields not editable: {sorted(bad)}", 422)
    sub = _get_sub(session, sub_id)
    before = dict(sub.corrections or {})
    sub.corrections = {**before, **fields}
    sub.decided_by = "system"
    audit(session, clock, actor, "fields_corrected", "submission", sub.id,
          {"before": before, "after": sub.corrections, "note": note})
    session.commit()
    return evaluate(session, sub.id, clock, cfg, note=f"re-evaluated after correction by {actor}")


def customer_credit(session: Session, customer_id: int) -> list[dict]:
    """Held credit per bank credit: excess (overpayment) + unapplied credit, minus what staff already applied."""
    out = []
    for c in session.scalars(select(Claim).where(Claim.customer_id == customer_id, Claim.excess_cents > 0)).all():
        used = session.scalar(select(func.coalesce(func.sum(CreditApplication.amount_cents), 0))
                              .where(CreditApplication.claim_id == c.id)) or 0
        if c.excess_cents - used > 0:
            out.append({"claim_id": c.id, "sms_id": c.sms_id, "from_order_id": c.order_id,
                        "available_cents": c.excess_cents - int(used)})
    return out


def refund_summary(session: Session, customer_id: int) -> dict:
    """What the business owes this customer back: overpayments, late payments / payments on closed orders
    (held as excess), and payments on orders that were cancelled. Minus credit applied to other orders and refunds
    already recorded. This is what staff see when the customer calls the hotline with their customer ID."""
    items = []
    for c in customer_credit(session, customer_id):
        cl = session.get(Claim, c["claim_id"])
        o = session.get(Order, cl.order_id)
        kind = "overpayment" if cl.kind == "ORDER_PAYMENT" else "payment not used for an order"
        items.append({"source": kind, "order_code": o.code, "sms_id": cl.sms_id, "amount_cents": c["available_cents"]})
    for o in session.scalars(select(Order).where(Order.customer_id == customer_id,
                                                 Order.status.in_(("EXPIRED", "CANCELLED")))).all():
        if o.paid_cents > 0:
            items.append({"source": f"order {o.status.lower()}", "order_code": o.code, "sms_id": None,
                          "amount_cents": o.paid_cents})
    refunded = session.scalar(select(func.coalesce(func.sum(Refund.amount_cents), 0))
                              .where(Refund.customer_id == customer_id)) or 0
    owed = sum(i["amount_cents"] for i in items)
    return {"items": items, "owed_cents": owed, "refunded_cents": int(refunded),
            "outstanding_cents": max(0, owed - int(refunded))}


def record_refund(session: Session, clock: Clock, customer_id: int, amount_cents: int, actor: str,
                  note: str | None) -> Refund:
    note = _require_note(note)
    if session.get(Customer, customer_id) is None:
        raise ActionError("customer not found", 404)
    outstanding = refund_summary(session, customer_id)["outstanding_cents"]
    if amount_cents <= 0 or amount_cents > outstanding:
        raise ActionError(f"refund must be between Rs. 0.01 and the outstanding {format_rs(outstanding)}", 409)
    r = Refund(customer_id=customer_id, amount_cents=amount_cents, actor=actor, note=note, created_at=clock.now())
    session.add(r)
    session.flush()
    audit(session, clock, actor, "refund_recorded", "customer", customer_id, {"amount_cents": amount_cents, "note": note})
    session.commit()
    return r


def apply_credit(session: Session, clock: Clock, claim_id: int, order_id: int, actor: str, note: str | None,
                 amount_cents: int | None = None) -> CreditApplication:
    note = _require_note(note)
    claim = session.get(Claim, claim_id)
    order = session.get(Order, order_id)
    if claim is None or order is None:
        raise ActionError("credit or order not found", 404)
    if claim.customer_id != order.customer_id:
        raise ActionError("credit belongs to a different customer", 409)
    avail = next((c["available_cents"] for c in customer_credit(session, claim.customer_id) if c["claim_id"] == claim_id), 0)
    balance = max(0, order.expected_cents - order.paid_cents)
    amt = min(avail, balance) if amount_cents is None else amount_cents
    if amt <= 0 or amt > avail or amt > balance:
        raise ActionError(f"cannot apply {format_rs(max(amt, 0))}: available {format_rs(avail)}, "
                          f"order balance {format_rs(balance)}", 409)
    app_ = CreditApplication(claim_id=claim.id, order_id=order.id, amount_cents=amt, actor=actor, note=note,
                             created_at=clock.now())
    session.add(app_)
    session.flush()
    recompute_order(session, order)
    audit(session, clock, actor, "credit_applied", "order", order.id,
          {"claim_id": claim.id, "amount_cents": amt, "note": note})
    session.commit()
    return app_
