"""Pure domain logic: no database, no network, no clock except what is passed in."""
