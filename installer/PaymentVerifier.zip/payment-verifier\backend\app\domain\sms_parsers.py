"""Pluggable per-bank SMS parser registry.

Each parser gets the raw body plus the time the business phone received it (the only reliable date for
banks that print just HH:MM). Adding a bank = one class + one test with a real sample.
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta

from app.domain.normalize import (
    infer_date_from_received,
    local_dt,
    normalize_account,
    parse_amount_cents,
    parse_date_dmy,
)
from app.domain.types import ParsedSms

_AMT = r"([0-9][0-9,]*(?:\.[0-9]{1,2})?)"
_DEBIT_WORDS = re.compile(r"\b(debit(?:ed)?|withdraw[a-z]*|purchase|payment\s+of|dr\b)", re.I)
_CREDIT_WORDS = re.compile(r"\b(credit(?:ed)?|deposit(?:ed)?|received|cr\b)", re.I)


class SmsParser:
    name = "base"

    def match(self, body: str) -> bool:
        raise NotImplementedError

    def parse(self, body: str, received_at: datetime) -> ParsedSms:
        raise NotImplementedError


class ComBankCreditParser(SmsParser):
    """'Credit for Rs. 5,000.00 to 8026328795 at 16:18 at DIGITAL BANKING DIVISION'

    No date, no reference, no sender: the date comes from received_at.
    """
    name = "combank_credit"
    _re = re.compile(
        r"\b(Credit|Debit)\s+for\s+Rs\.?\s*" + _AMT + r"\s+(?:to|from)\s+([0-9Xx*\-]{6,20})\s+at\s+(\d{1,2}):(\d{2})"
        r"(?:\s+at\s+(.+?))?\s*\.?\s*$",
        re.I | re.S,
    )

    def match(self, body: str) -> bool:
        return bool(self._re.search(body))

    def parse(self, body: str, received_at: datetime) -> ParsedSms:
        m = self._re.search(body)
        assert m
        is_credit = m.group(1).lower() == "credit"
        txn_at = infer_date_from_received(int(m.group(4)), int(m.group(5)), received_at)
        return ParsedSms(
            parser=self.name,
            is_credit=is_credit,
            amount_cents=parse_amount_cents(m.group(2)),
            account=normalize_account(m.group(3)),
            txn_at=txn_at,
            date_source="received_at",
            channel=(m.group(6) or "").strip().upper() or None,
            confidence=0.95,
        )


class PeoplesBankParser(SmsParser):
    """'Dear Sir/Madam, Your A/C 065-2002****90 has been Credited by Rs. 7500.00(Cash Depo. @13:44 28/08/2026).
    [Av_Bal: Rs. 36222.13 at SMS generated]'
    """
    name = "peoples_bank"
    _re = re.compile(
        r"A/C\s*([0-9Xx*\-]{6,24})\s+has\s+been\s+(Credited|Debited)\s+by\s+Rs\.?\s*" + _AMT +
        r"\s*\(\s*([^@)]*?)\s*@\s*(\d{1,2}):(\d{2})\s+(\d{1,2}/\d{1,2}/\d{2,4})\s*\)",
        re.I | re.S,
    )
    _bal = re.compile(r"Av_?Bal\s*:\s*Rs\.?\s*(-?" + _AMT[1:], re.I)

    def match(self, body: str) -> bool:
        return bool(self._re.search(body))

    def parse(self, body: str, received_at: datetime) -> ParsedSms:
        m = self._re.search(body)
        assert m
        issues: list[str] = []
        d = parse_date_dmy(m.group(7))
        h, mi = int(m.group(5)), int(m.group(6))
        if d is None:
            issues.append("date in SMS unreadable; inferred from received time")
            txn_at, src = infer_date_from_received(h, mi, received_at), "received_at"
        else:
            txn_at, src = local_dt(d, h, mi), "sms"
        bal = self._bal.search(body)
        channel = m.group(4).strip().rstrip(".").upper() or None
        if channel and "CASH" in channel:
            channel = "CASH_DEPOSIT"
        return ParsedSms(
            parser=self.name,
            is_credit=m.group(2).lower().startswith("credit"),
            amount_cents=parse_amount_cents(m.group(3)),
            account=normalize_account(m.group(1)),
            txn_at=txn_at,
            date_source=src,
            balance_cents=parse_amount_cents(bal.group(1).replace("-", "")) if bal else None,
            channel=channel,
            confidence=0.97 if d else 0.85,
            issues=issues,
        )


class GenericCreditParser(SmsParser):
    """Fallback, e.g. the brief's 'Rs. 25,000 credited to A/C XXXX1234. Ref 839201.'

    Lower confidence. If no time can be found the SMS is stored but can never auto-confirm a slip
    (time is the confirmation key); staff can still link it manually.
    """
    name = "generic"
    _amt = re.compile(r"(?:Rs\.?|LKR)\s*" + _AMT, re.I)
    _acc = re.compile(r"(?:A/C|acct?|account)\s*(?:no\.?)?\s*[:#]?\s*([0-9Xx*\-]{4,24})", re.I)
    _ref = re.compile(r"\bRef(?:erence)?\.?\s*(?:no\.?)?\s*[:#]?\s*([A-Z0-9\-]{4,30})", re.I)
    _time = re.compile(r"(?:@|\bat\b)?\s*(\d{1,2}):(\d{2})(?::\d{2})?\s*([AP]M)?", re.I)
    _date = re.compile(r"(\d{1,2}[/\-.]\d{1,2}[/\-.]\d{2,4})")

    def match(self, body: str) -> bool:
        return bool(self._amt.search(body)) and bool(_CREDIT_WORDS.search(body) or _DEBIT_WORDS.search(body))

    def parse(self, body: str, received_at: datetime) -> ParsedSms:
        issues: list[str] = []
        amt = self._amt.search(body)
        acc = self._acc.search(body)
        ref = self._ref.search(body)
        tm = self._time.search(body)
        dt_m = self._date.search(body)
        is_credit = bool(_CREDIT_WORDS.search(body)) and not _DEBIT_WORDS.search(body)
        txn_at, src = None, None
        if tm:
            h, mi = int(tm.group(1)), int(tm.group(2))
            if tm.group(3):
                if tm.group(3).upper() == "PM" and h != 12:
                    h += 12
                elif tm.group(3).upper() == "AM" and h == 12:
                    h = 0
            if 0 <= h <= 23 and 0 <= mi <= 59:
                d = parse_date_dmy(dt_m.group(1)) if dt_m else None
                if d:
                    txn_at, src = local_dt(d, h, mi), "sms"
                else:
                    txn_at, src = infer_date_from_received(h, mi, received_at), "received_at"
        if txn_at is None:
            issues.append("no transaction time in SMS; cannot auto-confirm a slip")
        if acc is None:
            issues.append("no account in SMS")
        return ParsedSms(
            parser=self.name,
            is_credit=is_credit,
            amount_cents=parse_amount_cents(amt.group(1)) if amt else None,
            account=normalize_account(acc.group(1)) if acc else None,
            txn_at=txn_at,
            date_source=src,
            reference=ref.group(1) if ref else None,
            confidence=0.75 if txn_at and acc else 0.5,
            issues=issues,
        )


REGISTRY: list[SmsParser] = [ComBankCreditParser(), PeoplesBankParser(), GenericCreditParser()]


def parse_sms(body: str, received_at: datetime) -> ParsedSms | None:
    """Return the first parser's result, or None if no parser recognises the message (stored raw anyway)."""
    text = " ".join((body or "").split())
    for parser in REGISTRY:
        if parser.match(text):
            parsed = parser.parse(text, received_at)
            if parsed.txn_at and parsed.date_source == "sms":
                lag = received_at - parsed.txn_at
                if lag > timedelta(hours=2):
                    parsed.issues.append(f"SMS delivered {lag} after the transaction")
                if lag < -timedelta(minutes=5):
                    parsed.issues.append("SMS transaction time is after the phone received it (clock skew?)")
            return parsed
    return None
