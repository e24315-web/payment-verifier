﻿"""HTTP-level tests: setup -> order -> WhatsApp slip -> SMS webhook -> staff actions, plus webhook security."""
import hashlib
import hmac
import io
import json
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.clock import FixedClock, lk
from app.config import RulesConfig
from app.domain.slip_parsers import extract_slip
from app.imaging.extraction import ExtractionReport, SlipExtractor
from app.imaging.images import sha256_bytes
from app.main import create_app
from app.services.sms_auth import sign
from app.settings import Settings
from tests.fixtures import samples as S

IMG = Path(__file__).parent / "fixtures" / "images"
SECRET = "test-hmac-secret"


class FakeExtractor(SlipExtractor):
    """Maps the real fixture images to their transcribed text (real OCR is covered in test_imaging)."""

    def __init__(self):
        super().__init__([], RulesConfig())
        self.texts = {sha256_bytes((IMG / f).read_bytes()): t for f, t in (
            ("combank_ereceipt.jpeg", S.COMBANK_ERECEIPT), ("combank_flash.jpeg", S.COMBANK_FLASH),
            ("peoples_deposit.jpeg", S.PEOPLES_DEPOSIT))}
        self.calls = 0

    def extract_bytes(self, data):
        self.calls += 1
        sha = sha256_bytes(data)
        ex = extract_slip(self.texts.get(sha, "unreadable"))
        return ExtractionReport(sha, "0" * 16, ex, "T1", latency_ms=5)


@pytest.fixture
def env(tmp_path):
    clock = FixedClock(lk(2026, 9, 26, 16, 0))
    settings = Settings(database_url=f"sqlite:///{tmp_path / 'api.db'}", upload_dir=str(tmp_path / "up"),
                        sms_hmac_secret=SECRET, sms_device_tokens={"phone-1": "tok-1"},
                        sms_sender_allowlist=["COMBANK", "PEOPLESBANK"],
                        whatsapp_verify_token="vt", whatsapp_app_secret="app-secret")
    fx = FakeExtractor()
    app = create_app(settings, clock, RulesConfig(), fx, run_jobs=False)
    with TestClient(app) as c:
        # time windows off for the general API tests; the payment-window tests switch them on
        c.put("/api/business", json={"name": "Rasool Stores", "payment_window_min": None, "balance_window_min": None})
        c.post("/api/accounts", json={"bank": "Commercial Bank", "account": "8026328795",
                                      "holder_names": ["MR MOHAMED RIZAN ATHAYEA RASOOL", "Athayee Kampu"]})
        c.post("/api/accounts", json={"bank": "People's Bank", "account": "065-2002****90",
                                      "holder_names": ["MR ATHAYEA RASOOL"]})
        yield c, clock, fx


def post_sms_webhook(c, body: str, received_at: str, sender="COMBANK", device="phone-1", secret=SECRET):
    import time
    raw = json.dumps({"sender": sender, "body": body, "received_at": received_at}).encode()
    ts = str(int(time.time()))   # replay window is checked against real wall-clock time
    return c.post("/webhooks/sms", content=raw, headers={
        "Content-Type": "application/json", "X-Device-Id": device, "X-Timestamp": ts,
        "X-Signature": sign(secret, ts, raw)})


def send_slip(c, phone, file, caption=None, message_id=None):
    data = {"phone": phone}
    if caption:
        data["caption"] = caption
    if message_id:
        data["message_id"] = message_id
    return c.post("/api/whatsapp/simulate", data=data,
                  files={"image": (file, (IMG / file).read_bytes(), "image/jpeg")}).json()


def test_full_happy_path_order_slip_sms_approved(env):
    c, clock, fx = env
    o = c.post("/api/orders", json={"customer_name": "Rizan", "phone": "0771234567", "amount": "5,000.00"}).json()
    assert o["customer"]["phone"] == "+94771234567" and o["status"] == "AWAITING_PAYMENT"
    conv = c.get("/api/whatsapp/conversations", params={"phone": "+94771234567"}).json()[0]["messages"]
    assert o["code"] in conv[0]["text"] and "8026328795" in conv[0]["text"]     # bank details sent

    clock.set(lk(2026, 9, 26, 16, 20))
    # slip first, SMS later (feed alive thanks to an earlier unrelated SMS)
    assert post_sms_webhook(c, S.combank_sms("1,000.00", "15:00"), "2026-09-26T15:00:20+05:30").status_code == 200
    r = send_slip(c, "0771234567", "combank_ereceipt.jpeg")
    assert r["outcome"] == "NEEDS_VERIFICATION" and "waiting for confirmation" in r["reply"]
    # first sight of an image must log the real OCR tier, not a cache hit (DEBUGGING.md #7)
    assert c.get(f"/api/submissions/{r['submission_id']}").json()["submission"]["extraction_meta"]["tier"] == "T1"
    w = post_sms_webhook(c, S.SMS_A, "2026-09-26T16:18:40+05:30").json()
    assert r["submission_id"] in w["reevaluated_submissions"]
    d = c.get(f"/api/submissions/{r['submission_id']}").json()
    assert d["system_concluded"]["outcome"] == "APPROVED"
    assert {row["field"]: row["status"] for row in d["comparison"]}["Amount"] == "match"
    assert c.get("/api/orders").json()[0]["status"] == "PAID"


def test_order_sends_only_the_account_staff_chose(env):
    c, clock, _ = env
    accs = {a["bank"]: a for a in c.get("/api/business").json()["accounts"]}
    # People's Bank is only known as an SMS mask: it cannot be sent to a customer
    r = c.post("/api/orders", json={"customer_name": "A", "phone": "0770000001", "amount": "7500",
                                    "account_id": accs["People's Bank"]["id"]})
    assert r.status_code == 422 and "full account number" in r.json()["detail"]
    # owner enters the full number (hypothetical here; the real one is not legible on the photo)
    c.patch(f"/api/accounts/{accs["People's Bank"]['id']}",
            json={"bank": "People's Bank", "account": "065-2002-1234-90", "holder_names": ["MR ATHAYEA RASOOL"]})
    # two sendable accounts now: staff must choose
    assert c.post("/api/orders", json={"customer_name": "A", "phone": "0770000001", "amount": "7500"}).status_code == 422
    o = c.post("/api/orders", json={"customer_name": "A", "phone": "0770000001", "amount": "7500",
                                    "account_id": accs["People's Bank"]["id"]}).json()
    assert o["pay_to_account"]["bank"] == "People's Bank"
    text = c.get("/api/whatsapp/conversations", params={"phone": "+94770000001"}).json()[0]["messages"][0]["text"]
    assert "065-2002-1234-90" in text and "8026328795" not in text      # only the chosen account is sent
    # the SMS mask from the bank still matches the now-full account
    m = c.post("/api/sms/simulate", json={"body": S.SMS_B, "received_at": "2026-08-28T13:44:55+05:30"}).json()
    assert m["sms"]["business_account"]["bank"] == "People's Bank"


def test_payment_into_the_other_business_account_is_accepted_with_a_note(env):
    c, clock, _ = env
    accs = {a["bank"]: a for a in c.get("/api/business").json()["accounts"]}
    c.patch(f"/api/accounts/{accs["People's Bank"]['id']}",
            json={"bank": "People's Bank", "account": "065-2002-1234-90", "holder_names": ["MR ATHAYEA RASOOL"]})
    c.post("/api/orders", json={"customer_name": "Rizan", "phone": "0771234567", "amount": "5000",
                                "account_id": accs["People's Bank"]["id"]})      # told to pay People's Bank...
    clock.set(lk(2026, 9, 26, 16, 20))
    post_sms_webhook(c, S.SMS_A, "2026-09-26T16:18:40+05:30")                    # ...but paid into ComBank
    r = send_slip(c, "0771234567", "combank_ereceipt.jpeg")
    d = c.get(f"/api/submissions/{r['submission_id']}").json()
    assert d["system_concluded"]["outcome"] == "APPROVED"
    assert "OTHER_BUSINESS_ACCOUNT" in [f["code"] for f in d["system_concluded"]["flags"]]


def test_order_message_contains_deadline_and_sms_senders_from_settings(env):
    c, clock, _ = env
    c.put("/api/business", json={"name": "Rasool Stores", "hotline": "0112345678",
                                 "payment_window_min": 10, "balance_window_min": 10})
    accs = {a["bank"]: a for a in c.get("/api/business").json()["accounts"]}
    assert any("no SMS sender" in w for w in c.get("/api/health").json()["setup_warnings"])
    cb = accs["Commercial Bank"]
    c.patch(f"/api/accounts/{cb['id']}", json={"bank": cb["bank"], "account": cb["account"],
                                                "holder_names": cb["holder_names"], "sms_senders": ["COMBANK"]})
    o = c.post("/api/orders", json={"customer_name": "Rizan", "phone": "0771234567", "amount": "5000"}).json()
    assert o["expires_at"] is not None and o["customer"]["code"].startswith("C")
    text = c.get("/api/whatsapp/conversations", params={"phone": "+94771234567"}).json()[0]["messages"][0]["text"]
    assert "within 10 minutes" in text and "04:10 PM" in text
    # sender allowlist now comes from the account settings (env allowlist also contains COMBANK/PEOPLESBANK)
    assert post_sms_webhook(c, S.SMS_A, "2026-09-26T16:05:00+05:30", sender="COMBANK").status_code == 200
    assert post_sms_webhook(c, S.SMS_A, "2026-09-26T16:06:00+05:30", sender="SOMEONE").status_code == 403
    # hotline lookup by customer ID
    found = c.get("/api/customers", params={"q": o["customer"]["code"]}).json()
    assert len(found) == 1 and found[0]["refunds"]["outstanding_cents"] == 0


def test_whatsapp_retry_same_message_id_is_idempotent(env):
    c, clock, fx = env
    c.post("/api/orders", json={"customer_name": "Rizan", "phone": "0771234567", "amount": "5000"})
    a = send_slip(c, "0771234567", "combank_ereceipt.jpeg", message_id="wamid.1")
    b = send_slip(c, "0771234567", "combank_ereceipt.jpeg", message_id="wamid.1")
    assert a["submission_id"] == b["submission_id"] and b["duplicate_delivery"]
    assert fx.calls == 1
    # a genuinely new message with the same image: cache hit, zero OCR, logged as CACHE
    d = send_slip(c, "0771234567", "combank_ereceipt.jpeg", message_id="wamid.2")
    assert fx.calls == 1
    assert c.get(f"/api/submissions/{d['submission_id']}").json()["submission"]["extraction_meta"]["tier"] == "CACHE"


def test_resend_after_order_is_paid_is_answered_as_duplicate(env):
    c, clock, _ = env
    c.post("/api/orders", json={"customer_name": "Rizan", "phone": "0771234567", "amount": "5000"})
    clock.set(lk(2026, 9, 26, 16, 20))
    post_sms_webhook(c, S.SMS_A, "2026-09-26T16:18:40+05:30")
    first = send_slip(c, "0771234567", "combank_ereceipt.jpeg")
    assert first["outcome"] == "APPROVED"
    again = send_slip(c, "0771234567", "combank_ereceipt.jpeg")        # order is PAID now: no open order
    assert again["submission_id"] is not None and "already received this payment slip" in again["reply"]


def test_unknown_number_gets_polite_reply_and_no_submission(env):
    c, *_ = env
    r = send_slip(c, "0719999999", "combank_ereceipt.jpeg")
    assert r["submission_id"] is None and "couldn't find an order" in r["reply"]


def test_order_code_in_caption_routes_to_that_order(env):
    c, clock, fx = env
    o1 = c.post("/api/orders", json={"customer_name": "Rizan", "phone": "0771234567", "amount": "5000"}).json()
    o2 = c.post("/api/orders", json={"customer_name": "Rizan", "phone": "0771234567", "amount": "5000"}).json()
    r = send_slip(c, "0771234567", "combank_ereceipt.jpeg", caption=f"paid for {o1['code']}")
    d = c.get(f"/api/submissions/{r['submission_id']}").json()
    assert d["order"]["code"] == o1["code"] and not r["order_guessed"]


# ------------------------------------------------------------------ SMS webhook security

def test_sms_webhook_rejects_bad_signature_wrong_sender_and_replay(env):
    c, *_ = env
    raw = json.dumps({"sender": "COMBANK", "body": S.SMS_A}).encode()
    import time
    ts = str(int(time.time()))
    bad = c.post("/webhooks/sms", content=raw, headers={"X-Device-Id": "phone-1", "X-Timestamp": ts,
                                                         "X-Signature": sign("wrong", ts, raw)})
    assert bad.status_code == 401
    old = str(int(time.time()) - 3600)
    replay = c.post("/webhooks/sms", content=raw, headers={"X-Device-Id": "phone-1", "X-Timestamp": old,
                                                            "X-Signature": sign(SECRET, old, raw)})
    assert replay.status_code == 401
    assert post_sms_webhook(c, S.SMS_A, "", sender="0771234567").status_code == 403   # a customer, not a bank
    assert post_sms_webhook(c, S.SMS_A, "", device="unknown-phone").status_code == 403
    assert c.get("/api/sms").json() == []                                           # nothing stored


def test_sms_webhook_static_token_mode(env):
    c, *_ = env
    c.app.state.pv.settings.sms_hmac_secret = ""
    raw = json.dumps({"sender": "COMBANK", "body": S.SMS_A, "received_at": "2026-09-26T16:18:40+05:30"}).encode()
    ok = c.post("/webhooks/sms", content=raw, headers={"X-Device-Id": "phone-1", "X-Device-Token": "tok-1"})
    assert ok.status_code == 200
    bad = c.post("/webhooks/sms", content=raw, headers={"X-Device-Id": "phone-1", "X-Device-Token": "nope"})
    assert bad.status_code == 401


def test_manual_and_csv_sms_are_marked_by_source(env):
    c, *_ = env
    m = c.post("/api/sms/manual", json={"body": S.SMS_B, "received_at": "2026-08-28T13:44:55"}).json()
    assert m["sms"]["source"] == "manual" and any("manually" in i for i in m["sms"]["issues"])
    csv_text = "received_at,sender,body\n" + f'2026-09-26T16:18:40+05:30,COMBANK,"{S.SMS_A}"\n'
    r = c.post("/api/sms/csv", files={"file": ("sms.csv", csv_text.encode(), "text/csv")}).json()
    assert r["rows"] == 1 and r["created"] == 1
    srcs = {x["source"] for x in c.get("/api/sms").json()}
    assert srcs == {"manual", "csv"}


# ------------------------------------------------------------------ staff actions

def _waiting_submission(c, clock):
    c.post("/api/orders", json={"customer_name": "Rizan", "phone": "0771234567", "amount": "5000"})
    clock.set(lk(2026, 9, 26, 16, 20))
    return send_slip(c, "0771234567", "combank_ereceipt.jpeg")["submission_id"]


def test_approve_override_requires_note_and_bank_credit(env):
    c, clock, _ = env
    sid = _waiting_submission(c, clock)
    assert c.post(f"/api/submissions/{sid}/approve", json={}).status_code == 422            # no note
    r = c.post(f"/api/submissions/{sid}/approve", json={"note": "checked bank app"})
    assert r.status_code == 409 and "bank credit" in r.json()["detail"]                  # no SMS linked
    sms = c.post("/api/sms/manual", json={"body": S.combank_sms("5,000.00", "16:50"),
                                           "received_at": "2026-09-26T16:50:10+05:30"}).json()["sms"]
    ok = c.post(f"/api/submissions/{sid}/approve", json={"note": "seen in bank app", "sms_id": sms["id"]},
                headers={"X-Staff-Name": "Nimal"}).json()
    assert ok["system_concluded"]["outcome"] == "APPROVED" and ok["system_concluded"]["decided_by"] == "staff:Nimal"
    assert ok["order"]["status"] == "PAID"
    assert any(h["note"] == "seen in bank app" for h in ok["history"])


def test_cash_received_in_person_approves_with_a_cash_record(env):
    c, clock, _ = env
    sid = _waiting_submission(c, clock)
    assert c.post(f"/api/submissions/{sid}/cash", json={"amount": "5,000.00"}).status_code == 422   # no note
    assert c.post(f"/api/submissions/{sid}/cash", json={"amount": "0", "note": "cash"}).status_code == 422
    ok = c.post(f"/api/submissions/{sid}/cash", json={"amount": "5,000.00", "note": "paid at the counter"},
                headers={"X-Staff-Name": "Nimal"}).json()
    assert ok["system_concluded"]["outcome"] == "APPROVED" and ok["order"]["status"] == "PAID"
    assert ok["sms_evidence"]["source"] == "cash" and ok["sms_evidence"]["sender"] == "staff:Nimal"
    assert any("paid at the counter" in (h["note"] or "") for h in ok["history"])


def test_reject_releases_held_sms(env):
    c, clock, _ = env
    c.post("/api/orders", json={"customer_name": "Rizan", "phone": "0771234567", "amount": "5000"})
    clock.set(lk(2026, 9, 26, 16, 20))
    post_sms_webhook(c, S.SMS_A, "2026-09-26T16:18:40+05:30")
    post_sms_webhook(c, S.combank_sms("5,000.00", "16:19"), "2026-09-26T16:19:30+05:30")   # ambiguity
    sid = send_slip(c, "0771234567", "combank_ereceipt.jpeg")["submission_id"]
    d = c.get(f"/api/submissions/{sid}").json()
    assert d["system_concluded"]["reason_code"] == "AMBIGUOUS_MATCH" and len(d["sms_candidates"]) == 2
    # staff picks the right SMS from the candidates (manual link)
    linked = c.post(f"/api/submissions/{sid}/approve",
                    json={"note": "customer confirmed 16:18 transfer", "sms_id": d["sms_candidates"][0]["id"]}).json()
    assert linked["system_concluded"]["claim"]["kind"] == "ORDER_PAYMENT"
    rej = c.post(f"/api/submissions/{sid}/reject", json={"note": "changed my mind for test"}).json()
    assert rej["system_concluded"]["claim"] is None and rej["order"]["status"] == "AWAITING_PAYMENT"
    assert len(c.get("/api/sms", params={"unclaimed_only": True}).json()) == 2


def test_request_new_slip_sends_whatsapp_message(env):
    c, clock, _ = env
    sid = _waiting_submission(c, clock)
    c.post(f"/api/submissions/{sid}/request-new-slip", json={"note": "blurry"})
    msgs = c.get("/api/whatsapp/conversations", params={"phone": "+94771234567"}).json()[0]["messages"]
    assert "Please send a clear photo" in msgs[-1]["text"]


def test_unreadable_slip_corrected_by_staff_is_then_verified_by_the_system(env):
    """OCR fails -> UNREADABLE. Staff read the image and type amount/time; the SYSTEM (not staff) then matches
    the SMS and approves. Staff typing values never bypasses the SMS check."""
    c, clock, _ = env
    clock.set(lk(2026, 8, 28, 13, 0))
    o = c.post("/api/orders", json={"customer_name": "Athayea", "phone": "0770000001", "amount": "7500"}).json()
    clock.set(lk(2026, 8, 28, 13, 50))
    c.post("/api/sms/simulate", json={"body": S.SMS_B, "received_at": "2026-08-28T13:44:55+05:30"})
    from PIL import Image
    buf = io.BytesIO()
    Image.new("RGB", (600, 800), "gray").save(buf, "JPEG")        # an image the fake OCR cannot read
    r = c.post("/api/whatsapp/simulate", data={"phone": "0770000001", "caption": o["code"]},
               files={"image": ("blur.jpg", buf.getvalue(), "image/jpeg")}).json()
    sid = r["submission_id"]
    assert c.get(f"/api/submissions/{sid}").json()["system_concluded"]["reason_code"] == "UNREADABLE_SLIP"

    wrong = c.post(f"/api/submissions/{sid}/corrections", json={"fields": {
        "amount": "7,500.00", "txn_at": "2026-08-28T15:10:00+05:30", "receiving_account": "065-2002****90"},
        "note": "typed from image"}).json()
    assert wrong["system_concluded"]["outcome"] != "APPROVED"            # wrong time: no SMS agrees
    ok = c.post(f"/api/submissions/{sid}/corrections", json={"fields": {"txn_at": "2026-08-28T13:43:42+05:30"},
                                                              "note": "re-read stamp"}).json()
    assert ok["system_concluded"]["outcome"] == "APPROVED" and ok["system_concluded"]["decided_by"] == "system"
    assert any(a["action"] == "fields_corrected" for a in ok["audit"])


def test_overpayment_credit_can_be_applied_to_next_order(env):
    c, clock, _ = env
    o1 = c.post("/api/orders", json={"customer_name": "Rizan", "phone": "0771234567", "amount": "4000"}).json()
    clock.set(lk(2026, 9, 26, 16, 20))
    post_sms_webhook(c, S.SMS_A, "2026-09-26T16:18:40+05:30")
    r = send_slip(c, "0771234567", "combank_ereceipt.jpeg")
    assert c.get(f"/api/submissions/{r['submission_id']}").json()["system_concluded"]["reason_code"] == "APPROVED_OVERPAID"
    cust = next(x for x in c.get("/api/customers").json() if x["phone"] == "+94771234567")
    assert cust["credit"][0]["available_cents"] == 100000
    o2 = c.post("/api/orders", json={"customer_name": "Rizan", "phone": "0771234567", "amount": "2500"}).json()
    assert c.post("/api/credits/apply", json={"claim_id": cust["credit"][0]["claim_id"], "order_id": o2["id"]}).status_code == 422
    applied = c.post("/api/credits/apply", json={"claim_id": cust["credit"][0]["claim_id"], "order_id": o2["id"],
                                                  "note": "use overpayment"}).json()
    assert applied["amount_cents"] == 100000 and applied["order"]["status"] == "PARTIALLY_PAID"
    assert applied["order"]["balance_due_cents"] == 150000


# ------------------------------------------------------------------ queue, health, jobs, privacy

def test_queue_puts_needs_action_and_risk_first(env):
    c, clock, _ = env
    c.post("/api/orders", json={"customer_name": "Rizan", "phone": "0771234567", "amount": "5000"})
    c.post("/api/orders", json={"customer_name": "Fraud", "phone": "0772222222", "amount": "5000"})
    clock.set(lk(2026, 9, 26, 16, 20))
    post_sms_webhook(c, S.SMS_A, "2026-09-26T16:18:40+05:30")
    send_slip(c, "0771234567", "combank_ereceipt.jpeg")          # approved (then contested)
    send_slip(c, "0772222222", "combank_ereceipt.jpeg")          # ALREADY_USED
    q = c.get("/api/submissions").json()
    assert q[0]["needs_action"] and q[0]["contested"]             # the contested approval needs a look first
    assert {i["reason_code"] for i in q} == {"APPROVED_PAID", "ALREADY_USED"}


def test_health_reports_stale_feed(env):
    c, *_ = env
    assert c.get("/api/health").json()["sms_feed"]["stale"] is True
    post_sms_webhook(c, S.SMS_A, "2026-09-26T15:59:00+05:30")
    assert c.get("/api/health").json()["sms_feed"]["stale"] is False


def test_jobs_tick_escalates_old_waiting_submissions(env):
    c, clock, _ = env
    post_sms_webhook(c, S.combank_sms("1,000.00", "15:00"), "2026-09-26T15:00:20+05:30")
    sid = _waiting_submission(c, clock)
    assert c.post("/api/jobs/tick").json()["escalated"] == []            # not old enough yet
    clock.advance(minutes=121)
    r = c.post("/api/jobs/tick").json()
    assert r["escalated"] == [sid]
    assert c.get(f"/api/submissions/{sid}").json()["system_concluded"]["reason_code"] == "WAITING_FOR_SMS_EXPIRED"


def test_customer_messages_never_contain_business_balance(env):
    c, clock, _ = env
    c.post("/api/sms/simulate", json={"body": S.SMS_B, "received_at": "2026-08-28T13:44:55+05:30"})
    clock.set(lk(2026, 8, 28, 13, 50))
    o = c.post("/api/orders", json={"customer_name": "A", "phone": "0770000001", "amount": "7500"}).json()
    send_slip(c, "0770000001", "peoples_deposit.jpeg", caption=o["code"])
    for conv in c.get("/api/whatsapp/conversations").json():
        for m in conv["messages"]:
            if m["dir"] == "out":
                assert "36222" not in m["text"] and "36,222" not in m["text"]
    # staff view does show it (it is the owner's own balance)
    assert any(x["balance_cents"] == 3622213 for x in c.get("/api/sms").json())


# ------------------------------------------------------------------ WhatsApp Cloud API webhook

class FakeFetcher:
    def fetch(self, media_id):
        return (IMG / "combank_ereceipt.jpeg").read_bytes()


def test_whatsapp_cloud_webhook_verify_signature_and_parse(env):
    c, clock, _ = env
    assert c.get("/webhooks/whatsapp", params={"hub.mode": "subscribe", "hub.verify_token": "vt",
                                                "hub.challenge": "123"}).text == "123"
    assert c.get("/webhooks/whatsapp", params={"hub.mode": "subscribe", "hub.verify_token": "no",
                                                "hub.challenge": "1"}).status_code == 403
    c.post("/api/orders", json={"customer_name": "Rizan", "phone": "0771234567", "amount": "5000"})
    c.app.state.pv.media_fetcher = FakeFetcher()
    payload = {"entry": [{"changes": [{"value": {"messages": [
        {"id": "wamid.X", "from": "94771234567", "type": "image", "image": {"id": "media-1", "caption": "slip"}}]}}]}]}
    raw = json.dumps(payload).encode()
    sig = "sha256=" + hmac.new(b"app-secret", raw, hashlib.sha256).hexdigest()
    assert c.post("/webhooks/whatsapp", content=raw, headers={"X-Hub-Signature-256": "sha256=bad"}).status_code == 401
    r = c.post("/webhooks/whatsapp", content=raw, headers={"X-Hub-Signature-256": sig}).json()
    assert r["handled"][0]["submission_id"] is not None
    again = c.post("/webhooks/whatsapp", content=raw, headers={"X-Hub-Signature-256": sig}).json()
    assert again["handled"][0]["duplicate_delivery"] is True
