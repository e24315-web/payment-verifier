"""Injectable clock. All business logic asks a Clock for "now"; tests pass a FixedClock."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Protocol

# Sri Lanka has had no DST since 2006, so a fixed offset is exact and avoids a tzdata dependency.
LK_TZ = timezone(timedelta(hours=5, minutes=30), name="Asia/Colombo")


class Clock(Protocol):
    def now(self) -> datetime:  # timezone-aware UTC
        ...


class SystemClock:
    def now(self) -> datetime:
        return datetime.now(timezone.utc)


class OffsetClock:
    """Demo clock: starts at `start` and then runs forward in real time. Lets the real sample slips (dated
    26/09/2026 and 28/08/2026) be replayed live with the 10-minute payment window. Never used unless
    PV_DEMO_START is set."""

    def __init__(self, start: datetime):
        if start.tzinfo is None:
            start = start.replace(tzinfo=LK_TZ)
        self._offset = start.astimezone(timezone.utc) - datetime.now(timezone.utc)

    def now(self) -> datetime:
        return datetime.now(timezone.utc) + self._offset


class FixedClock:
    def __init__(self, at: datetime):
        if at.tzinfo is None:
            raise ValueError("FixedClock needs an aware datetime")
        self._at = at.astimezone(timezone.utc)

    def now(self) -> datetime:
        return self._at

    def set(self, at: datetime) -> None:
        self._at = at.astimezone(timezone.utc)

    def advance(self, **kwargs) -> None:
        self._at = self._at + timedelta(**kwargs)


def lk(year: int, month: int, day: int, hour: int = 0, minute: int = 0, second: int = 0) -> datetime:
    """Build an aware Asia/Colombo datetime (handy in tests and seeds)."""
    return datetime(year, month, day, hour, minute, second, tzinfo=LK_TZ)
