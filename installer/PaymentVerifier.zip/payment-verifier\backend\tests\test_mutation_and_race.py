"""Mutation tests: take an APPROVED case, change exactly one field, assert it is never APPROVED.
Race test: two orders claiming the same bank SMS concurrently -> exactly one wins.
"""
import threading

import pytest
from sqlalchemy.exc import IntegrityError

from app.clock import lk
from app.db.models import Claim
from app.services.verification import create_submission
from tests.fixtures import samples as S

T = lk(2026, 9, 26, 16, 18)


def fresh(world):
    order = world.order("Rizan", 5000, lk(2026, 9, 26, 16, 0))
    world.sms(S.SMS_A, lk(2026, 9, 26, 16, 18, 40))
    return order


def test_baseline_is_approved(world):
    assert world.submit(fresh(world), world.slip(S.COMBANK_ERECEIPT)).outcome == "APPROVED"


MUTATIONS = {
    # amount
    "amount +1 rupee": {"amount_cents": 500100},
    "amount -1 rupee": {"amount_cents": 499900},
    "amount x10": {"amount_cents": 5000000},
    "amount /10": {"amount_cents": 50000},
    # minute (slip minute +1 => SMS would be 1 minute EARLIER than the transaction: impossible)
    "minute +1": {"txn_at": T.replace(minute=19)},
    "minute +2": {"txn_at": T.replace(minute=20)},
    "minute -2": {"txn_at": T.replace(minute=16)},
    "minute -3": {"txn_at": T.replace(minute=15)},
    "minute -10": {"txn_at": T.replace(minute=8)},
    "hour -1": {"txn_at": T.replace(hour=15)},
    "AM instead of PM": {"txn_at": T.replace(hour=4)},
    # date
    "date -1 day": {"txn_at": T.replace(day=25)},
    "date +1 day": {"txn_at": T.replace(day=27)},
    "month -1": {"txn_at": T.replace(month=8)},
    "year -1": {"txn_at": T.replace(year=2025)},
    # status
    "status pending": {"status": "PENDING"},
    "status failed": {"status": "FAILED"},
}
# every single-digit change of the receiving account
for i in range(10):
    acc = list("8026328795")
    acc[i] = str((int(acc[i]) + 1) % 10)
    MUTATIONS[f"account digit {i}"] = {"receiving_account": "".join(acc)}


@pytest.mark.parametrize("name", list(MUTATIONS))
def test_single_field_mutation_of_fresh_case_is_never_approved(world, name):
    r = world.submit(fresh(world), world.slip(S.COMBANK_ERECEIPT, **MUTATIONS[name]))
    assert r.outcome != "APPROVED", f"{name} -> {r.reason}"


def test_documented_tolerance_slip_one_minute_before_sms_is_the_same_payment(world):
    """Design choice, not a hole: SMS may lag the bank by one minute. The slip still names the same single
    unclaimed credit, so no one else's money can be taken this way."""
    r = world.submit(fresh(world), world.slip(S.COMBANK_ERECEIPT, txn_at=T.replace(minute=17)))
    assert r.outcome == "APPROVED"


REUSE_MUTATIONS = {
    **MUTATIONS,
    "unchanged": {},
    "ref last char": {"reference": "O600066186697"},
    "ref first char": {"reference": "X600066186696"},
    "ref removed": {"reference": None, "secondary_reference": None},
    "ref removed + minute -1": {"reference": None, "txn_at": T.replace(minute=17)},
    "ref changed + sender changed": {"reference": "O611111111111", "sender_account": "81******99",
                                     "sender_name": "MR SOMEONE ELSE"},
    "ref changed + name + narration": {"reference": "O622222222222", "narration": "ord123",
                                       "beneficiary_name": "ATHAYEE KAMPU"},
}


@pytest.mark.parametrize("name", list(REUSE_MUTATIONS))
def test_reused_slip_with_any_single_mutation_is_never_approved_for_another_customer(world, name):
    o1 = fresh(world)
    assert world.submit(o1, world.slip(S.COMBANK_ERECEIPT)).outcome == "APPROVED"
    o2 = world.order("Fraudster", 5000, lk(2026, 9, 26, 16, 5))
    r = world.submit(o2, world.slip(S.COMBANK_ERECEIPT, **REUSE_MUTATIONS[name]))
    assert r.outcome != "APPROVED", f"{name} -> {r.reason}"
    assert len([c for c in world.claims() if c.kind == "ORDER_PAYMENT"]) == 1


# ------------------------------------------------------------------ races

def test_claim_unique_constraint_is_enforced_by_the_database(world):
    o = fresh(world)
    r = world.submit(o, world.slip(S.COMBANK_ERECEIPT))
    world.s.add(Claim(sms_id=1, submission_id=r.submission.id, order_id=o.id, customer_id=o.customer_id,
                      kind="ORDER_PAYMENT", created_at=world.clock.now()))
    with pytest.raises(IntegrityError):
        world.s.flush()
    world.s.rollback()


def test_forced_interleaving_both_read_unclaimed_then_both_write(world, monkeypatch):
    """Worst-case interleaving, forced deterministically: both threads gather evidence and decide
    'APPROVE, claim SMS #1' BEFORE either writes. Two different customers, no reference, different
    minutes (16:18 exact / 16:17 lag), so duplicate/reuse checks cannot see each other.
    Only UNIQUE(claims.sms_id) + retry can prevent a double approval."""
    import app.services.verification as v

    world.sms(S.SMS_A, lk(2026, 9, 26, 16, 18, 40))
    orders = [world.order(n, 5000, lk(2026, 9, 26, 16, 0)) for n in ("Racer1", "Racer2")]
    slips = [world.slip(S.COMBANK_ERECEIPT, reference=None, secondary_reference=None, sender_account=None),
             world.slip(S.COMBANK_ERECEIPT, reference=None, secondary_reference=None, sender_account=None,
                        txn_at=T.replace(minute=17))]
    # create both submissions first (no evaluation), sequentially
    from app.db.models import Submission
    subs = []
    for i in range(2):
        s = Submission(order_id=orders[i].id, customer_id=orders[i].customer_id, image_sha256=f"race-{i}",
                       extraction=slips[i].to_dict(), created_at=world.clock.now(), updated_at=world.clock.now())
        world.s.add(s)
        world.s.commit()
        subs.append(s.id)

    barrier = threading.Barrier(2, timeout=10)
    local = threading.local()
    calls: list[tuple[int, str]] = []
    real_decide = v.decide

    def decide_then_wait(inp):
        d = real_decide(inp)
        calls.append((threading.get_ident(), d.reason_code))
        if not getattr(local, "waited", False):   # only the first attempt waits; the retry must not
            local.waited = True
            barrier.wait()
        return d

    monkeypatch.setattr(v, "decide", decide_then_wait)
    results, errors = {}, []

    def run(i):
        s = world.sf()
        try:
            d = v.evaluate(s, subs[i], world.clock, world.cfg)
            results[i] = (d.outcome.value, d.reason_code)
        except Exception as e:  # pragma: no cover
            errors.append(repr(e))
        finally:
            s.close()

    threads = [threading.Thread(target=run, args=(i,)) for i in range(2)]
    [t.start() for t in threads]
    [t.join() for t in threads]
    assert not errors, errors
    # Both first attempts decided to approve (the dangerous state was really reached)...
    assert [c for _, c in calls[:2]] == ["APPROVED_PAID", "APPROVED_PAID"], calls
    # ...one of them hit the constraint and re-decided (3 decide calls total)...
    assert len(calls) == 3, calls
    # ...and exactly one approval / one claim survived. The loser is ALREADY_USED and the winner is
    # marked contested so staff look at both (one of the two customers is not the real payer).
    assert sorted(results.values()) == [("APPROVED", "APPROVED_PAID"), ("REJECTED", "ALREADY_USED")], results
    world.s.expire_all()
    assert len(world.claims()) == 1
    winner = next(i for i, r in results.items() if r[0] == "APPROVED")
    assert world.s.get(Submission, subs[winner]).contested is True


def test_race_repeated_many_times(world, engine):
    """Smoke test only: un-forced concurrent submissions. On SQLite these usually serialise and never reach
    the constraint (see DEBUGGING.md #2); the forced-interleaving test above is the real proof."""
    from app.db.session import make_session_factory
    sf = make_session_factory(engine)
    approvals_per_round = []
    for k in range(15):
        minute = 10 + k * 3
        hh = f"17:{minute:02d}"
        world.sms(S.combank_sms("5,000.00", hh), lk(2026, 9, 26, 17, minute, 30))
        orders = [world.order(f"R{k}-{i}", 5000, lk(2026, 9, 26, 16, 0)) for i in range(2)]
        t = lk(2026, 9, 26, 17, minute)
        slips = [world.slip(S.COMBANK_ERECEIPT, reference=None, secondary_reference=None, sender_account=None,
                            txn_at=t, generated_at=t),
                 world.slip(S.COMBANK_ERECEIPT, reference=None, secondary_reference=None, sender_account=None,
                            txn_at=t.replace(minute=minute - 1), generated_at=t)]
        world.clock.set(lk(2026, 9, 26, 17, minute, 50))
        barrier = threading.Barrier(2)
        res = []

        def run(i):
            s = sf()
            try:
                barrier.wait()
                _, d = create_submission(s, orders[i].id, slips[i], world.clock, world.cfg, image_sha256=f"r{k}-{i}")
                res.append(d.outcome.value)
            finally:
                s.close()

        ths = [threading.Thread(target=run, args=(i,)) for i in range(2)]
        [x.start() for x in ths]
        [x.join() for x in ths]
        approvals_per_round.append(res.count("APPROVED"))
    assert max(approvals_per_round) <= 1, approvals_per_round
