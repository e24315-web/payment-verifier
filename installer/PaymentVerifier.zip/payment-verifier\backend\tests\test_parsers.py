from app.clock import lk
from app.domain.slip_parsers import extract_slip
from app.domain.sms_parsers import parse_sms
from app.domain.types import SlipType
from tests.fixtures import samples as S


# ------------------------------------------------------------------ SMS

def test_combank_sms_real_sample():
    p = parse_sms(S.SMS_A, lk(2026, 9, 26, 16, 18, 40))
    assert p.parser == "combank_credit" and p.is_credit
    assert p.amount_cents == 500000
    assert p.account == "8026328795"
    assert p.txn_at == lk(2026, 9, 26, 16, 18)
    assert p.date_source == "received_at"
    assert p.balance_cents is None and p.reference is None


def test_peoples_sms_real_sample():
    p = parse_sms(S.SMS_B, lk(2026, 8, 28, 13, 45, 3))
    assert p.parser == "peoples_bank" and p.is_credit
    assert p.amount_cents == 750000                      # the credit, NOT the Av_Bal
    assert p.balance_cents == 3622213                    # internal only
    assert p.account == "0652002****90"
    assert p.txn_at == lk(2026, 8, 28, 13, 44)
    assert p.date_source == "sms"
    assert p.channel == "CASH_DEPOSIT"


def test_peoples_sms_without_closing_bracket_as_pasted_by_owner():
    body = S.SMS_B.rstrip("]")
    p = parse_sms(body, lk(2026, 8, 28, 13, 45))
    assert p.amount_cents == 750000 and p.balance_cents == 3622213


def test_debit_sms_is_not_a_credit():
    p = parse_sms(S.combank_sms("5,000.00", "16:18", kind="Debit"), lk(2026, 9, 26, 16, 19))
    assert p is not None and not p.is_credit


def test_generic_brief_example_has_no_time_so_cannot_confirm():
    p = parse_sms("Rs. 25,000 credited to A/C XXXX1234. Ref 839201.", lk(2026, 9, 26, 10, 0))
    assert p.parser == "generic" and p.is_credit
    assert p.amount_cents == 2500000 and p.account == "****1234" and p.reference == "839201"
    assert p.txn_at is None
    assert any("no transaction time" in i for i in p.issues)


def test_unrecognised_sms_returns_none():
    assert parse_sms("Your OTP is 123456", lk(2026, 9, 26, 10, 0)) is None


def test_late_delivered_sms_is_flagged():
    p = parse_sms(S.SMS_B, lk(2026, 8, 30, 9, 0))
    assert any("delivered" in i for i in p.issues)


# ------------------------------------------------------------------ slips

def test_combank_ereceipt_fields():
    ex = extract_slip(S.COMBANK_ERECEIPT)
    assert ex.template == "combank_ereceipt" and ex.slip_type == SlipType.ONLINE_TRANSFER
    assert ex.get("amount_cents") == 500000
    assert ex.get("txn_at") == lk(2026, 9, 26, 16, 18)
    assert ex.get("receiving_account") == "8026328795"
    assert ex.get("reference") == "O600066186696"
    assert ex.get("secondary_reference") == "CCE1-2AD2-6445-6ED6"
    assert ex.get("sender_account") == "80******73"
    assert ex.get("sender_name") == "MR MOHAMED RIZAN ABDUR RASHEED"
    assert ex.get("beneficiary_name") == "MR MOHAMED RIZAN ATHAYEA RASOOL"
    assert ex.get("narration") == "rasool"
    assert ex.get("status") == "COMPLETED"
    assert ex.get("generated_at") == lk(2026, 9, 26, 16, 18)
    assert ex.flags == []


def test_combank_ereceipt_generated_before_transaction_is_flagged():
    text = S.COMBANK_ERECEIPT.replace("Generated at 9/26/26 4:18 PM", "Generated at 9/25/26 4:18 PM")
    ex = extract_slip(text)
    assert "GENERATED_BEFORE_TXN" in [f.code for f in ex.flags]


def test_combank_ereceipt_payment_date_disagreement_is_flagged():
    text = S.COMBANK_ERECEIPT.replace("Payment Date 26-09-26", "Payment Date 25-09-26")
    assert "DATE_FIELDS_DISAGREE" in [f.code for f in extract_slip(text).flags]


def test_combank_flash_fields_with_wrapped_time():
    ex = extract_slip(S.COMBANK_FLASH)
    assert ex.template == "combank_flash"
    assert ex.get("amount_cents") == 5100000
    assert ex.get("txn_at") == lk(2026, 9, 24, 22, 1, 29)
    assert ex.get("txn_has_seconds") is True
    assert ex.get("receiving_account") == "8026328795"
    assert ex.get("sender_account") == "8028556219"
    assert ex.get("reference") == "WT33426219"
    assert ex.get("beneficiary_name") == "Athayee Kampu"
    assert ex.get("narration") == "lap"
    assert ex.get("status") == "COMPLETED"


def test_peoples_deposit_slip_uses_machine_line_only():
    ex = extract_slip(S.PEOPLES_DEPOSIT)
    assert ex.template == "peoples_deposit_slip" and ex.slip_type == SlipType.CASH_DEPOSIT
    assert ex.get("amount_cents") == 750000
    assert ex.get("txn_at") == lk(2026, 8, 28, 13, 44, 42)
    assert ex.get("status") == "COMPLETED"
    assert ex.get("receiving_account") == "0652002*00**90"
    assert ex.conf("receiving_account") < 0.85        # partial account is never trusted for decisions
    assert ex.get("sender_account") is None            # cash deposits have no payer account
    assert ex.get("reference") is None
    assert ex.get("teller_sequence") == "1HC-203-02/2655931"


def test_peoples_amount_with_ocr_slash_is_not_guessed_but_other_line_used():
    text = S.PEOPLES_DEPOSIT.replace("CASH LKR 7,500.00 CR", "CASH LKR /,500.00 CR")
    ex = extract_slip(text)
    assert ex.get("amount_cents") == 750000             # from the second, clean machine line
    assert ex.conf("amount_cents") < extract_slip(S.PEOPLES_DEPOSIT).conf("amount_cents")


def test_peoples_amount_unreadable_everywhere():
    text = S.PEOPLES_DEPOSIT.replace("7,500.00", "/,500.00")
    ex = extract_slip(text)
    assert ex.get("amount_cents") is None
    assert "AMOUNT_UNPARSEABLE" in [f.code for f in ex.flags]


def test_peoples_slip_without_validation_stamp():
    text = "PEOPLE'S BANK Deposit Slip Customer Copy Form No213 DP\nName Athaye Rasool\n7500 00"
    ex = extract_slip(text)
    assert ex.get("txn_at") is None
    assert "NO_TELLER_VALIDATION" in [f.code for f in ex.flags]


# RapidOCR text of two AI-generated cash-deposit slips the user tested (unknown banks, handwritten, no time).
LANKA_DEMO = """Lanka Demo Bank /m / Branch
People·Progress·Together CASH DEPOSIT SLIP Kandy Branch
2 / G / Date / Details of Cash
28/09/2026 Savings / /Current
(DD / MM / YYYY) / / Other Denomination No. of Pieces Amount (LKR)
/ Lu /Account Name 5,000 5 25,000.00
1,000
2 / 6 6& /Account Number Test Books (Pvt) Ltd XXXXXX1234 500 100 50 AYMENT
/ / Depositor Name A. Kumar TEST-25000-001 OCR TEST IMAGE NOTA RLAL / / Total 20 10 25,000.00
Transaction No. Deposit Type Depositor Signature
LD202609280153 /Cheque / /Other A. Kuman"""

HNB_BOXES = """HATTON NATIONAL BANK CASH DEPOSIT SLIP
Account Type / Details of Cash
28 9 202 968 380 Savings
/Account Number
100
1 2 3 4 1 2 3 4 50
/ / Depositor Name 20
A. Kumar 10
/ Reference
Order Payment - ISEN 1045 / / Total 25,000.00
Transaction No.
092010082401"""


def test_unknown_bank_cash_slip_is_read_but_never_trusted():
    ex = extract_slip(LANKA_DEMO)
    assert ex.template == "generic" and ex.slip_type == SlipType.CASH_DEPOSIT
    assert ex.get("amount_cents") == 2500000
    assert ex.get("txn_date") == "2026-09-28" and ex.get("txn_at") is None      # a date but no time
    assert ex.get("receiving_account") == "******1234"
    assert ex.get("sender_name") == "A. Kumar"
    assert ex.get("reference") == "LD202609280153"
    assert ex.get("bank") == "LANKA DEMO BANK"
    assert {"NO_TIME_ON_SLIP", "NO_TELLER_VALIDATION"} <= {f.code for f in ex.flags}
    assert ex.conf("amount_cents") < 0.85                                        # unknown layout -> a person


def test_digit_boxes_are_read_without_swallowing_neighbouring_rows():
    ex = extract_slip(HNB_BOXES)
    assert ex.get("receiving_account") == "12341234"      # not '0123412345' (from '100' and '50' around it)
    assert ex.get("bank") == "HATTON NATIONAL BANK"
    assert ex.get("reference") == "092010082401"
    assert ex.get("amount_cents") == 2500000


def test_other_banks_deposit_slip_is_not_mistaken_for_peoples_bank():
    from app.domain.slip_parsers import PeoplesBankDepositSlip
    assert PeoplesBankDepositSlip().score(LANKA_DEMO + "\nCash Depositor Signature") == 0


def test_unknown_layout_falls_back_to_generic_with_low_confidence():
    ex = extract_slip("Some Bank\nAmount: LKR 5,000.00\n26/09/2026 16:18\nRef ABC12345\nTo Account 8026328795")
    assert ex.template == "generic"
    assert ex.get("amount_cents") == 500000
    assert ex.conf("txn_at") < 0.9
