"""Scenario matrix: the 12 brief scenarios + the owner's extra fraud cases, end to end through the services
and a real SQLite database. Each test name says the scenario; each asserts outcome AND reason code.

Clock default: 26/09/2026 16:20 Asia/Colombo (2 minutes after fixture A's transfer).
"""
from datetime import timedelta

from sqlalchemy import select

from app.clock import lk
from app.db.models import AuditLog, DecisionRecord
from app.domain.slip_parsers import extract_slip
from tests.fixtures import samples as S

A_TIME = lk(2026, 9, 26, 16, 18)
A_RECEIVED = lk(2026, 9, 26, 16, 18, 40)
ORDER_A_CREATED = lk(2026, 9, 26, 16, 0)


def setup_a(world, customer="Rizan", amount=5000):
    order = world.order(customer, amount, ORDER_A_CREATED)
    world.sms(S.SMS_A, A_RECEIVED)
    return order


# =============================================================== 1. normal payment

def test_01_normal_online_payment_combank_ereceipt(world):
    order = setup_a(world)
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT))
    assert (r.outcome, r.reason) == ("APPROVED", "APPROVED_PAID")
    assert r.decision.confidence >= 0.85
    assert world.refresh(order).status == "PAID"
    assert [c.kind for c in world.claims()] == ["ORDER_PAYMENT"]
    assert "received your payment of Rs. 5,000.00" in world.outbox()[-1].body


def test_02_normal_cash_deposit_peoples_bank(world):
    world.clock.set(lk(2026, 8, 28, 13, 50))
    order = world.order("Athayea", 7500, lk(2026, 8, 28, 13, 0))
    world.sms(S.SMS_B, lk(2026, 8, 28, 13, 44, 55))
    r = world.submit(order, world.slip(S.PEOPLES_DEPOSIT))
    assert (r.outcome, r.reason) == ("APPROVED", "APPROVED_PAID")


def test_03_cash_deposit_stamp_one_minute_before_sms_is_accepted_when_isolated(world):
    """Photo is ambiguous between 13:43 and 13:44. 13:43:42 stamp + 13:44 SMS = normal SMS lag."""
    world.clock.set(lk(2026, 8, 28, 13, 50))
    order = world.order("Athayea", 7500, lk(2026, 8, 28, 13, 0))
    world.sms(S.SMS_B, lk(2026, 8, 28, 13, 44, 55))
    r = world.submit(order, world.slip(S.PEOPLES_DEPOSIT.replace("13:44:42", "13:43:42")))
    assert (r.outcome, r.reason) == ("APPROVED", "APPROVED_PAID")


def test_04_normal_flash_app_payment_with_synthetic_sms(world):
    world.clock.set(lk(2026, 9, 24, 22, 5))
    order = world.order("Kampu", 51000, lk(2026, 9, 24, 21, 30))
    world.sms(S.SMS_C_SYNTHETIC, lk(2026, 9, 24, 22, 1, 50))
    r = world.submit(order, world.slip(S.COMBANK_FLASH))
    assert (r.outcome, r.reason) == ("APPROVED", "APPROVED_PAID")


# =============================================================== 2. wrong amount

def test_05_underpaid_then_balance_paid(world):
    order = setup_a(world, amount=8000)
    r1 = world.submit(order, world.slip(S.COMBANK_ERECEIPT))
    assert (r1.outcome, r1.reason) == ("APPROVED", "APPROVED_UNDERPAID")
    assert world.refresh(order).status == "PARTIALLY_PAID" and order.paid_cents == 500000
    assert "remaining balance is Rs. 3,000.00" in world.outbox()[-1].body

    world.clock.set(lk(2026, 9, 26, 16, 35))
    world.sms(S.combank_sms("3,000.00", "16:30"), lk(2026, 9, 26, 16, 30, 20))
    r2 = world.submit(order, world.slip(S.COMBANK_ERECEIPT, amount_cents=300000, txn_at=lk(2026, 9, 26, 16, 30),
                                        reference="O600066199999", generated_at=lk(2026, 9, 26, 16, 30)))
    assert (r2.outcome, r2.reason) == ("APPROVED", "APPROVED_PAID")
    assert world.refresh(order).status == "PAID" and order.paid_cents == 800000


def test_06_overpaid_keeps_excess_as_credit(world):
    order = setup_a(world, amount=4000)
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT))
    assert (r.outcome, r.reason) == ("APPROVED", "APPROVED_OVERPAID")
    claim = world.claims()[0]
    assert (claim.applied_cents, claim.excess_cents) == (400000, 100000)
    assert world.refresh(order).status == "PAID"


def test_07_slip_amount_differs_from_sms_at_same_minute_is_conflict(world):
    """Edited amount: slip says 50,000 but the bank credited 5,000 at that minute."""
    order = setup_a(world, amount=50000)
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT, amount_cents=5000000))
    assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "SMS_CONFLICT")
    assert world.claims() == []


# =============================================================== 3. wrong account

def test_08_wrong_receiving_account_rejected(world):
    order = setup_a(world)
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT, receiving_account="8026328799"))
    assert (r.outcome, r.reason) == ("REJECTED", "WRONG_ACCOUNT")


def test_09_wrong_account_read_with_low_confidence_goes_to_review(world):
    order = setup_a(world)
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT, receiving_account=("8026328799", 0.7)))
    assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "ACCOUNT_UNCERTAIN")


# =============================================================== 4. duplicate payment

def test_10_same_image_twice_for_same_order_returns_prior_decision(world):
    order = setup_a(world)
    r1 = world.submit(order, world.slip(S.COMBANK_ERECEIPT), sha="img-A")
    r2 = world.submit(order, world.slip(S.COMBANK_ERECEIPT), sha="img-A")
    assert r1.outcome == "APPROVED"
    assert (r2.outcome, r2.reason) == ("APPROVED", "DUPLICATE_SUBMISSION")
    assert r2.submission.duplicate_of == r1.submission.id
    assert len(world.claims()) == 1 and world.refresh(order).paid_cents == 500000


def test_11_whatsapp_webhook_retry_is_idempotent(world):
    order = setup_a(world)
    r1 = world.submit(order, world.slip(S.COMBANK_ERECEIPT), msg_id="wamid.123")
    r2 = world.submit(order, world.slip(S.COMBANK_ERECEIPT), msg_id="wamid.123")
    assert r1.submission.id == r2.submission.id
    n = world.s.scalar(select(DecisionRecord.id).where(DecisionRecord.submission_id == r1.submission.id)
                       .order_by(DecisionRecord.id.desc()))
    assert len(world.s.scalars(select(DecisionRecord).where(DecisionRecord.submission_id == r1.submission.id)).all()) == 1
    assert n is not None


# =============================================================== 5. reused payment (another customer's order)

def test_12_reused_online_slip_for_another_customer_rejected_and_original_contested(world):
    o1 = setup_a(world, customer="Rizan")
    o2 = world.order("Fraudster", 5000, lk(2026, 9, 26, 16, 5))
    r1 = world.submit(o1, world.slip(S.COMBANK_ERECEIPT), sha="img-A")
    r2 = world.submit(o2, world.slip(S.COMBANK_ERECEIPT), sha="img-A-forwarded")
    assert r1.outcome == "APPROVED"
    assert (r2.outcome, r2.reason) == ("REJECTED", "ALREADY_USED")
    assert world.refresh(r1.submission).contested is True
    assert "already been used for another order" in world.outbox("Fraudster")[-1].body


def test_13_reused_cash_slip_for_another_customer_rejected(world):
    world.clock.set(lk(2026, 8, 28, 13, 50))
    o1 = world.order("Athayea", 7500, lk(2026, 8, 28, 13, 0))
    o2 = world.order("Other", 7500, lk(2026, 8, 28, 13, 10))
    world.sms(S.SMS_B, lk(2026, 8, 28, 13, 44, 55))
    assert world.submit(o1, world.slip(S.PEOPLES_DEPOSIT)).outcome == "APPROVED"
    r2 = world.submit(o2, world.slip(S.PEOPLES_DEPOSIT))
    assert (r2.outcome, r2.reason) == ("REJECTED", "ALREADY_USED")


def test_14_reference_with_ocr_o_zero_confusion_still_detected_as_reuse(world):
    o1 = setup_a(world, customer="Rizan")
    o2 = world.order("Fraudster", 5000, lk(2026, 9, 26, 16, 5))
    world.submit(o1, world.slip(S.COMBANK_ERECEIPT))
    r2 = world.submit(o2, world.slip(S.COMBANK_ERECEIPT, reference="0600066186696"))
    assert (r2.outcome, r2.reason) == ("REJECTED", "ALREADY_USED")


def test_15_same_customer_same_payment_for_a_different_order_goes_to_review(world):
    o1 = setup_a(world, customer="Rizan")
    o2 = world.order("Rizan", 5000, lk(2026, 9, 26, 16, 10))
    world.submit(o1, world.slip(S.COMBANK_ERECEIPT))
    r2 = world.submit(o2, world.slip(S.COMBANK_ERECEIPT))
    assert (r2.outcome, r2.reason) == ("NEEDS_VERIFICATION", "SAME_CUSTOMER_OTHER_ORDER")


def test_16_fraudster_first_and_rejected_does_not_block_real_payer(world):
    """Fraudster sends the victim's slip for an order created AFTER the transfer -> OLD_PAYMENT.
    The real payer must not then be rejected as ALREADY_USED; they go to review instead."""
    world.clock.set(lk(2026, 9, 26, 16, 45))
    fraud_order = world.order("Fraudster", 5000, lk(2026, 9, 26, 16, 40))
    world.sms(S.SMS_A, A_RECEIVED)
    rf = world.submit(fraud_order, world.slip(S.COMBANK_ERECEIPT))
    assert (rf.outcome, rf.reason) == ("REJECTED", "OLD_PAYMENT")
    real_order = world.order("Rizan", 5000, ORDER_A_CREATED)
    rr = world.submit(real_order, world.slip(S.COMBANK_ERECEIPT))
    assert rr.outcome == "NEEDS_VERIFICATION" and rr.reason == "SUSPICIOUS"
    assert "SEEN_ON_OTHER_CUSTOMER" in [f["code"] for f in rr.submission.flags]


# =============================================================== 6. same payment, different image

def test_17_same_transaction_different_image_same_order_is_duplicate(world):
    order = setup_a(world)
    r1 = world.submit(order, world.slip(S.COMBANK_ERECEIPT), sha="screenshot")
    r2 = world.submit(order, world.slip(S.COMBANK_ERECEIPT, ocr_conf=0.97), sha="photo-of-screen")
    assert (r2.outcome, r2.reason) == ("APPROVED", "DUPLICATE_SUBMISSION")
    assert r2.submission.duplicate_of == r1.submission.id


def test_18_cropped_reference_different_image_other_customer_still_caught(world):
    o1 = setup_a(world, customer="Rizan")
    o2 = world.order("Fraudster", 5000, lk(2026, 9, 26, 16, 5))
    world.submit(o1, world.slip(S.COMBANK_ERECEIPT))
    r2 = world.submit(o2, world.slip(S.COMBANK_ERECEIPT, reference=None, secondary_reference=None))
    assert (r2.outcome, r2.reason) == ("REJECTED", "ALREADY_USED")


# =============================================================== 7. old payment

def test_19_old_cash_deposit_for_new_order_rejected(world):
    """Fixture B is a month old relative to 'today' (28/09/2026)."""
    world.clock.set(lk(2026, 9, 28, 10, 5))
    world.sms(S.SMS_B, lk(2026, 8, 28, 13, 44, 55))
    order = world.order("Athayea", 7500, lk(2026, 9, 28, 10, 0))
    r = world.submit(order, world.slip(S.PEOPLES_DEPOSIT))
    assert (r.outcome, r.reason) == ("REJECTED", "OLD_PAYMENT")


def test_19b_old_payment_with_single_uncorroborated_date_goes_to_review_not_rejected(world):
    """Flash receipts print one date only. An OCR misread of that date must not hard-reject a real payer."""
    world.clock.set(lk(2026, 9, 28, 10, 5))
    world.sms(S.SMS_C_SYNTHETIC, lk(2026, 9, 24, 22, 1, 50))
    order = world.order("Kampu", 51000, lk(2026, 9, 28, 10, 0))
    r = world.submit(order, world.slip(S.COMBANK_FLASH))
    assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "OLD_PAYMENT_UNCONFIRMED")
    # staff looks at the image, confirms the date -> now it is corroborated and rejected as old
    from app.services.verification import evaluate
    r.submission.corrections = {"txn_at": lk(2026, 9, 24, 22, 1, 29).isoformat()}
    world.s.commit()
    d = evaluate(world.s, r.submission.id, world.clock, world.cfg, actor="staff:test")
    assert (d.outcome.value, d.reason_code) == ("REJECTED", "OLD_PAYMENT")


def test_20_payment_minutes_before_order_creation_goes_to_review(world):
    order = world.order("Rizan", 5000, lk(2026, 9, 26, 16, 25))
    world.sms(S.SMS_A, A_RECEIVED)
    world.clock.set(lk(2026, 9, 26, 16, 30))
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT))
    assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "PAID_BEFORE_ORDER_GRACE")


# =============================================================== 8. edited / suspicious slip

def test_21_known_reference_with_edited_amount_is_flagged(world):
    o1 = setup_a(world, customer="Rizan")
    o2 = world.order("Fraudster", 50000, lk(2026, 9, 26, 16, 5))
    world.submit(o1, world.slip(S.COMBANK_ERECEIPT))
    r2 = world.submit(o2, world.slip(S.COMBANK_ERECEIPT, amount_cents=5000000))
    assert (r2.outcome, r2.reason) == ("NEEDS_VERIFICATION", "REFERENCE_REUSED_DIFFERENT_DETAILS")


def test_22_edited_time_does_not_match_sms_minute(world):
    order = setup_a(world)
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT, txn_at=lk(2026, 9, 26, 16, 25)))
    assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "SMS_CONFLICT")


def test_23_receipt_generated_before_transaction_is_suspicious_and_sms_held(world):
    order = setup_a(world)
    text = S.COMBANK_ERECEIPT.replace("Generated at 9/26/26 4:18 PM", "Generated at 9/25/26 4:18 PM")
    r = world.submit(order, extract_slip(text))
    assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "SUSPICIOUS")
    assert [c.kind for c in world.claims()] == ["HOLD"]
    assert world.refresh(order).paid_cents == 0          # a HOLD never counts as payment


def test_24_image_tamper_signal_alone_never_approves_or_rejects(world):
    from app.domain.types import Flag, Severity
    from app.services.verification import build_input
    from app.domain.decision import decide
    order = setup_a(world)
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT))
    assert r.outcome == "APPROVED"
    inp = build_input(world.s, r.submission, world.clock, world.cfg)
    inp.extra_flags = [Flag("ELA_HOTSPOT", Severity.MEDIUM, "edited region near amount")]
    d = decide(inp)
    assert (d.outcome.value, d.reason_code) == ("NEEDS_VERIFICATION", "SUSPICIOUS")
    world.s.rollback()


def test_25_future_dated_slip(world):
    order = setup_a(world)
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT, txn_at=lk(2026, 9, 27, 16, 18)))
    assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "FUTURE_DATED")


def test_26_pending_or_scheduled_transfer_not_accepted(world):
    order = setup_a(world)
    for status in ("PENDING", "SCHEDULED"):
        r = world.submit(order, world.slip(S.COMBANK_ERECEIPT, status=status))
        assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "NOT_COMPLETED")


def test_26b_completed_slip_after_pending_slip_is_evaluated_not_treated_as_duplicate(world):
    order = setup_a(world)
    r1 = world.submit(order, world.slip(S.COMBANK_ERECEIPT, status="PENDING"))
    assert r1.reason == "NOT_COMPLETED"
    r2 = world.submit(order, world.slip(S.COMBANK_ERECEIPT))
    assert (r2.outcome, r2.reason) == ("APPROVED", "APPROVED_PAID")


def test_26c_clearer_slip_after_unreadable_slip_is_evaluated(world):
    order = setup_a(world)
    r1 = world.submit(order, world.slip(S.COMBANK_ERECEIPT, ocr_conf=0.8))
    assert r1.reason == "UNREADABLE_SLIP"
    r2 = world.submit(order, world.slip(S.COMBANK_ERECEIPT))
    assert (r2.outcome, r2.reason) == ("APPROVED", "APPROVED_PAID")


def test_27_new_sender_account_for_known_customer_is_soft_flag_only(world):
    o1 = setup_a(world, customer="Rizan")
    world.submit(o1, world.slip(S.COMBANK_ERECEIPT))
    o2 = world.order("Rizan", 2000, lk(2026, 9, 26, 17, 0))
    world.clock.set(lk(2026, 9, 26, 17, 10))
    world.sms(S.combank_sms("2,000.00", "17:05"), lk(2026, 9, 26, 17, 5, 30))
    r = world.submit(o2, world.slip(S.COMBANK_ERECEIPT, amount_cents=200000, txn_at=lk(2026, 9, 26, 17, 5),
                                    reference="O600066100001", sender_account="8011111199",
                                    generated_at=lk(2026, 9, 26, 17, 5)))
    assert (r.outcome, r.reason) == ("APPROVED", "APPROVED_PAID")
    assert "NEW_SENDER_ACCOUNT" in [f["code"] for f in r.submission.flags]


# =============================================================== 9. unclear image

def test_28_amount_unreadable(world):
    order = setup_a(world)
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT, amount_cents=None))
    assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "UNREADABLE_SLIP")
    assert "clearer photo" in world.outbox()[-1].body


def test_29_time_cropped_out(world):
    order = setup_a(world)
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT, txn_at=None))
    assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "UNREADABLE_SLIP")


def test_30_low_ocr_confidence_on_time(world):
    order = setup_a(world)
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT, ocr_conf=0.8))
    assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "UNREADABLE_SLIP")


def test_31_online_slip_with_account_cropped(world):
    order = setup_a(world)
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT, receiving_account=None))
    assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "INCOMPLETE_SLIP")


# =============================================================== 10. conflicting evidence

def test_32_cash_slip_date_differs_from_sms_date(world):
    world.clock.set(lk(2026, 8, 28, 13, 50))
    order = world.order("Athayea", 7500, lk(2026, 8, 20, 9, 0))
    world.sms(S.SMS_B, lk(2026, 8, 28, 13, 44, 55))
    r = world.submit(order, world.slip(S.PEOPLES_DEPOSIT.replace("28AUG2026 13:44:42", "27AUG2026 13:44:42")))
    assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "SMS_CONFLICT")


# =============================================================== 11. missing evidence

def test_33_no_sms_yet_then_sms_arrives_and_auto_approves(world):
    order = world.order("Rizan", 5000, ORDER_A_CREATED)
    world.sms(S.combank_sms("1,000.00", "15:00"), lk(2026, 9, 26, 15, 0, 20))   # feed is alive
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT))
    assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "WAITING_FOR_SMS")
    assert "waiting for confirmation from the bank" in world.outbox()[-1].body

    world.clock.set(lk(2026, 9, 26, 16, 26))
    res = world.sms(S.SMS_A, lk(2026, 9, 26, 16, 25, 5))    # SMS delivered 7 minutes late
    assert r.submission.id in res.reevaluated
    assert world.refresh(r.submission).outcome == "APPROVED"
    assert "received your payment" in world.outbox()[-1].body


def test_34_no_sms_at_all_means_feed_is_stale(world):
    order = world.order("Rizan", 5000, ORDER_A_CREATED)
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT))
    assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "SMS_FEED_STALE")


def test_35_waiting_too_long_escalates(world):
    order = world.order("Rizan", 5000, ORDER_A_CREATED)
    world.sms(S.combank_sms("1,000.00", "15:00"), lk(2026, 9, 26, 15, 0, 20))
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT))
    world.clock.advance(minutes=world.cfg.sms_wait_ttl_min + 1)
    world.sms(S.combank_sms("1,000.00", "18:21"), world.clock.now())    # keeps feed fresh, triggers re-check
    assert world.refresh(r.submission).reason_code == "WAITING_FOR_SMS_EXPIRED"


def test_36_debit_sms_is_never_used_as_evidence(world):
    order = world.order("Rizan", 5000, ORDER_A_CREATED)
    world.sms(S.combank_sms("5,000.00", "16:18", kind="Debit"), A_RECEIVED)
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT))
    assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "WAITING_FOR_SMS")


# =============================================================== 12. multiple customers with similar payments

def test_37_two_identical_credits_same_minute_is_ambiguous(world):
    order = setup_a(world)
    world.sms(S.SMS_A, lk(2026, 9, 26, 16, 18, 52))     # a second, genuinely separate Rs 5,000 credit
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT))
    assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "AMBIGUOUS_MATCH")
    assert len(r.submission.match["candidates"]) == 2


def test_38_same_amount_one_minute_apart_is_ambiguous(world):
    order = setup_a(world)
    world.sms(S.combank_sms("5,000.00", "16:19"), lk(2026, 9, 26, 16, 19, 30))
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT))
    assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "AMBIGUOUS_MATCH")


def test_39_same_amount_far_apart_both_customers_approved(world):
    o1 = setup_a(world, customer="Rizan")
    o2 = world.order("Nimal", 5000, ORDER_A_CREATED)
    world.clock.set(lk(2026, 9, 26, 16, 45))
    world.sms(S.combank_sms("5,000.00", "16:40"), lk(2026, 9, 26, 16, 40, 10))
    r1 = world.submit(o1, world.slip(S.COMBANK_ERECEIPT))
    r2 = world.submit(o2, world.slip(S.COMBANK_ERECEIPT, txn_at=lk(2026, 9, 26, 16, 40), reference="O600066177777",
                                     sender_account="81******11", generated_at=lk(2026, 9, 26, 16, 40)))
    assert r1.outcome == "APPROVED" and r2.outcome == "APPROVED"
    assert {c.sms_id for c in world.claims()} == {1, 2}


def test_40_one_candidate_already_claimed_and_one_free_is_not_auto_picked(world):
    o1 = setup_a(world, customer="Rizan")
    world.submit(o1, world.slip(S.COMBANK_ERECEIPT))                     # claims SMS at 16:18
    o2 = world.order("Cash", 5000, ORDER_A_CREATED)
    world.sms(S.combank_sms("5,000.00", "16:19"), lk(2026, 9, 26, 16, 19, 30))
    # cash-style slip (no reference, no account) at 16:18: both SMS are strong-ish candidates
    r = world.submit(o2, world.slip(S.COMBANK_ERECEIPT, txn_at=lk(2026, 9, 26, 16, 18, 30), reference=None,
                                    secondary_reference=None, sender_account="82******22"))
    assert r.outcome != "APPROVED"


# =============================================================== extras

def test_41_hold_on_suspicious_submission_blocks_second_claimant(world):
    o1 = world.order("Suspect", 5000, ORDER_A_CREATED)
    o2 = world.order("Rizan", 5000, ORDER_A_CREATED)
    world.sms(S.SMS_A, A_RECEIVED)
    text = S.COMBANK_ERECEIPT.replace("Generated at 9/26/26 4:18 PM", "Generated at 9/25/26 4:18 PM")
    r1 = world.submit(o1, extract_slip(text))
    assert r1.reason == "SUSPICIOUS"
    r2 = world.submit(o2, world.slip(S.COMBANK_ERECEIPT))
    assert (r2.outcome, r2.reason) == ("NEEDS_VERIFICATION", "CLAIM_CONTESTED")


def test_42_order_already_paid_extra_payment_kept_as_credit(world):
    order = setup_a(world)
    world.submit(order, world.slip(S.COMBANK_ERECEIPT))
    world.clock.set(lk(2026, 9, 26, 17, 5))
    world.sms(S.combank_sms("5,000.00", "17:00"), lk(2026, 9, 26, 17, 0, 15))
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT, txn_at=lk(2026, 9, 26, 17, 0),
                                       reference="O600066188888", generated_at=lk(2026, 9, 26, 17, 0)))
    assert (r.outcome, r.reason) == ("NEEDS_VERIFICATION", "ORDER_ALREADY_PAID")
    assert sorted(c.kind for c in world.claims()) == ["ORDER_PAYMENT", "UNAPPLIED_CREDIT"]


def test_43_sms_delivered_after_midnight_gets_previous_day(world):
    world.clock.set(lk(2026, 9, 27, 0, 5))
    order = world.order("Night", 5000, lk(2026, 9, 26, 23, 0))
    world.sms(S.combank_sms("5,000.00", "23:59"), lk(2026, 9, 27, 0, 1, 10))
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT, txn_at=lk(2026, 9, 26, 23, 59), reference="O600066123123",
                                       generated_at=lk(2026, 9, 26, 23, 59)))
    assert (r.outcome, r.reason) == ("APPROVED", "APPROVED_PAID")


def test_44_two_business_accounts_same_amount_same_minute_disambiguated_by_account(world):
    order = setup_a(world)
    world.sms(S.peoples_sms("5000.00", "16:18", "26/09/2026"), lk(2026, 9, 26, 16, 18, 45))
    r = world.submit(order, world.slip(S.COMBANK_ERECEIPT))
    assert (r.outcome, r.reason) == ("APPROVED", "APPROVED_PAID")
    assert world.claims()[0].sms_id == 1


def test_45_duplicate_sms_from_forwarder_retry_is_stored_once(world):
    a = world.sms(S.SMS_A, A_RECEIVED)
    b = world.sms(S.SMS_A, A_RECEIVED)
    assert a.created and not b.created and a.sms.id == b.sms.id


def test_46_balance_gap_detected_on_peoples_bank_sms(world):
    world.clock.set(lk(2026, 8, 28, 14, 0))
    world.sms(S.peoples_sms("1000.00", "10:00", "28/08/2026", balance="28722.13"), lk(2026, 8, 28, 10, 0, 30))
    ok = world.sms(S.SMS_B, lk(2026, 8, 28, 13, 44, 55))                  # 28722.13 + 7500 = 36222.13
    assert not any("balance gap" in i for i in ok.sms.issues)
    gap = world.sms(S.peoples_sms("500.00", "13:55", "28/08/2026", balance="40000.00"), lk(2026, 8, 28, 13, 55, 30))
    assert any("balance gap" in i for i in gap.sms.issues)


def test_47_customer_messages_never_leak_internal_details(world):
    # run a spread of scenarios then inspect every outbound message
    o1 = setup_a(world, customer="Rizan")
    o2 = world.order("Fraudster", 5000, lk(2026, 9, 26, 16, 5))
    world.submit(o1, world.slip(S.COMBANK_ERECEIPT))
    world.submit(o2, world.slip(S.COMBANK_ERECEIPT))
    world.submit(o2, world.slip(S.COMBANK_ERECEIPT, receiving_account="8026328799"))
    world.submit(o2, world.slip(S.COMBANK_ERECEIPT, txn_at=lk(2026, 9, 26, 16, 25)))
    banned = ["sms", "av_bal", "36,222", "36222", "tamper", "fraud", "suspicious", "another customer",
              "hold", "confidence", "8026328799", "rasheed"]
    for m in world.outbox():
        low = m.body.lower()
        assert not any(b in low for b in banned), m.body


def test_48_audit_log_and_decisions_are_append_only(world):
    import pytest
    from sqlalchemy import text
    from sqlalchemy.exc import DatabaseError
    order = setup_a(world)
    world.submit(order, world.slip(S.COMBANK_ERECEIPT))
    assert world.s.scalars(select(AuditLog)).first() is not None
    for stmt in ("UPDATE decision_records SET outcome='REJECTED'", "DELETE FROM audit_log"):
        with pytest.raises(DatabaseError):
            world.s.execute(text(stmt))
        world.s.rollback()
