import React, { useEffect, useState } from "react";
import { api, countdown, dt, rs } from "../lib.js";
import { Empty, ErrorLine, StatusPill, usePoll } from "../ui.jsx";

export function NewOrderForm({ business, preset, onCreated }) {
  const accounts = (business?.accounts || []).filter((a) => a.is_active);
  const sendable = accounts.filter((a) => !a.masked);
  const [f, setF] = useState({ customer_name: preset?.name || "", phone: preset?.phone || "", amount: "", account_id: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(null);
  useEffect(() => {
    if (!f.account_id && sendable.length === 1) setF((x) => ({ ...x, account_id: String(sendable[0].id) }));
  }, [business]);
  useEffect(() => { if (preset) setF((x) => ({ ...x, customer_name: preset.name || x.customer_name, phone: preset.phone || x.phone })); }, [preset?.phone]);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setErr(""); setDone(null);
    try {
      const o = await api.post("/api/orders", { ...f, account_id: f.account_id ? Number(f.account_id) : null });
      setDone(o);
      setF({ customer_name: "", phone: "", amount: "", account_id: sendable.length === 1 ? String(sendable[0].id) : "" });
      onCreated && onCreated(o);
    } catch (x) { setErr(x.message); } finally { setBusy(false); }
  };
  return (
    <form onSubmit={submit} className="space-y-3">
      <div>
        <label className="label">Customer name</label>
        <input className="input" required value={f.customer_name} onChange={(e) => setF({ ...f, customer_name: e.target.value })} />
      </div>
      <div>
        <label className="label">WhatsApp number</label>
        <input className="input" required placeholder="077 123 4567" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
      </div>
      <div>
        <label className="label">Amount to pay (Rs.)</label>
        <input className="input tabular" required placeholder="5,000.00" value={f.amount} onChange={(e) => setF({ ...f, amount: e.target.value })} />
      </div>
      <div>
        <label className="label">Bank account to send to the customer</label>
        <select className="input" required value={f.account_id} onChange={(e) => setF({ ...f, account_id: e.target.value })}>
          <option value="">Choose account…</option>
          {accounts.map((a) => (
            <option key={a.id} value={a.id} disabled={a.masked}>
              {a.bank} · {a.account}{a.masked ? " (full number needed, see Settings)" : ""}
            </option>
          ))}
        </select>
      </div>
      <ErrorLine error={err} />
      <button className="btn-primary w-full" disabled={busy}>{busy ? "Sending…" : "Create order & send account details on WhatsApp"}</button>
      {business?.payment_window_min && <p className="text-xs text-slate-500">The customer has {business.payment_window_min} minutes to pay{business.balance_window_min ? `, and ${business.balance_window_min} more minutes to pay any balance` : ""}.</p>}
      {done && <div className="text-sm bg-emerald-50 border border-emerald-200 rounded px-3 py-2">
        Order <b>{done.code}</b> created for {done.customer.name} ({done.customer.code}). Account details sent on WhatsApp.
      </div>}
    </form>
  );
}

export default function Orders({ business }) {
  const [orders, setOrders] = useState([]);
  const [status, setStatus] = useState("");
  const [, setTick] = useState(0);
  const load = () => api.get(`/api/orders${status ? `?status=${status}` : ""}`).then(setOrders).catch(() => {});
  usePoll(load, 5000, [status]);
  useEffect(() => { const t = setInterval(() => setTick((x) => x + 1), 1000); return () => clearInterval(t); }, []);

  return (
    <div className="grid grid-cols-[360px_1fr] gap-4 items-start">
      <div className="card p-4">
        <h2 className="font-semibold mb-3">New order</h2>
        <NewOrderForm business={business} onCreated={load} />
      </div>
      <div className="card">
        <div className="px-4 py-2 border-b border-slate-200 flex items-center gap-2">
          <h2 className="font-semibold mr-auto">Orders</h2>
          <select className="input !w-48" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">All statuses</option>
            {["AWAITING_PAYMENT", "PARTIALLY_PAID", "PAID", "EXPIRED", "CANCELLED"].map((s) => <option key={s} value={s}>{s.replace("_", " ").toLowerCase()}</option>)}
          </select>
        </div>
        {orders.length === 0 ? <Empty>No orders yet.</Empty> : (
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-200">
              <th className="th">Order</th><th className="th">Customer</th><th className="th">Pay to</th><th className="th text-right">Amount</th>
              <th className="th text-right">Paid</th><th className="th">Status</th><th className="th">Deadline</th><th className="th">Slips</th>
            </tr></thead>
            <tbody className="divide-y divide-slate-100">
              {orders.map((o) => {
                const deadline = o.status === "PARTIALLY_PAID" ? o.balance_due_by : o.status === "AWAITING_PAYMENT" ? o.expires_at : null;
                const cd = countdown(deadline);
                return (
                  <tr key={o.id}>
                    <td className="td font-medium">{o.code}<div className="text-xs text-slate-400 font-normal">{dt(o.created_at)}</div></td>
                    <td className="td">{o.customer.name}<div className="text-xs text-slate-500">{o.customer.code} · {o.customer.phone}</div></td>
                    <td className="td text-xs">{o.pay_to_account ? `${o.pay_to_account.bank} ${o.pay_to_account.account}` : "–"}</td>
                    <td className="td text-right tabular">{rs(o.expected_cents)}</td>
                    <td className="td text-right tabular">{rs(o.paid_cents)}{o.balance_due_cents > 0 && o.paid_cents > 0 && <div className="text-xs text-amber-700">due {rs(o.balance_due_cents)}</div>}</td>
                    <td className="td"><StatusPill status={o.status} />{o.closed_reason && <div className="text-[11px] text-slate-500 mt-0.5">{o.closed_reason.replaceAll("_", " ").toLowerCase()}</div>}</td>
                    <td className="td text-xs tabular">{cd ? <span className={cd === "time up" ? "text-red-700" : "text-slate-700"}>{cd}</span> : "–"}</td>
                    <td className="td text-xs">{o.submissions > 0 ? <a className="underline" href={`#/queue`}>{o.submissions}</a> : "0"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
