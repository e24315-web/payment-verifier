"""Shared domain value types."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class Outcome(str, Enum):
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    NEEDS_VERIFICATION = "NEEDS_VERIFICATION"


class SlipType(str, Enum):
    ONLINE_TRANSFER = "ONLINE_TRANSFER"
    CASH_DEPOSIT = "CASH_DEPOSIT"
    UNKNOWN = "UNKNOWN"


class Severity(str, Enum):
    LOW = "LOW"        # shown to staff, does not block approval
    MEDIUM = "MEDIUM"  # blocks auto-approval -> NEEDS_VERIFICATION
    HIGH = "HIGH"      # blocks auto-approval, highlighted as likely fraud


@dataclass(frozen=True)
class Flag:
    code: str
    severity: Severity
    detail: str

    def to_dict(self) -> dict:
        return {"code": self.code, "severity": self.severity.value, "detail": self.detail}


@dataclass
class FieldValue:
    value: Any
    confidence: float
    raw: str | None = None
    source: str = "ocr"  # ocr | vision | human

    def to_dict(self) -> dict:
        v = self.value.isoformat() if isinstance(self.value, datetime) else self.value
        return {"value": v, "confidence": round(self.confidence, 3), "raw": self.raw, "source": self.source}


# Canonical slip field names. Everything else a template reads goes into `extra`.
SLIP_FIELDS = (
    "amount_cents",        # int
    "txn_at",              # aware datetime (the confirmation key)
    "txn_has_seconds",     # bool
    "receiving_account",   # normalised, may be masked
    "reference",           # primary bank reference / transaction id (raw)
    "secondary_reference", # e.g. ComBank e-Receipt reference
    "sender_account",
    "sender_name",
    "beneficiary_name",
    "narration",
    "status",              # COMPLETED / PENDING / ...
    "generated_at",        # aware datetime (receipt render time), if printed
    "bank",
)
DATETIME_FIELDS = {"txn_at", "generated_at"}


@dataclass
class SlipExtraction:
    template: str
    slip_type: SlipType
    fields: dict[str, FieldValue] = field(default_factory=dict)
    flags: list[Flag] = field(default_factory=list)
    raw_text: str = ""

    def get(self, name: str) -> Any:
        fv = self.fields.get(name)
        return fv.value if fv else None

    def conf(self, name: str) -> float:
        fv = self.fields.get(name)
        return fv.confidence if fv and fv.value is not None else 0.0

    def set(self, name: str, value: Any, confidence: float, raw: str | None = None, source: str = "ocr") -> None:
        if value is None:
            return
        self.fields[name] = FieldValue(value, confidence, raw, source)

    def to_dict(self) -> dict:
        return {
            "template": self.template,
            "slip_type": self.slip_type.value,
            "fields": {k: v.to_dict() for k, v in self.fields.items()},
            "flags": [f.to_dict() for f in self.flags],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "SlipExtraction":
        ex = cls(d.get("template", "unknown"), SlipType(d.get("slip_type", "UNKNOWN")))
        for k, fv in (d.get("fields") or {}).items():
            v = fv.get("value")
            if k in DATETIME_FIELDS and isinstance(v, str):
                v = datetime.fromisoformat(v)
            ex.fields[k] = FieldValue(v, float(fv.get("confidence", 0)), fv.get("raw"), fv.get("source", "ocr"))
        ex.flags = [Flag(f["code"], Severity(f["severity"]), f.get("detail", "")) for f in d.get("flags") or []]
        return ex

    def with_corrections(self, corrections: dict | None) -> "SlipExtraction":
        """Human-corrected values override OCR values with confidence 1.0 (source='human')."""
        if not corrections:
            return self
        out = SlipExtraction.from_dict(self.to_dict())
        for k, v in corrections.items():
            if k in DATETIME_FIELDS and isinstance(v, str):
                v = datetime.fromisoformat(v)
            if v is None:
                out.fields.pop(k, None)
            else:
                out.fields[k] = FieldValue(v, 1.0, None, "human")
        if corrections.get("txn_at"):
            out.fields["date_corroborated"] = FieldValue(True, 1.0, "confirmed by staff", "human")
        return out


@dataclass
class ParsedSms:
    parser: str
    is_credit: bool
    amount_cents: int | None
    account: str | None             # normalised, usually masked
    txn_at: datetime | None         # minute precision, aware
    date_source: str | None         # "sms" | "received_at"
    reference: str | None = None
    balance_cents: int | None = None  # INTERNAL ONLY. Never shown to customers.
    channel: str | None = None       # e.g. "CASH_DEPOSIT", "DIGITAL_BANKING"
    confidence: float = 0.0
    issues: list[str] = field(default_factory=list)
