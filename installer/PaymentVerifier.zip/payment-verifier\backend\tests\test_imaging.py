"""Real OCR on the real images, degraded copies, cache behaviour, and image -> decision end to end.

Slow-ish (~1 min): real Tesseract + RapidOCR. Skipped if no OCR engine is installed.
Safety property checked on every image: a critical field that is confident enough to be USED is correct.
Being incomplete is fine (-> human); being confidently wrong is not.
"""
import io
from pathlib import Path

import pytest
from PIL import Image, ImageEnhance, ImageFilter

from app.clock import lk
from app.config import RulesConfig
from app.domain.normalize import minute_key
from app.domain.types import SlipExtraction
from app.imaging.extraction import SlipExtractor, is_complete, merge_extractions
from app.imaging.ocr import build_engines
from app.services.intake import submit_slip_image
from tests.fixtures import samples as S

IMG = Path(__file__).parent / "fixtures" / "images"
CFG = RulesConfig()

TRUTH = {
    "combank_ereceipt.jpeg": {"amount_cents": 500000, "txn_at": "202609261618", "receiving_account": "8026328795"},
    "combank_flash.jpeg": {"amount_cents": 5100000, "txn_at": "202609242201", "receiving_account": "8026328795"},
    # Stamp minute read as 43 by RapidOCR and on close inspection; SMS says 13:44 (one-minute lag).
    "peoples_deposit.jpeg": {"amount_cents": 750000, "txn_at": "202608281343"},
}
THRESH = {"amount_cents": CFG.min_amount_conf, "txn_at": CFG.min_time_conf, "receiving_account": CFG.min_account_conf}


@pytest.fixture(scope="module")
def extractor():
    engines = build_engines()
    if not engines:
        pytest.skip("no OCR engine available")
    return SlipExtractor(engines, CFG)


def _bytes(im: Image.Image, quality: int = 92) -> bytes:
    buf = io.BytesIO()
    im.convert("RGB").save(buf, "JPEG", quality=quality)
    return buf.getvalue()


def _load(name: str) -> Image.Image:
    return Image.open(IMG / name).convert("RGB")


def assert_never_confidently_wrong(ex, truth: dict, label: str):
    """Amount, account and time-of-day must never be confidently wrong. The DATE is only required to be right
    when a second date on the slip corroborates it: OCR does confidently misread dot-matrix years (2026->2028
    on the rotated real slip), which is why OLD_PAYMENT needs corroboration (see DEBUGGING.md)."""
    for k, want in truth.items():
        fv = ex.fields.get(k)
        if fv is None or fv.confidence < THRESH[k]:
            continue
        got = minute_key(fv.value) if k == "txn_at" else fv.value
        if k == "txn_at" and not ex.get("date_corroborated"):
            got, want = got[8:], want[8:]      # compare HHMM only
        assert got == want, f"{label}: {k} confidently WRONG: {got!r} (conf {fv.confidence:.2f}), truth {want!r}"


# ------------------------------------------------------------------ real images

@pytest.mark.parametrize("name", list(TRUTH))
def test_real_images_extract_all_critical_fields_correctly(extractor, name):
    rep = extractor.extract_bytes((IMG / name).read_bytes())
    ex = rep.extraction
    assert is_complete(ex, CFG), {k: (str(v.value), round(v.confidence, 2)) for k, v in ex.fields.items()}
    assert_never_confidently_wrong(ex, TRUTH[name], name)
    assert rep.cost_usd == 0.0
    assert not [f for f in ex.flags if f.severity.value != "LOW"], ex.flags


def test_clean_screenshot_is_handled_by_the_cheap_tier(extractor):
    rep = extractor.extract_bytes((IMG / "combank_ereceipt.jpeg").read_bytes())
    assert rep.tier == "T1"
    assert {a.engine for a in rep.attempts} == {"tesseract"}


def test_rotated_photo_found_by_rotation_search(extractor):
    rep = extractor.extract_bytes((IMG / "peoples_deposit.jpeg").read_bytes())
    assert rep.rotation in (90,) and rep.tier == "T1b"


# ------------------------------------------------------------------ degradations

DEGRADE = {
    "rot90": lambda im: im.rotate(90, expand=True),
    "rot180": lambda im: im.rotate(180, expand=True),
    "rot270": lambda im: im.rotate(270, expand=True),
    "jpeg_q20": lambda im: Image.open(io.BytesIO(_bytes(im, 20))),
    "blur_r2": lambda im: im.filter(ImageFilter.GaussianBlur(2)),
    "blur_r6": lambda im: im.filter(ImageFilter.GaussianBlur(6)),
    "dark_0.3": lambda im: ImageEnhance.Brightness(im).enhance(0.3),
    "lowres_25pct": lambda im: im.resize((im.width // 4, im.height // 4)),
    "crop_top_30pct": lambda im: im.crop((0, 0, im.width, int(im.height * 0.3))),
}
# Degradations the system is EXPECTED to still read completely (others may legitimately become unreadable).
EXPECT_COMPLETE = {("combank_ereceipt.jpeg", d) for d in ("rot90", "rot180", "rot270", "jpeg_q20", "blur_r2")}


@pytest.mark.parametrize("name", ["combank_ereceipt.jpeg", "peoples_deposit.jpeg"])
@pytest.mark.parametrize("deg", list(DEGRADE))
def test_degraded_images_are_never_confidently_wrong(extractor, name, deg):
    im = DEGRADE[deg](_load(name))
    ex = extractor.extract_bytes(_bytes(im)).extraction
    assert_never_confidently_wrong(ex, TRUTH[name], f"{name}/{deg}")
    if (name, deg) in EXPECT_COMPLETE:
        assert is_complete(ex, CFG), f"{name}/{deg} should still be readable"


@pytest.mark.parametrize("deg", ["rot90", "rot180", "rot270", "jpeg_q20", "blur_r2", "dark_0.3", "lowres_25pct"])
def test_degraded_real_cash_slip_is_never_rejected_and_never_wrongly_approved(world, extractor, deg):
    """Decision-level safety on the hardest real image: the genuine payment is never REJECTED, whatever
    the OCR reads, and if APPROVED the critical fields were read correctly."""
    world.clock.set(lk(2026, 8, 28, 13, 50))
    order = world.order("Athayea", 7500, lk(2026, 8, 28, 13, 0))
    world.sms(S.SMS_B, lk(2026, 8, 28, 13, 44, 55))
    im = DEGRADE[deg](_load("peoples_deposit.jpeg"))
    sub, d = submit_slip_image(world.s, order.id, _bytes(im), extractor, world.clock, world.cfg)
    assert d.outcome.value != "REJECTED", (deg, d.reason_code, d.reasons)
    if d.outcome.value == "APPROVED":
        ex = SlipExtraction.from_dict(sub.extraction)
        assert ex.get("amount_cents") == 750000 and minute_key(ex.get("txn_at")) in ("202608281343", "202608281344")


def test_cropped_slip_without_time_is_not_complete(extractor):
    rep = extractor.extract_bytes(_bytes(DEGRADE["crop_top_30pct"](_load("combank_ereceipt.jpeg"))))
    assert rep.extraction.conf("txn_at") < CFG.min_time_conf
    # DEBUGGING #8: layout recognised upright by Tesseract -> the fallback must not search 4 rotations
    assert {a.rotation for a in rep.attempts} == {0}
    assert rep.tier == "T1b" and "incomplete" in rep.result_tier


# ------------------------------------------------------------------ merging unit test

def test_merge_disagreement_on_critical_field_lowers_or_drops():
    from app.domain.types import FieldValue, SlipExtraction, SlipType
    def mk(amount):
        e = SlipExtraction("combank_ereceipt", SlipType.ONLINE_TRANSFER)
        e.fields["amount_cents"] = FieldValue(amount, 0.95)
        return e
    tie = merge_extractions([mk(500000), mk(800000)])
    assert "amount_cents" not in tie.fields
    major = merge_extractions([mk(500000), mk(500000), mk(800000)])
    assert major.get("amount_cents") == 500000 and major.conf("amount_cents") < CFG.min_amount_conf
    agree = merge_extractions([mk(500000), mk(500000)])
    assert agree.conf("amount_cents") > 0.95


# ------------------------------------------------------------------ image -> decision, end to end

def test_image_to_decision_all_three_real_slips(world, extractor, tmp_path):
    # A: ComBank e-receipt
    world.clock.set(lk(2026, 9, 26, 16, 20))
    oa = world.order("Rizan", 5000, lk(2026, 9, 26, 16, 0))
    world.sms(S.SMS_A, lk(2026, 9, 26, 16, 18, 40))
    sa, da = submit_slip_image(world.s, oa.id, (IMG / "combank_ereceipt.jpeg").read_bytes(), extractor,
                               world.clock, world.cfg, upload_dir=tmp_path)
    assert (da.outcome.value, da.reason_code) == ("APPROVED", "APPROVED_PAID")
    assert sa.extraction_meta["tier"] == "T1" and Path(sa.image_path).exists()

    # B: People's Bank cash deposit photo. Stamp 13:43:42 vs SMS 13:44 (one-minute lag) and a borderline
    # amount read (one of two machine lines garbled): overall confidence ~0.82 < 0.85, so by design it goes
    # to a human with the SMS HELD for this submission - not auto-approved, never rejected.
    world.clock.set(lk(2026, 8, 28, 13, 50))
    ob = world.order("Athayea", 7500, lk(2026, 8, 28, 13, 0))
    world.sms(S.SMS_B, lk(2026, 8, 28, 13, 44, 55))
    sb, db = submit_slip_image(world.s, ob.id, (IMG / "peoples_deposit.jpeg").read_bytes(), extractor,
                               world.clock, world.cfg)
    assert db.outcome.value in ("APPROVED", "NEEDS_VERIFICATION"), db.reason_code
    if db.outcome.value == "NEEDS_VERIFICATION":
        assert db.reason_code == "LOW_CONFIDENCE"
        assert db.claim is not None and db.claim.kind == "HOLD"

    # C: Flash receipt with the synthetic SMS
    world.clock.set(lk(2026, 9, 24, 22, 5))
    oc = world.order("Kampu", 51000, lk(2026, 9, 24, 21, 30))
    world.sms(S.SMS_C_SYNTHETIC, lk(2026, 9, 24, 22, 1, 50))
    _, dc = submit_slip_image(world.s, oc.id, (IMG / "combank_flash.jpeg").read_bytes(), extractor,
                              world.clock, world.cfg)
    assert (dc.outcome.value, dc.reason_code) == ("APPROVED", "APPROVED_PAID")


def test_forwarded_identical_image_costs_zero_ocr_and_is_rejected_as_reused(world, extractor):
    world.clock.set(lk(2026, 9, 26, 16, 20))
    o1 = world.order("Rizan", 5000, lk(2026, 9, 26, 16, 0))
    o2 = world.order("Fraudster", 5000, lk(2026, 9, 26, 16, 5))
    world.sms(S.SMS_A, lk(2026, 9, 26, 16, 18, 40))
    data = (IMG / "combank_ereceipt.jpeg").read_bytes()
    submit_slip_image(world.s, o1.id, data, extractor, world.clock, world.cfg)
    s2, d2 = submit_slip_image(world.s, o2.id, data, extractor, world.clock, world.cfg)
    assert s2.extraction_meta["tier"] == "CACHE" and s2.extraction_meta["latency_ms"] == 0
    assert (d2.outcome.value, d2.reason_code) == ("REJECTED", "ALREADY_USED")


def test_recompressed_copy_of_approved_slip_for_other_customer_rejected(world, extractor):
    """Same payment, different image bytes (recompressed + slightly cropped): caught by transaction identity."""
    world.clock.set(lk(2026, 9, 26, 16, 20))
    o1 = world.order("Rizan", 5000, lk(2026, 9, 26, 16, 0))
    o2 = world.order("Fraudster", 5000, lk(2026, 9, 26, 16, 5))
    world.sms(S.SMS_A, lk(2026, 9, 26, 16, 18, 40))
    submit_slip_image(world.s, o1.id, (IMG / "combank_ereceipt.jpeg").read_bytes(), extractor, world.clock, world.cfg)
    im = _load("combank_ereceipt.jpeg")
    im = im.crop((10, 10, im.width - 10, int(im.height * 0.75)))
    s2, d2 = submit_slip_image(world.s, o2.id, _bytes(im, 60), extractor, world.clock, world.cfg)
    assert s2.extraction_meta["tier"] != "CACHE"
    assert (d2.outcome.value, d2.reason_code) == ("REJECTED", "ALREADY_USED")
