import React, { useState } from "react";
import { api, dtSec, rs } from "../lib.js";
import { Empty, ErrorLine, usePoll } from "../ui.jsx";

export default function SmsPage() {
  const [list, setList] = useState([]);
  const [onlyFree, setOnlyFree] = useState(false);
  const [body, setBody] = useState("");
  const [recv, setRecv] = useState("");
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const load = () => api.get(`/api/sms${onlyFree ? "?unclaimed_only=true" : ""}`).then(setList).catch(() => {});
  usePoll(load, 5000, [onlyFree]);

  const paste = async () => {
    setErr(""); setMsg("");
    try {
      const r = await api.post("/api/sms/manual", { body, received_at: recv ? recv + ":00+05:30" : null });
      setMsg(r.created ? `Saved. ${r.reevaluated_submissions.length ? `Re-checked submissions: ${r.reevaluated_submissions.join(", ")}` : "No waiting slips matched."}` : "Already stored (duplicate).");
      setBody(""); load();
    } catch (e) { setErr(e.message); }
  };
  const upload = async (file) => {
    setErr(""); setMsg("");
    const fd = new FormData(); fd.append("file", file);
    try { const r = await api.form("/api/sms/csv", fd); setMsg(`${r.rows} rows, ${r.created} new.`); load(); } catch (e) { setErr(e.message); }
  };

  return (
    <div className="grid grid-cols-[360px_1fr] gap-4 items-start">
      <div className="space-y-4">
        <div className="card p-4 space-y-3">
          <h2 className="font-semibold">Add a bank SMS manually</h2>
          <p className="text-xs text-slate-500">Normally SMS arrive automatically from the business phone. Use this only when the forwarder missed one. Manual SMS are marked "manual" everywhere and recorded under your name.</p>
          <textarea className="input h-28 font-mono text-xs" placeholder="Paste the SMS text exactly as received" value={body} onChange={(e) => setBody(e.target.value)} />
          <div><label className="label">Received on the phone at (leave empty = now)</label>
            <input type="datetime-local" className="input" value={recv} onChange={(e) => setRecv(e.target.value)} /></div>
          <button className="btn-primary w-full" disabled={!body.trim()} onClick={paste}>Save SMS</button>
          <div className="border-t border-slate-100 pt-3">
            <label className="label">Or upload a CSV (columns: received_at, sender, body)</label>
            <input type="file" accept=".csv" className="text-xs" onChange={(e) => e.target.files[0] && upload(e.target.files[0])} />
          </div>
          <ErrorLine error={err} />
          {msg && <div className="text-sm text-emerald-800 bg-emerald-50 border border-emerald-200 rounded px-3 py-2">{msg}</div>}
        </div>
        <div className="card p-4 text-xs text-slate-600 space-y-1">
          <div className="font-semibold text-sm text-slate-800">Automatic forwarding</div>
          <p>An SMS-forwarder app on the business phone posts each bank SMS to <code className="bg-slate-100 px-1">/webhooks/sms</code>. Only the sender numbers set per account in Settings are accepted.</p>
        </div>
      </div>

      <div className="card">
        <div className="px-4 py-2 border-b border-slate-200 flex items-center">
          <h2 className="font-semibold mr-auto">Bank SMS received</h2>
          <label className="text-xs flex items-center gap-1.5"><input type="checkbox" checked={onlyFree} onChange={(e) => setOnlyFree(e.target.checked)} /> only unclaimed credits</label>
        </div>
        {list.length === 0 ? <Empty>No SMS yet.</Empty> : (
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-200">
              <th className="th">Transaction</th><th className="th">Account</th><th className="th text-right">Amount</th>
              <th className="th text-right" title="Business balance after this SMS (internal only)">Balance</th><th className="th">Used by</th><th className="th">Source</th>
            </tr></thead>
            <tbody className="divide-y divide-slate-100">
              {list.map((m) => (
                <tr key={m.id} className={m.is_credit ? "" : "text-slate-400"}>
                  <td className="td tabular text-xs">{dtSec(m.txn_at)}<div className="text-slate-400">{m.date_source === "received_at" ? "date from arrival" : ""}</div></td>
                  <td className="td text-xs">{m.business_account ? `${m.business_account.bank} ${m.business_account.display}` : <span className="text-amber-700">{m.account || "unknown"}</span>}</td>
                  <td className="td text-right tabular font-medium">{m.is_credit ? rs(m.amount_cents) : <span>debit {rs(m.amount_cents)}</span>}</td>
                  <td className="td text-right tabular text-xs">{rs(m.balance_cents)}</td>
                  <td className="td text-xs">{m.claim ? <a className="underline" href={`#/queue/${m.claim.submission_id}`}>#{m.claim.submission_id} ({m.claim.kind.toLowerCase().replaceAll("_", " ")})</a> : m.is_credit ? <span className="text-amber-700">unclaimed</span> : "–"}</td>
                  <td className="td text-xs">
                    <span className={m.source === "webhook" ? "" : "text-amber-700 font-medium"}>{m.source}</span>{m.sender ? ` · ${m.sender}` : ""}
                    {m.issues.length > 0 && <div className="text-[11px] text-slate-500 max-w-xs">{m.issues.join("; ")}</div>}
                    <details><summary className="text-[11px] text-slate-400 cursor-pointer">text</summary><div className="font-mono text-[11px] max-w-xs break-words">{m.body}</div></details>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
