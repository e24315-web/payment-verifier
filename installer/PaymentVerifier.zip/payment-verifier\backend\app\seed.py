"""Seed the business setup from the owner's real samples (accounts, holder-name aliases)."""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.clock import Clock
from app.db.models import Business, BusinessAccount
from app.domain.normalize import normalize_account


def seed_business(session: Session, clock: Clock) -> Business:
    b = session.scalar(select(Business).order_by(Business.id))
    if b:
        return b
    b = Business(name="Rasool Stores", whatsapp_number="+94770000000", hotline=None,
                 payment_window_min=10, balance_window_min=10, created_at=clock.now())
    session.add(b)
    session.flush()
    # SMS sender IDs are left empty on purpose: the real sender IDs must be read off the business phone and
    # entered in Settings (not guessed). Until then /api/health shows a setup warning.
    session.add_all([
        BusinessAccount(business_id=b.id, bank="Commercial Bank", account_number="8026328795",
                        display_account="8026328795",
                        holder_names=["MR MOHAMED RIZAN ATHAYEA RASOOL", "ATHAYEE KAMPU"]),
        # Only the SMS mask is known. The owner should replace this with the full number (Settings page) so the
        # bot can send it to customers; matching works with the mask either way.
        BusinessAccount(business_id=b.id, bank="People's Bank", account_number=normalize_account("065-2002****90"),
                        display_account="065-2002****90", holder_names=["MR ATHAYEA RASOOL"]),
    ])
    session.commit()
    return b
