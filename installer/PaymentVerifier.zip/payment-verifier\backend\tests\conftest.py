"""Test world: a business with the two real accounts, customers, orders, a fixed clock, and helpers."""
from __future__ import annotations

import itertools
from dataclasses import dataclass

import pytest
from sqlalchemy import select

from app.clock import FixedClock, lk
from app.config import RulesConfig
from app.db.models import Business, BusinessAccount, Claim, Customer, OutboundMessage, Order, Submission
from app.db.session import init_db, make_engine, make_session_factory
from app.domain.normalize import normalize_account
from app.domain.slip_parsers import extract_slip
from app.domain.types import FieldValue, SlipExtraction
from app.services.sms_ingest import ingest_sms
from app.services.verification import create_submission
from tests.fixtures import samples

_seq = itertools.count(1)


@dataclass
class Result:
    submission: Submission
    outcome: str
    reason: str
    decision: object


class World:
    def __init__(self, session_factory, clock: FixedClock, cfg: RulesConfig):
        self.sf = session_factory
        self.s = session_factory()
        self.clock = clock
        self.cfg = cfg
        now = clock.now()
        self.business = Business(name="Rasool Stores", whatsapp_number="+94770000000", created_at=now)
        self.s.add(self.business)
        self.s.flush()
        self.acc_combank = BusinessAccount(
            business_id=self.business.id, bank="Commercial Bank", account_number="8026328795",
            display_account="8026328795",
            holder_names=["MR MOHAMED RIZAN ATHAYEA RASOOL", "ATHAYEE KAMPU"])
        self.acc_peoples = BusinessAccount(
            business_id=self.business.id, bank="People's Bank", account_number=normalize_account("065-2002****90"),
            display_account="065-2002****90", holder_names=["MR ATHAYEA RASOOL"])
        self.s.add_all([self.acc_combank, self.acc_peoples])
        self.s.commit()
        self._customers: dict[str, Customer] = {}

    # ----------------------------------------------------------------- setup helpers
    def customer(self, name: str) -> Customer:
        if name not in self._customers:
            c = Customer(business_id=self.business.id, name=name, phone=f"+9477{next(_seq):07d}",
                         created_at=self.clock.now())
            self.s.add(c)
            self.s.commit()
            self._customers[name] = c
        return self._customers[name]

    def windows(self, payment_min: int | None = 10, balance_min: int | None = 10, hotline: str = "0112345678"):
        self.business.payment_window_min = payment_min
        self.business.balance_window_min = balance_min
        self.business.hotline = hotline
        self.s.commit()

    def order(self, customer: str, amount_rs: float, created_at) -> Order:
        from datetime import timedelta
        win = self.business.payment_window_min
        o = Order(business_id=self.business.id, customer_id=self.customer(customer).id,
                  code=f"ORD{next(_seq):04d}", expected_cents=int(round(amount_rs * 100)), created_at=created_at,
                  expires_at=created_at + timedelta(minutes=win) if win else None)
        self.s.add(o)
        self.s.commit()
        return o

    def sms(self, body: str, received_at, source: str = "simulator", device_id: str = "phone-1"):
        return ingest_sms(self.s, self.business.id, body, received_at, self.clock, self.cfg,
                          source=source, device_id=device_id)

    # ----------------------------------------------------------------- slips
    @staticmethod
    def slip(text: str, ocr_conf: float = 1.0, **overrides) -> SlipExtraction:
        """Parse fixture text, then override fields keeping the OCR confidence (simulates a different slip).
        Pass value None to remove a field; pass (value, confidence) to set confidence explicitly."""
        ex = extract_slip(text, ocr_conf)
        if "txn_at" in overrides and "date_corroborated" not in overrides:
            ex.fields.pop("date_corroborated", None)   # a changed date is no longer backed by the slip's other date
        for k, v in overrides.items():
            if v is None:
                ex.fields.pop(k, None)
                continue
            conf = ex.conf(k) or 0.95 * ocr_conf
            if isinstance(v, tuple):
                v, conf = v
            ex.fields[k] = FieldValue(v, conf, None, "ocr")
        return ex

    def submit(self, order: Order, slip: SlipExtraction, sha: str | None = None, msg_id: str | None = None) -> Result:
        sub, d = create_submission(self.s, order.id, slip, self.clock, self.cfg,
                                   image_sha256=sha or f"sha-{next(_seq)}", channel_message_id=msg_id)
        self.s.refresh(sub)
        return Result(sub, sub.outcome, sub.reason_code, d)

    # ----------------------------------------------------------------- queries
    def refresh(self, obj):
        self.s.refresh(obj)
        return obj

    def claims(self) -> list[Claim]:
        return list(self.s.scalars(select(Claim)).all())

    def outbox(self, customer: str | None = None) -> list[OutboundMessage]:
        q = select(OutboundMessage).order_by(OutboundMessage.id)
        if customer:
            q = q.where(OutboundMessage.customer_id == self.customer(customer).id)
        return list(self.s.scalars(q).all())


@pytest.fixture
def cfg() -> RulesConfig:
    return RulesConfig()


@pytest.fixture
def clock() -> FixedClock:
    return FixedClock(lk(2026, 9, 26, 16, 20))


@pytest.fixture
def engine(tmp_path):
    eng = make_engine(f"sqlite:///{tmp_path / 'test.db'}")
    init_db(eng)
    yield eng
    eng.dispose()


@pytest.fixture
def world(engine, clock, cfg) -> World:
    w = World(make_session_factory(engine), clock, cfg)
    yield w
    w.s.close()


@pytest.fixture
def S():
    return samples
