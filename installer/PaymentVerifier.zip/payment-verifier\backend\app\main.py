"""FastAPI app factory. `uvicorn app.main:app` or `python run.py`."""
from __future__ import annotations

import asyncio
import logging
import threading
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.api.routes import router
from datetime import datetime

from app.clock import Clock, OffsetClock, SystemClock
from app.config import RulesConfig, load_rules_config
from app.db.session import init_db, make_engine, make_session_factory
from app.imaging.extraction import SlipExtractor
from app.imaging.ocr import build_engines
from app.services.jobs import tick
from app.settings import Settings

log = logging.getLogger("payment_verifier")
UI_DIST = Path(__file__).resolve().parent.parent.parent / "frontend" / "dist"


class AppState:
    def __init__(self, settings: Settings, clock: Clock, cfg: RulesConfig, extractor: SlipExtractor | None = None,
                 media_fetcher=None):
        self.settings, self.clock, self.cfg = settings, clock, cfg
        self.engine = make_engine(settings.database_url)
        init_db(self.engine)
        self.session_factory = make_session_factory(self.engine)
        self._extractor = extractor
        self._lock = threading.Lock()
        self.media_fetcher = media_fetcher

    def extractor(self) -> SlipExtractor:
        """OCR engines load lazily (RapidOCR takes ~2 s to initialise)."""
        with self._lock:
            if self._extractor is None:
                self._extractor = SlipExtractor(build_engines(self.settings.ocr_engines), self.cfg)
            return self._extractor

    def engine_names(self) -> list[str]:
        return [e.name for e in self._extractor.engines] if self._extractor else ["(not loaded yet)"]


def create_app(settings: Settings | None = None, clock: Clock | None = None, cfg: RulesConfig | None = None,
               extractor: SlipExtractor | None = None, run_jobs: bool = True, media_fetcher=None) -> FastAPI:
    settings = settings or Settings()
    if clock is None:
        clock = OffsetClock(datetime.fromisoformat(settings.demo_start)) if settings.demo_start else SystemClock()
        if settings.demo_start:
            log.warning("DEMO CLOCK: app time starts at %s", settings.demo_start)
    st = AppState(settings, clock, cfg or load_rules_config(), extractor, media_fetcher)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        task = None
        if run_jobs:
            async def loop():
                while True:
                    await asyncio.sleep(settings.job_interval_s)
                    try:
                        s = st.session_factory()
                        try:
                            await asyncio.to_thread(tick, s, st.clock, st.cfg)
                        finally:
                            s.close()
                    except Exception:   # a failing job must never take the API down
                        log.exception("periodic job failed")
            task = asyncio.create_task(loop())
        yield
        if task:
            task.cancel()

    app = FastAPI(title="BuildStart Payment Verifier", version="1.0", lifespan=lifespan)
    app.state.pv = st
    app.include_router(router)

    if UI_DIST.exists():
        app.mount("/assets", StaticFiles(directory=UI_DIST / "assets"), name="assets")

        @app.get("/{path:path}", include_in_schema=False)
        def spa(path: str):
            f = UI_DIST / path
            return FileResponse(f if path and f.is_file() else UI_DIST / "index.html")
    return app
# No module-level app: importing this module must not create a database. Use
#   uvicorn app.main:create_app --factory      or      python run.py
