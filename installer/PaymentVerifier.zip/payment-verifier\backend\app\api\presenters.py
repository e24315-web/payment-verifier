"""Staff-facing view models. (Customer-facing text only ever comes from reasons.customer_message.)"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.clock import LK_TZ
from app.db.models import (
    AuditLog,
    BusinessAccount,
    Claim,
    CreditApplication,
    Customer,
    DecisionRecord,
    Order,
    SmsMessage,
    Submission,
)
from app.domain.normalize import accounts_compatible, minute_floor, name_similarity
from app.domain.reasons import REASONS
from app.services.actions import customer_credit, refund_summary
from app.services.verification import current_slip

FRAUDISH = {"SUSPICIOUS", "REFERENCE_REUSED_DIFFERENT_DETAILS", "ALREADY_USED", "CLAIM_CONTESTED",
            "SMS_CONFLICT", "FUTURE_DATED", "SAME_CUSTOMER_OTHER_ORDER"}


def iso(dt: datetime | None) -> str | None:
    return dt.astimezone(LK_TZ).isoformat() if dt else None


def risk_score(sub: Submission) -> int:
    flags = sub.flags or []
    score = sum(3 for f in flags if f.get("severity") == "HIGH") + sum(2 for f in flags if f.get("severity") == "MEDIUM")
    score += 3 if sub.contested else 0
    score += 2 if sub.reason_code in FRAUDISH else 0
    return score


def needs_action(sub: Submission) -> bool:
    return sub.outcome == "NEEDS_VERIFICATION" or bool(sub.contested)


def queue_item(session: Session, sub: Submission) -> dict:
    order = session.get(Order, sub.order_id)
    cust = session.get(Customer, sub.customer_id)
    spec = REASONS.get(sub.reason_code or "")
    return {
        "id": sub.id, "created_at": iso(sub.created_at),
        "customer": {"id": cust.id, "name": cust.name, "phone": cust.phone},
        "order": {"id": order.id, "code": order.code, "expected_cents": order.expected_cents,
                  "paid_cents": order.paid_cents, "status": order.status},
        "slip_amount_cents": sub.amount_cents, "txn_at": iso(sub.txn_at),
        "outcome": sub.outcome, "reason_code": sub.reason_code, "reason_title": spec.title if spec else None,
        "confidence": sub.confidence, "contested": sub.contested, "decided_by": sub.decided_by,
        "flag_counts": {s: sum(1 for f in (sub.flags or []) if f.get("severity") == s) for s in ("HIGH", "MEDIUM", "LOW")},
        "risk": risk_score(sub), "needs_action": needs_action(sub),
        "tier": (sub.extraction_meta or {}).get("tier"), "slip_type": sub.slip_type,
    }


def sms_view(s: SmsMessage, claim: Claim | None = None, accounts: dict | None = None) -> dict:
    acc = accounts.get(s.business_account_id) if accounts else None
    return {
        "id": s.id, "received_at": iso(s.received_at), "txn_at": iso(s.txn_at), "date_source": s.date_source,
        "amount_cents": s.amount_cents, "account": s.account, "is_credit": s.is_credit,
        "business_account": {"id": acc.id, "bank": acc.bank, "display": acc.display_account} if acc else None,
        "source": s.source, "sender": s.sender, "parser": s.parser, "body": s.body, "issues": s.issues or [],
        "balance_cents": s.balance_cents,      # staff-only (business owner's own balance)
        "claim": {"kind": claim.kind, "submission_id": claim.submission_id, "order_id": claim.order_id} if claim else None,
    }


def _status(ok: bool | None) -> str:
    return "na" if ok is None else ("match" if ok else "mismatch")


def comparison(slip, sms: SmsMessage | None, order: Order, accounts: list[BusinessAccount]) -> list[dict]:
    """Rows for the Slip | Bank SMS | Order table."""
    rows = []
    s_acc = slip.get("receiving_account")
    cash = slip.slip_type.value == "CASH_DEPOSIT"
    sms_acc = next((a for a in accounts if sms and a.id == sms.business_account_id), None)
    acc_ok = None
    if s_acc and sms_acc and not cash:
        acc_ok = accounts_compatible(s_acc, sms_acc.account_number)
    elif s_acc and not cash:
        acc_ok = any(accounts_compatible(s_acc, a.account_number) for a in accounts)
    rows.append({"field": "Receiving account",
                 "slip": s_acc if not cash else "(cash slip: handwritten, not used)",
                 "sms": f"{sms_acc.bank} {sms_acc.display_account}" if sms_acc else (sms.account if sms else None),
                 "order": ", ".join(f"{a.bank} {a.display_account}" for a in accounts),
                 "status": _status(acc_ok)})

    amt = slip.get("amount_cents")
    rows.append({"field": "Amount", "slip": amt, "sms": sms.amount_cents if sms else None,
                 "order": {"expected": order.expected_cents, "balance_due": order.expected_cents - order.paid_cents},
                 "status": _status(None if sms is None or amt is None else amt == sms.amount_cents),
                 "vs_order": None if amt is None else ("equal" if amt == order.expected_cents
                                                       else "less" if amt < order.expected_cents else "more"),
                 "kind": "money"})

    t = slip.get("txn_at")
    off = None
    if t and sms and sms.txn_at:
        off = int((minute_floor(sms.txn_at) - minute_floor(t)).total_seconds() // 60)
    rows.append({"field": "Date & time", "slip": iso(t), "sms": iso(sms.txn_at) if sms else None,
                 "sms_date_source": sms.date_source if sms else None, "order": iso(order.created_at),
                 "offset_min": off, "status": _status(None if off is None else off in (0, 1)),
                 "after_order": None if t is None else t >= order.created_at, "kind": "datetime"})

    rows.append({"field": "Reference", "slip": slip.get("reference"), "sms": sms.reference if sms else None,
                 "order": order.code, "status": _status(None if not (sms and sms.reference and slip.get("reference"))
                                                        else sms.reference == slip.get("reference"))})
    ben = slip.get("beneficiary_name")
    holders = [h for a in accounts for h in (a.holder_names or [])]
    sim = max((name_similarity(ben, h) for h in holders), default=0) if ben else None
    rows.append({"field": "Beneficiary name", "slip": ben, "sms": None, "order": " / ".join(holders),
                 "status": _status(None if sim is None or slip.conf("beneficiary_name") < 0.8 else sim >= 0.75)})
    return rows


def submission_detail(session: Session, sub: Submission) -> dict:
    order = session.get(Order, sub.order_id)
    cust = session.get(Customer, sub.customer_id)
    accounts = session.scalars(select(BusinessAccount).where(BusinessAccount.business_id == order.business_id)).all()
    acc_map = {a.id: a for a in accounts}
    slip = current_slip(sub)
    claim = session.scalar(select(Claim).where(Claim.submission_id == sub.id))
    sms = session.get(SmsMessage, claim.sms_id) if claim else None
    if sms is None and sub.match and sub.match.get("chosen_sms_id"):
        sms = session.get(SmsMessage, sub.match["chosen_sms_id"])
    if sms is None and sub.match:
        # e.g. ALREADY_USED: show the credit this slip points at, even though another order holds it
        strong = [c for c in sub.match.get("candidates", []) if c["kind"] in ("EXACT", "LAG1")]
        if len(strong) == 1:
            sms = session.get(SmsMessage, strong[0]["sms_id"])

    cand_ids = [c["sms_id"] for c in (sub.match or {}).get("candidates", [])]
    candidates = []
    for cid in cand_ids:
        s = session.get(SmsMessage, cid)
        if s:
            cl = session.scalar(select(Claim).where(Claim.sms_id == s.id))
            c_meta = next(c for c in sub.match["candidates"] if c["sms_id"] == cid)
            candidates.append({**sms_view(s, cl, acc_map), "offset_min": c_meta["offset_min"], "kind": c_meta["kind"]})

    rel = []
    for other in session.scalars(select(Submission).where(Submission.id != sub.id).where(
            (Submission.image_sha256 == sub.image_sha256)
            | ((Submission.amount_cents == sub.amount_cents) & (Submission.txn_minute == sub.txn_minute)
               & Submission.txn_minute.is_not(None))
            | ((Submission.reference_folded == sub.reference_folded) & Submission.reference_folded.is_not(None)))).all():
        o_order = session.get(Order, other.order_id)
        o_cust = session.get(Customer, other.customer_id)
        why = []
        if other.image_sha256 == sub.image_sha256:
            why.append("same image")
        if sub.reference_folded and other.reference_folded == sub.reference_folded:
            why.append("same reference")
        if sub.txn_minute and other.txn_minute == sub.txn_minute and other.amount_cents == sub.amount_cents:
            why.append("same amount & minute")
        rel.append({"id": other.id, "order_code": o_order.code, "customer": o_cust.name, "outcome": other.outcome,
                    "reason_code": other.reason_code, "why": why, "same_customer": other.customer_id == sub.customer_id})

    history = [{"at": iso(d.created_at), "actor": d.actor, "outcome": d.outcome, "reason_code": d.reason_code,
                "confidence": d.confidence, "reasons": d.reasons, "note": d.note, "customer_message": d.customer_message}
               for d in session.scalars(select(DecisionRecord).where(DecisionRecord.submission_id == sub.id)
                                        .order_by(DecisionRecord.id)).all()]
    audits = [{"at": iso(a.at), "actor": a.actor, "action": a.action, "detail": a.detail}
              for a in session.scalars(select(AuditLog).where(AuditLog.entity_type == "submission",
                                                              AuditLog.entity_id == sub.id).order_by(AuditLog.id)).all()]
    last = history[-1] if history else {}
    spec = REASONS.get(sub.reason_code or "")
    fields = {k: v.to_dict() for k, v in slip.fields.items()}
    past = session.scalars(select(Submission).where(Submission.customer_id == cust.id, Submission.id != sub.id)
                           .order_by(Submission.id.desc()).limit(20)).all()
    return {
        "submission": {**queue_item(session, sub), "image_url": f"/api/submissions/{sub.id}/image" if sub.image_path else None,
                       "extraction_meta": sub.extraction_meta},
        "customer_submitted": {"template": slip.template, "slip_type": slip.slip_type.value, "fields": fields,
                               "corrections": sub.corrections or {}},
        "system_concluded": {
            "outcome": sub.outcome, "reason_code": sub.reason_code, "title": spec.title if spec else None,
            "confidence": sub.confidence, "reasons": last.get("reasons", []), "flags": sub.flags or [],
            "next_action": spec.next_action if spec else None, "customer_message": last.get("customer_message"),
            "decided_by": sub.decided_by, "contested": sub.contested,
            "claim": {"kind": claim.kind, "sms_id": claim.sms_id, "applied_cents": claim.applied_cents,
                      "excess_cents": claim.excess_cents} if claim else None,
        },
        "comparison": comparison(slip, sms, order, accounts),
        "sms_evidence": sms_view(sms, session.scalar(select(Claim).where(Claim.sms_id == sms.id)), acc_map) if sms else None,
        "sms_candidates": candidates,
        "order": {"id": order.id, "code": order.code, "description": order.description,
                  "expected_cents": order.expected_cents, "paid_cents": order.paid_cents,
                  "balance_due_cents": max(0, order.expected_cents - order.paid_cents), "status": order.status,
                  "created_at": iso(order.created_at), "expires_at": iso(order.expires_at),
                  "balance_due_by": iso(order.balance_due_by), "closed_reason": order.closed_reason,
                  "credit_applications": [{"amount_cents": c.amount_cents, "actor": c.actor, "note": c.note}
                                          for c in session.scalars(select(CreditApplication)
                                                                   .where(CreditApplication.order_id == order.id)).all()]},
        "customer": {"id": cust.id, "code": cust.code, "name": cust.name, "phone": cust.phone,
                     "credit": customer_credit(session, cust.id), "refunds": refund_summary(session, cust.id),
                     "known_senders": sorted({s.sender_account for s in past if s.sender_account}),
                     "history": [{"id": s.id, "order_id": s.order_id, "outcome": s.outcome, "reason_code": s.reason_code,
                                  "amount_cents": s.amount_cents, "txn_at": iso(s.txn_at), "reference": s.reference_raw,
                                  "sender_name": s.sender_name, "sender_account": s.sender_account} for s in past]},
        "related": rel,
        "history": history,
        "audit": audits,
    }
