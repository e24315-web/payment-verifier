import React, { useEffect, useState } from "react";
import { api, countdown, dt, dtSec, FIELD_LABELS, rs } from "../lib.js";
import { ConfidenceBar, ErrorLine, FlagChip, ImageViewer, NoteDialog, OutcomeBadge, StatusPill } from "../ui.jsx";

const THRESH = { amount_cents: 0.85, txn_at: 0.9, receiving_account: 0.85 };
const FIELD_ORDER = ["amount_cents", "txn_at", "txn_date", "receiving_account", "status", "reference", "secondary_reference",
  "sender_account", "sender_name", "beneficiary_name", "narration", "bank", "generated_at", "teller_sequence"];
const EDITABLE = ["amount_cents", "txn_at", "receiving_account", "reference", "sender_account", "sender_name", "status"];

function fmtValue(k, v) {
  if (v === null || v === undefined || v === "") return <span className="text-slate-400">not read</span>;
  if (k === "amount_cents") return <span className="tabular font-medium">{rs(v)}</span>;
  if (k === "txn_at" || k === "generated_at") return <span className="tabular">{dtSec(v)}</span>;
  if (typeof v === "boolean") return v ? "yes" : "no";
  return String(v);
}

const ICON = {
  match: <span className="text-emerald-600 font-bold" title="matches">✓</span>,
  mismatch: <span className="text-red-600 font-bold" title="does not match">✗</span>,
  na: <span className="text-slate-300" title="not available">–</span>,
};

function cell(row, key) {
  const v = row[key];
  if (v === null || v === undefined) return <span className="text-slate-400">–</span>;
  if (row.kind === "money") {
    if (key === "order") return <span className="tabular">{rs(v.expected)}{v.balance_due !== v.expected && <span className="block text-xs text-slate-500">balance due {rs(v.balance_due)}</span>}</span>;
    return <span className="tabular font-medium">{rs(v)}</span>;
  }
  if (row.kind === "datetime") return <span className="tabular">{key === "order" ? <>created {dt(v)}</> : dtSec(v)}</span>;
  return <span className="break-all">{String(v)}</span>;
}

function Comparison({ rows }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead><tr className="border-b border-slate-200">
          <th className="th w-32"></th><th className="th">Slip (customer's claim)</th><th className="th">Bank SMS (source of truth)</th><th className="th">Order</th><th className="th w-8"></th>
        </tr></thead>
        <tbody className="divide-y divide-slate-100">
          {rows.map((r) => (
            <tr key={r.field}>
              <td className="td text-xs font-medium text-slate-500">{r.field}</td>
              <td className="td">{cell(r, "slip")}</td>
              <td className="td">{cell(r, "sms")}{r.field === "Date & time" && r.offset_min !== null && r.offset_min !== undefined && (
                <span className="block text-xs text-slate-500">{r.offset_min === 0 ? "same minute" : `${r.offset_min > 0 ? "+" : ""}${r.offset_min} min`}{r.sms_date_source === "received_at" ? " · date from SMS arrival" : ""}</span>)}
                {r.field === "Amount" && r.vs_order && r.vs_order !== "equal" && <span className="block text-xs text-amber-700">{r.vs_order} than order</span>}</td>
              <td className="td">{cell(r, "order")}{r.field === "Date & time" && r.after_order === false && <span className="block text-xs text-red-700">slip is before order</span>}</td>
              <td className="td text-center">{ICON[r.status]}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function toLocalInput(iso) {
  if (!iso) return "";
  const d = new Date(new Date(iso).getTime() + 5.5 * 3600 * 1000);
  return d.toISOString().slice(0, 19);
}

function EditFields({ fields, onSave, onCancel }) {
  const [vals, setVals] = useState(() => {
    const o = {};
    for (const k of EDITABLE) {
      const v = fields[k]?.value;
      o[k] = k === "amount_cents" ? (v ? (v / 100).toFixed(2) : "") : k === "txn_at" ? toLocalInput(v) : (v ?? "");
    }
    return o;
  });
  const [note, setNote] = useState("");
  const [err, setErr] = useState("");
  const save = async () => {
    const out = {};
    for (const k of EDITABLE) {
      const orig = fields[k]?.value ?? "";
      const cur = vals[k];
      if (k === "amount_cents") { if (cur && Math.round(parseFloat(cur.replace(/,/g, "")) * 100) !== orig) out.amount = cur; continue; }
      if (k === "txn_at") { if (cur && cur !== toLocalInput(orig)) out.txn_at = cur.length === 16 ? cur + ":00+05:30" : cur + "+05:30"; continue; }
      if (cur !== orig && cur !== "") out[k] = cur;
    }
    if (!Object.keys(out).length) { setErr("Nothing changed."); return; }
    try { await onSave(out, note); } catch (e) { setErr(e.message); }
  };
  return (
    <div className="space-y-2">
      <p className="text-xs text-slate-500">Type what you can read on the image. The system then re-checks it against the bank SMS. Your edit never approves a payment by itself.</p>
      {EDITABLE.map((k) => (
        <div key={k} className="grid grid-cols-[140px_1fr] items-center gap-2">
          <label className="text-xs text-slate-500">{FIELD_LABELS[k]}</label>
          {k === "txn_at" ? <input type="datetime-local" step="1" className="input" value={vals[k]} onChange={(e) => setVals({ ...vals, [k]: e.target.value })} />
            : k === "status" ? <select className="input" value={vals[k]} onChange={(e) => setVals({ ...vals, [k]: e.target.value })}>
              <option value="">–</option><option>COMPLETED</option><option>PENDING</option><option>SCHEDULED</option><option>FAILED</option></select>
            : <input className="input" value={vals[k]} placeholder={k === "amount_cents" ? "5,000.00" : ""} onChange={(e) => setVals({ ...vals, [k]: e.target.value })} />}
        </div>
      ))}
      <input className="input" placeholder="Note (optional)" value={note} onChange={(e) => setNote(e.target.value)} />
      <ErrorLine error={err} />
      <div className="flex gap-2 justify-end">
        <button className="btn-ghost" onClick={onCancel}>Cancel</button>
        <button className="btn-primary" onClick={save}>Save & re-check</button>
      </div>
    </div>
  );
}

export default function Detail({ id, onChange }) {
  const [d, setD] = useState(null);
  const [err, setErr] = useState("");
  const [dialog, setDialog] = useState(null);
  const [editing, setEditing] = useState(false);
  const [cashAmount, setCashAmount] = useState("");
  const [tick, setTick] = useState(0);

  const load = () => api.get(`/api/submissions/${id}`).then((x) => { setD(x); setErr(""); }).catch((e) => setErr(e.message));
  useEffect(() => { setD(null); setEditing(false); load(); }, [id]);
  useEffect(() => { const t = setInterval(() => setTick((x) => x + 1), 1000); return () => clearInterval(t); }, []);
  const after = (x) => { setD(x); onChange && onChange(); };

  if (err) return <ErrorLine error={err} />;
  if (!d) return <div className="card p-10 text-center text-slate-400">Loading…</div>;
  const s = d.submission, c = d.system_concluded, o = d.order, cu = d.customer;
  const fields = d.customer_submitted.fields;
  const deadline = o.status === "PARTIALLY_PAID" ? o.balance_due_by : o.status === "AWAITING_PAYMENT" ? o.expires_at : null;
  const act = (path, body) => api.post(`/api/submissions/${id}/${path}`, body).then(after);

  return (
    <div className="space-y-4">
      {/* ---------- verdict ---------- */}
      <div className="card p-4">
        <div className="flex items-start gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-3 flex-wrap">
              <OutcomeBadge outcome={c.outcome} big />
              {c.contested && <span className="bg-red-600 text-white rounded px-2 py-1 text-xs font-semibold">CONTESTED: another customer claimed this payment</span>}
              <span className="text-xs text-slate-500">confidence</span><ConfidenceBar value={c.confidence} />
            </div>
            <div className="mt-2 text-base font-medium">{c.title}</div>
            <div className="text-sm text-slate-600 mt-1"><b>Next:</b> {c.next_action}</div>
            <div className="text-xs text-slate-400 mt-1">Decided by {c.decided_by} · submission #{s.id} · received {dt(s.created_at)} · extraction {s.extraction_meta?.tier || "–"}{s.extraction_meta?.latency_ms ? ` in ${(s.extraction_meta.latency_ms / 1000).toFixed(1)}s` : ""}</div>
          </div>
          <div className="text-right text-sm shrink-0">
            <div className="font-semibold">{cu.name} <span className="text-slate-400 font-normal">{cu.code}</span></div>
            <div className="text-slate-500 text-xs">{cu.phone}</div>
            <div className="mt-2">Order <b>{o.code}</b> <StatusPill status={o.status} /></div>
            <div className="tabular text-xs text-slate-600 mt-1">expected {rs(o.expected_cents)} · paid {rs(o.paid_cents)}</div>
            {o.balance_due_cents > 0 && <div className="tabular text-sm font-semibold text-amber-700">balance due {rs(o.balance_due_cents)}</div>}
            {deadline && <div className="text-xs text-slate-500" key={tick}>{o.status === "PARTIALLY_PAID" ? "balance" : "payment"} deadline {dt(deadline).slice(-8)} · <b>{countdown(deadline)}</b></div>}
          </div>
        </div>
        <div className="flex flex-wrap gap-2 mt-4 pt-3 border-t border-slate-100">
          {c.outcome !== "APPROVED" && <button className="btn-green" onClick={() => setDialog("approve")}>Approve{c.claim?.kind === "HOLD" ? " (use held SMS)" : ""}</button>}
          {c.outcome !== "APPROVED" && <button className="btn-ghost" onClick={() => { setCashAmount(o.balance_due_cents > 0 ? (o.balance_due_cents / 100).toFixed(2) : ""); setDialog("cash"); }}>Cash received</button>}
          {c.outcome !== "REJECTED" && <button className="btn-red" onClick={() => setDialog("reject")}>Reject</button>}
          <button className="btn-ghost" onClick={() => setDialog("newslip")}>Ask for a new slip</button>
          <button className="btn-ghost" onClick={() => setEditing(true)}>Correct slip details</button>
          <button className="btn-ghost" onClick={() => api.post(`/api/submissions/${id}/reevaluate`).then(after)}>Re-check now</button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 items-start">
        {/* ---------- what the customer submitted ---------- */}
        <div className="card p-4">
          <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-3">What the customer submitted</h3>
          <ImageViewer src={s.image_url} />
          <div className="mt-3 text-xs text-slate-500">Read as <b>{d.customer_submitted.template.replaceAll("_", " ")}</b> · {d.customer_submitted.slip_type.replace("_", " ").toLowerCase()}</div>
          {editing ? (
            <div className="mt-3"><EditFields fields={fields} onCancel={() => setEditing(false)}
              onSave={(f, note) => api.post(`/api/submissions/${id}/corrections`, { fields: f, note }).then((x) => { setEditing(false); after(x); })} /></div>
          ) : (
            <table className="w-full text-sm mt-2">
              <tbody className="divide-y divide-slate-100">
                {FIELD_ORDER.filter((k) => fields[k] || THRESH[k]).map((k) => (
                  <tr key={k}>
                    <td className="py-1.5 pr-2 text-xs text-slate-500 w-40">{FIELD_LABELS[k] || k}</td>
                    <td className="py-1.5">{fmtValue(k, fields[k]?.value)}{fields[k]?.source === "human" && <span className="ml-1.5 text-[10px] bg-sky-100 text-sky-800 rounded px-1">edited by staff</span>}</td>
                    <td className="py-1.5 w-28">{fields[k] && fields[k].source !== "human" && <ConfidenceBar value={fields[k].confidence} threshold={THRESH[k]} />}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* ---------- what the system concluded ---------- */}
        <div className="space-y-4">
          <div className="card p-4">
            <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-2">What the system concluded</h3>
            <ul className="text-sm space-y-1 list-disc pl-5">{c.reasons.map((r, i) => <li key={i}>{r}</li>)}</ul>
            {c.flags.length > 0 && <div className="mt-3 space-y-1.5">
              <div className="text-xs font-medium text-slate-500">Suspicious / notable indicators</div>
              {c.flags.map((f, i) => <FlagChip key={i} flag={f} />)}
            </div>}
            {c.claim && <div className="mt-3 text-xs bg-slate-50 border border-slate-200 rounded px-2.5 py-1.5">
              Bank credit #{c.claim.sms_id}: <b>{c.claim.kind.replaceAll("_", " ").toLowerCase()}</b>
              {c.claim.kind === "HOLD" && " (reserved for this payment while staff review it)"}
              {c.claim.applied_cents > 0 && <> · applied {rs(c.claim.applied_cents)}</>}
              {c.claim.excess_cents > 0 && <> · <span className="text-amber-700">refund due {rs(c.claim.excess_cents)}</span></>}
            </div>}
          </div>

          <div className="card p-4">
            <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-2">Slip vs bank SMS vs order</h3>
            <Comparison rows={d.comparison} />
            {d.sms_evidence && <div className="mt-3 text-xs text-slate-600 bg-slate-50 border border-slate-200 rounded p-2">
              <div className="font-medium mb-0.5">Bank SMS #{d.sms_evidence.id} · {d.sms_evidence.source}{d.sms_evidence.sender ? ` from ${d.sms_evidence.sender}` : ""} · received {dtSec(d.sms_evidence.received_at)}
                {d.sms_evidence.claim && d.sms_evidence.claim.submission_id !== s.id && <> · <a className="text-red-700 underline" href={`#/queue/${d.sms_evidence.claim.submission_id}`}>already used by #{d.sms_evidence.claim.submission_id}</a></>}</div>
              <div className="font-mono text-[11px] break-words">{d.sms_evidence.body}</div>
            </div>}
          </div>

          {d.sms_candidates.length > 0 && <div className="card p-4">
            <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-2">Bank SMS near this slip</h3>
            <div className="divide-y divide-slate-100">
              {d.sms_candidates.map((m) => (
                <div key={m.id} className="py-2 flex items-center gap-3 text-sm">
                  <div className="flex-1">
                    <div className="tabular"><b>{rs(m.amount_cents)}</b> · {dtSec(m.txn_at)} · {m.business_account?.bank || m.account}</div>
                    <div className="text-xs text-slate-500">{m.kind.replaceAll("_", " ").toLowerCase()} · offset {m.offset_min} min · {m.claim ? `claimed (${m.claim.kind.toLowerCase()}) by submission #${m.claim.submission_id}` : "unclaimed"}</div>
                  </div>
                  {!m.claim && m.amount_cents && <button className="btn-ghost !py-1 text-xs" onClick={() => setDialog({ link: m })}>Link & approve</button>}
                </div>
              ))}
            </div>
          </div>}

          {c.customer_message && <div className="card p-4">
            <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-2">Message sent to the customer (WhatsApp)</h3>
            <div className="bg-emerald-50 border border-emerald-100 rounded-lg px-3 py-2 text-sm whitespace-pre-line">{c.customer_message}</div>
          </div>}
        </div>
      </div>

      {/* ---------- related, customer, audit ---------- */}
      <div className="grid grid-cols-2 gap-4 items-start">
        <div className="card p-4">
          <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-2">Related / duplicate payments</h3>
          {d.related.length === 0 ? <div className="text-sm text-slate-400">None: this transaction has not been seen on any other submission.</div> :
            <div className="divide-y divide-slate-100">{d.related.map((r) => (
              <a key={r.id} href={`#/queue/${r.id}`} className="py-2 flex items-center gap-2 text-sm hover:bg-slate-50">
                <OutcomeBadge outcome={r.outcome} /><span>#{r.id} · {r.customer}{r.same_customer ? " (same customer)" : ""} · order {r.order_code}</span>
                <span className="ml-auto text-xs text-slate-500">{r.why.join(", ")}</span>
              </a>))}</div>}
          <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-500 mt-4 mb-2">Customer {cu.code}: payment history</h3>
          {cu.refunds.outstanding_cents > 0 && <div className="text-sm text-amber-800 bg-amber-50 border border-amber-200 rounded px-2 py-1 mb-2">
            Refund due to customer: <b>{rs(cu.refunds.outstanding_cents)}</b> · <a className="underline" href="#/customers">record refund</a></div>}
          {cu.history.length === 0 ? <div className="text-sm text-slate-400">First payment from this customer.</div> :
            <table className="w-full text-xs"><tbody className="divide-y divide-slate-100">{cu.history.map((h) => (
              <tr key={h.id}><td className="py-1"><a className="underline" href={`#/queue/${h.id}`}>#{h.id}</a></td><td>{rs(h.amount_cents)}</td><td>{dt(h.txn_at)}</td><td className="truncate max-w-[120px]">{h.sender_name || h.sender_account || ""}</td><td>{h.reference || ""}</td><td><OutcomeBadge outcome={h.outcome} /></td></tr>))}
            </tbody></table>}
          {cu.known_senders.length > 0 && <div className="text-xs text-slate-500 mt-2">Known sender accounts: {cu.known_senders.join(", ")}</div>}
        </div>
        <div className="card p-4">
          <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-2">Decision history & audit trail</h3>
          <ol className="space-y-2 text-xs">
            {d.history.map((h, i) => (
              <li key={"h" + i} className="border-l-2 border-slate-300 pl-2">
                <div><b>{h.outcome?.replaceAll("_", " ").toLowerCase()}</b> · {h.reason_code} · {h.actor} · {dtSec(h.at)}</div>
                {h.note && <div className="text-slate-600">Note: {h.note}</div>}
              </li>))}
          </ol>
          <details className="mt-3"><summary className="text-xs text-slate-500 cursor-pointer">Raw audit log ({d.audit.length})</summary>
            <ol className="mt-2 space-y-1 text-[11px] font-mono text-slate-600">{d.audit.map((a, i) => <li key={i}>{dtSec(a.at)} {a.actor} {a.action} {a.detail ? JSON.stringify(a.detail) : ""}</li>)}</ol>
          </details>
        </div>
      </div>

      {dialog === "approve" && <NoteDialog title="Approve this payment" confirmLabel="Approve" confirmClass="btn-green"
        help={c.claim ? "The held bank credit will be applied to this order." : "No bank credit is linked. Link an SMS from the list, or add the credit on the Bank SMS page first (every approval must be backed by a bank record)."}
        onConfirm={(note) => act("approve", { note })} onClose={() => setDialog(null)} />}
      {typeof dialog === "object" && dialog?.link && <NoteDialog title={`Link bank credit #${dialog.link.id} and approve`} confirmLabel="Link & approve" confirmClass="btn-green"
        help={`${rs(dialog.link.amount_cents)} at ${dtSec(dialog.link.txn_at)}. Only do this if you are sure this credit is this customer's payment.`}
        onConfirm={(note) => act("approve", { note, sms_id: dialog.link.id })} onClose={() => setDialog(null)} />}
      {dialog === "cash" && <NoteDialog title="Cash received in person" confirmLabel="Record cash & approve" confirmClass="btn-green"
        help="Use this only when the customer gave the cash to staff directly (no bank transfer, so no bank SMS). It is recorded as cash under your name."
        onConfirm={(note) => act("cash", { note, amount: cashAmount })} onClose={() => setDialog(null)}>
        <label className="label">Cash amount received (Rs.)</label>
        <input className="input mb-3 tabular" placeholder="5,000.00" value={cashAmount} onChange={(e) => setCashAmount(e.target.value)} />
      </NoteDialog>}
      {dialog === "reject" && <NoteDialog title="Reject this payment" confirmLabel="Reject" confirmClass="btn-red !bg-red-600 !text-white"
        help="Any bank credit held for it will be released. The customer receives a generic message."
        onConfirm={(note) => act("reject", { note })} onClose={() => setDialog(null)} />}
      {dialog === "newslip" && <NoteDialog title="Ask the customer for a new slip" confirmLabel="Send WhatsApp message" requireNote={false}
        help="The customer receives: “Please send a clear photo or screenshot of the complete payment slip…”"
        onConfirm={(note) => act("request-new-slip", { note })} onClose={() => setDialog(null)} />}
    </div>
  );
}
