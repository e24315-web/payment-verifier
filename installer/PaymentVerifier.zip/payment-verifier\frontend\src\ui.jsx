import React, { useEffect, useRef, useState } from "react";
import { OUTCOME, ORDER_STATUS } from "./lib.js";

export function usePoll(fn, ms, deps = []) {
  const saved = useRef(fn);
  saved.current = fn;
  useEffect(() => {
    saved.current();
    const id = setInterval(() => saved.current(), ms);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
}

export function OutcomeBadge({ outcome, big = false }) {
  const o = OUTCOME[outcome] || { label: outcome || "Pending", cls: "bg-slate-50 text-slate-700 border-slate-300", dot: "bg-slate-400" };
  return (
    <span className={`inline-flex items-center gap-1.5 border rounded-full font-medium ${o.cls} ${big ? "px-4 py-1.5 text-base" : "px-2 py-0.5 text-xs"}`}>
      <span className={`rounded-full ${o.dot} ${big ? "w-2.5 h-2.5" : "w-1.5 h-1.5"}`} />
      {o.label}
    </span>
  );
}

export function StatusPill({ status }) {
  return (
    <span className={`inline-block border rounded px-1.5 py-0.5 text-[11px] font-medium ${ORDER_STATUS[status] || "bg-slate-50 border-slate-200"}`}>
      {(status || "").replaceAll("_", " ").toLowerCase()}
    </span>
  );
}

const SEV = {
  HIGH: "bg-red-50 text-red-800 border-red-200",
  MEDIUM: "bg-amber-50 text-amber-900 border-amber-200",
  LOW: "bg-slate-50 text-slate-600 border-slate-200",
};
export function FlagChip({ flag }) {
  return (
    <div className={`border rounded-md px-2.5 py-1.5 text-xs ${SEV[flag.severity]}`}>
      <span className="font-semibold">{flag.code.replaceAll("_", " ").toLowerCase()}</span>
      <span className="opacity-60"> · {flag.severity.toLowerCase()}</span>
      <div className="mt-0.5">{flag.detail}</div>
    </div>
  );
}

export function ConfidenceBar({ value, threshold }) {
  if (value === null || value === undefined) return <span className="text-slate-400 text-xs">–</span>;
  const pct = Math.round(value * 100);
  const low = threshold !== undefined && value < threshold;
  return (
    <div className="flex items-center gap-2" title={threshold ? `needs ≥ ${Math.round(threshold * 100)}%` : ""}>
      <div className="w-16 h-1.5 bg-slate-200 rounded-full overflow-hidden">
        <div className={`h-full ${low ? "bg-amber-500" : "bg-emerald-500"}`} style={{ width: `${pct}%` }} />
      </div>
      <span className={`text-xs tabular ${low ? "text-amber-700 font-medium" : "text-slate-500"}`}>{pct}%</span>
    </div>
  );
}

export function Modal({ title, children, onClose }) {
  useEffect(() => {
    const h = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 flex items-center justify-center p-4" onClick={onClose}>
      <div className="card w-full max-w-lg p-5 shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-base">{title}</h3>
          <button className="text-slate-400 hover:text-slate-700 cursor-pointer" onClick={onClose}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

/** Asks for a mandatory note before running a staff action. */
export function NoteDialog({ title, help, confirmLabel, confirmClass = "btn-primary", onConfirm, onClose, children, requireNote = true }) {
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const ok = !requireNote || note.trim().length >= 3;
  return (
    <Modal title={title} onClose={onClose}>
      {help && <p className="text-sm text-slate-600 mb-3">{help}</p>}
      {children}
      <label className="label">{requireNote ? "Note (required, kept in the audit log)" : "Note (optional)"}</label>
      <textarea className="input h-20" autoFocus value={note} onChange={(e) => setNote(e.target.value)} />
      {err && <div className="text-sm text-red-700 mt-2">{err}</div>}
      <div className="flex justify-end gap-2 mt-4">
        <button className="btn-ghost" onClick={onClose}>Cancel</button>
        <button className={confirmClass} disabled={!ok || busy} onClick={async () => {
          setBusy(true); setErr("");
          try { await onConfirm(note.trim()); onClose(); } catch (e) { setErr(e.message); } finally { setBusy(false); }
        }}>{busy ? "Working…" : confirmLabel}</button>
      </div>
    </Modal>
  );
}

export function ImageViewer({ src }) {
  const [zoom, setZoom] = useState(1);
  const [rot, setRot] = useState(0);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const drag = useRef(null);
  useEffect(() => { setZoom(1); setRot(0); setPos({ x: 0, y: 0 }); }, [src]);
  if (!src) return <div className="h-80 flex items-center justify-center text-slate-400 bg-slate-100 rounded">No image</div>;
  return (
    <div>
      <div className="flex items-center gap-1 mb-2">
        <button className="btn-ghost !px-2 !py-1" onClick={() => setZoom((z) => Math.min(6, z * 1.4))} title="Zoom in">＋</button>
        <button className="btn-ghost !px-2 !py-1" onClick={() => setZoom((z) => Math.max(0.4, z / 1.4))} title="Zoom out">－</button>
        <button className="btn-ghost !px-2 !py-1" onClick={() => setRot((r) => r - 90)} title="Rotate left">⟲</button>
        <button className="btn-ghost !px-2 !py-1" onClick={() => setRot((r) => r + 90)} title="Rotate right">⟳</button>
        <button className="btn-ghost !px-2 !py-1 text-xs" onClick={() => { setZoom(1); setRot(0); setPos({ x: 0, y: 0 }); }}>Reset</button>
        <a className="btn-ghost !px-2 !py-1 text-xs ml-auto" href={src} target="_blank" rel="noreferrer">Open full size</a>
      </div>
      <div
        className="h-[420px] bg-slate-800 rounded overflow-hidden relative cursor-grab active:cursor-grabbing select-none"
        onWheel={(e) => setZoom((z) => Math.max(0.4, Math.min(6, z * (e.deltaY < 0 ? 1.15 : 0.87))))}
        onMouseDown={(e) => (drag.current = { x: e.clientX - pos.x, y: e.clientY - pos.y })}
        onMouseMove={(e) => drag.current && setPos({ x: e.clientX - drag.current.x, y: e.clientY - drag.current.y })}
        onMouseUp={() => (drag.current = null)}
        onMouseLeave={() => (drag.current = null)}
      >
        <img src={src} alt="payment slip" draggable={false}
          className="absolute inset-0 m-auto max-h-full max-w-full transition-transform duration-100"
          style={{ transform: `translate(${pos.x}px, ${pos.y}px) rotate(${rot}deg) scale(${zoom})` }} />
      </div>
    </div>
  );
}

export function Empty({ children }) {
  return <div className="text-center text-slate-400 py-10 text-sm">{children}</div>;
}

export function ErrorLine({ error }) {
  return error ? <div className="text-sm text-red-700 bg-red-50 border border-red-200 rounded px-3 py-2">{error}</div> : null;
}
