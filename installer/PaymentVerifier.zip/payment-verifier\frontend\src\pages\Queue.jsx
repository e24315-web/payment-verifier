import React, { useState } from "react";
import { api, ago, dt, rs, timeOnly } from "../lib.js";
import { Empty, OutcomeBadge, usePoll } from "../ui.jsx";
import Detail from "./Detail.jsx";

const FILTERS = [
  ["action", "Needs action"],
  ["all", "All"],
  ["NEEDS_VERIFICATION", "Needs verification"],
  ["APPROVED", "Approved"],
  ["REJECTED", "Rejected"],
];

export default function Queue({ id }) {
  const [filter, setFilter] = useState("action");
  const [q, setQ] = useState("");
  const [items, setItems] = useState([]);
  const [credits, setCredits] = useState([]);

  const load = () => {
    const p = new URLSearchParams();
    if (filter === "action") p.set("needs_action_only", "true");
    else if (filter !== "all") p.set("outcome", filter);
    if (q) p.set("q", q);
    api.get(`/api/submissions?${p}`).then(setItems).catch(() => {});
    api.get("/api/sms?unclaimed_only=true").then(setCredits).catch(() => {});
  };
  usePoll(load, 5000, [filter, q]);

  const selected = id || null;
  return (
    <div className="grid grid-cols-[400px_1fr] gap-4 items-start">
      <div className="space-y-3">
        <div className="card">
          <div className="p-2 border-b border-slate-200 space-y-2">
            <div className="flex flex-wrap gap-1">
              {FILTERS.map(([k, label]) => (
                <button key={k} onClick={() => setFilter(k)}
                  className={`px-2.5 py-1 rounded text-xs cursor-pointer ${filter === k ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}>
                  {label}
                </button>
              ))}
            </div>
            <input className="input" placeholder="Search customer, phone or order code" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <div className="max-h-[calc(100vh-330px)] overflow-y-auto divide-y divide-slate-100">
            {items.length === 0 && <Empty>{filter === "action" ? "Nothing needs action right now." : "No submissions."}</Empty>}
            {items.map((it) => {
              const diff = it.slip_amount_cents !== null && it.slip_amount_cents !== it.order.expected_cents;
              return (
                <a key={it.id} href={`#/queue/${it.id}`}
                  className={`block px-3 py-2.5 hover:bg-slate-50 ${selected === it.id ? "bg-slate-100 border-l-4 border-slate-900" : "border-l-4 border-transparent"}`}>
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-medium truncate">{it.customer.name}</span>
                    <OutcomeBadge outcome={it.outcome} />
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-500 mt-1">
                    <span>Order <b className="text-slate-700">{it.order.code}</b> · {ago(it.created_at)}</span>
                    <span className={`tabular ${diff ? "text-amber-700 font-medium" : ""}`}>
                      {rs(it.slip_amount_cents)} {diff && <span className="text-slate-400">/ {rs(it.order.expected_cents)}</span>}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 mt-1 text-xs">
                    <span className="text-slate-600 truncate">{it.reason_title}</span>
                    {it.contested && <span className="ml-auto shrink-0 bg-red-600 text-white rounded px-1.5 text-[10px]">CONTESTED</span>}
                    {it.flag_counts.HIGH > 0 && <span className="ml-auto shrink-0 bg-red-100 text-red-800 rounded px-1.5 text-[10px]">{it.flag_counts.HIGH} high-risk</span>}
                  </div>
                </a>
              );
            })}
          </div>
        </div>

        <div className="card">
          <div className="px-3 py-2 border-b border-slate-200 flex items-center justify-between">
            <span className="font-medium text-sm">Unclaimed bank credits</span>
            <a href="#/sms" className="text-xs text-slate-500 underline">all SMS</a>
          </div>
          <div className="max-h-56 overflow-y-auto divide-y divide-slate-100">
            {credits.length === 0 && <Empty>Every bank credit is matched to a payment.</Empty>}
            {credits.map((c) => (
              <div key={c.id} className="px-3 py-2 text-xs flex items-center justify-between gap-2">
                <div>
                  <div className="font-medium tabular text-sm">{rs(c.amount_cents)}</div>
                  <div className="text-slate-500">{c.business_account ? `${c.business_account.bank}` : c.account} · {timeOnly(c.txn_at)} {dt(c.txn_at).slice(0, 6)}</div>
                </div>
                <div className="text-right text-slate-500">
                  {c.balance_cents !== null && <div title="Available balance after this credit (internal)">bal {rs(c.balance_cents)}</div>}
                  {c.source !== "webhook" && <div className="text-amber-700">{c.source}</div>}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div>{selected ? <Detail id={selected} onChange={load} /> : (
        <div className="card p-10 text-center text-slate-500">
          Select a payment on the left to see what the customer sent and what the system concluded.
        </div>
      )}</div>
    </div>
  );
}
