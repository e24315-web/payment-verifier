"""Local OCR engines behind one interface. Output is an OcrDoc: text + a confidence for every character,
so a template can score a field by the OCR confidence of exactly the words it was read from.
"""
from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from pathlib import Path

from PIL import Image

# Word confidence at or above this counts as fully confident (clean text on the real receipts scores ~96).
FULL_CONF = 95.0


@dataclass
class OcrDoc:
    text: str
    char_conf: list[float] | None = None   # 0..1 per character of `text`; None = unknown (uniform)
    engine: str = "text"
    latency_ms: int = 0
    mean_conf: float = 1.0
    notes: list[str] = field(default_factory=list)

    def span_conf(self, start: int, end: int) -> float:
        if self.char_conf is None or end <= start:
            return 1.0
        vals = [c for c in self.char_conf[start:end] if c >= 0]
        return min(vals) if vals else 1.0

    @classmethod
    def from_words(cls, lines: list[list[tuple[str, float]]], engine: str, latency_ms: int) -> "OcrDoc":
        """lines: [[(word, conf0to100), ...], ...] -> text with per-char confidence (-1 for separators)."""
        parts: list[str] = []
        confs: list[float] = []
        all_c: list[float] = []
        for li, words in enumerate(lines):
            if li:
                parts.append("\n")
                confs.append(-1)
            for wi, (w, c) in enumerate(words):
                if wi:
                    parts.append(" ")
                    confs.append(-1)
                f = max(0.0, min(1.0, c / FULL_CONF))
                parts.append(w)
                confs.extend([f] * len(w))
                all_c.append(f)
        text = "".join(parts)
        return cls(text, confs, engine, latency_ms, sum(all_c) / len(all_c) if all_c else 0.0)


class OcrEngine:
    name = "base"

    def read(self, im: Image.Image) -> OcrDoc:
        raise NotImplementedError

    def available(self) -> bool:
        return True


def _fix_tessdata_prefix() -> None:
    """Common Windows mis-install: TESSDATA_PREFIX points at the install dir, data lives in ./tessdata.
    Correct it for this process only (hit on the dev machine, see DEBUGGING.md)."""
    prefix = os.environ.get("TESSDATA_PREFIX")
    if prefix and not (Path(prefix) / "eng.traineddata").exists() and (Path(prefix) / "tessdata" / "eng.traineddata").exists():
        os.environ["TESSDATA_PREFIX"] = str(Path(prefix) / "tessdata")


class TesseractEngine(OcrEngine):
    name = "tesseract"

    def __init__(self, psm: int = 6):
        _fix_tessdata_prefix()
        import pytesseract
        self._pt = pytesseract
        self.psm = psm
        exe = os.getenv("TESSERACT_CMD")
        if exe:
            pytesseract.pytesseract.tesseract_cmd = exe
        elif os.name == "nt" and Path(r"C:\Program Files\Tesseract-OCR\tesseract.exe").exists():
            pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

    def available(self) -> bool:
        try:
            self._pt.get_tesseract_version()
            return True
        except Exception:
            return False

    def read(self, im: Image.Image) -> OcrDoc:
        t = time.perf_counter()
        d = self._pt.image_to_data(im, config=f"--psm {self.psm}", output_type=self._pt.Output.DICT)
        lines: dict[tuple, list[tuple[str, float]]] = {}
        for i, w in enumerate(d["text"]):
            if not w.strip():
                continue
            key = (d["block_num"][i], d["par_num"][i], d["line_num"][i])
            lines.setdefault(key, []).append((w, float(d["conf"][i])))
        return OcrDoc.from_words(list(lines.values()), self.name, int((time.perf_counter() - t) * 1000))

    def orientation_hint(self, im: Image.Image) -> tuple[int, float] | None:
        """Tesseract OSD: (degrees to rotate counter-clockwise, confidence). Low-confidence answers are
        unreliable (it was wrong on the real deposit slip at conf 0.46), so callers only use it to order tries."""
        try:
            osd = self._pt.image_to_osd(im, output_type=self._pt.Output.DICT)
            return (-int(osd["rotate"])) % 360, float(osd["orientation_conf"])
        except Exception:
            return None


class RapidOcrEngine(OcrEngine):
    """PaddleOCR models via ONNX runtime: local, free, much better than Tesseract on phone photos."""
    name = "rapidocr"

    def __init__(self):
        from rapidocr import RapidOCR  # optional dependency
        self._ocr = RapidOCR()

    def read(self, im: Image.Image) -> OcrDoc:
        import numpy as np
        t = time.perf_counter()
        res = self._ocr(np.asarray(im.convert("RGB")))
        boxes = list(zip(res.boxes, res.txts, res.scores)) if res is not None and res.txts else []
        # Group boxes into rows by vertical overlap, then order left-to-right (label | value on one line).
        items = []
        for box, txt, score in boxes:
            ys = [p[1] for p in box]
            xs = [p[0] for p in box]
            items.append((min(ys), max(ys), min(xs), txt, float(score) * 100))
        items.sort(key=lambda r: (r[0] + r[1]) / 2)
        rows: list[list[tuple]] = []
        for it in items:
            cy = (it[0] + it[1]) / 2
            if rows:
                last = rows[-1]
                top = min(r[0] for r in last)
                bot = max(r[1] for r in last)
                if top <= cy <= bot:
                    last.append(it)
                    continue
            rows.append([it])
        lines = [[(r[3], r[4]) for r in sorted(row, key=lambda r: r[2])] for row in rows]
        return OcrDoc.from_words(lines, self.name, int((time.perf_counter() - t) * 1000))


def build_engines(preference: str | None = None) -> list[OcrEngine]:
    """Ordered engines: primary first. PV_OCR_ENGINES e.g. 'tesseract,rapidocr'."""
    order = (preference or os.getenv("PV_OCR_ENGINES", "tesseract,rapidocr")).split(",")
    engines: list[OcrEngine] = []
    for name in (n.strip() for n in order):
        try:
            eng = TesseractEngine() if name == "tesseract" else RapidOcrEngine() if name == "rapidocr" else None
        except Exception:
            eng = None
        if eng is not None and eng.available():
            engines.append(eng)
    return engines
