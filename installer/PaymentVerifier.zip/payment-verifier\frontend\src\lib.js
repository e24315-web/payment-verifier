// API client + formatting helpers.

export function staffName() {
  try { return localStorage.getItem("pv.staff") || "staff"; } catch { return "staff"; }
}
export function setStaffName(n) {
  try { localStorage.setItem("pv.staff", n); } catch { /* ignore */ }
}
function staffKey() {
  try { return localStorage.getItem("pv.key") || ""; } catch { return ""; }
}

async function req(method, path, body, isForm) {
  const headers = { "X-Staff-Name": staffName() };
  const key = staffKey();
  if (key) headers["X-Staff-Key"] = key;
  if (body && !isForm) headers["Content-Type"] = "application/json";
  const res = await fetch(path, { method, headers, body: body ? (isForm ? body : JSON.stringify(body)) : undefined });
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) {
    const msg = data && data.detail ? (typeof data.detail === "string" ? data.detail : JSON.stringify(data.detail)) : res.statusText;
    throw new Error(msg);
  }
  return data;
}
export const api = {
  get: (p) => req("GET", p),
  post: (p, b) => req("POST", p, b),
  put: (p, b) => req("PUT", p, b),
  patch: (p, b) => req("PATCH", p, b),
  form: (p, fd) => req("POST", p, fd, true),
};

export const rs = (cents) =>
  cents === null || cents === undefined ? "–" : "Rs. " + (cents / 100).toLocaleString("en-LK", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const TZ = "Asia/Colombo";
export const dt = (iso) =>
  iso ? new Date(iso).toLocaleString("en-GB", { timeZone: TZ, day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", hour12: true }) : "–";
export const dtSec = (iso) =>
  iso ? new Date(iso).toLocaleString("en-GB", { timeZone: TZ, day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true }) : "–";
export const timeOnly = (iso) =>
  iso ? new Date(iso).toLocaleTimeString("en-GB", { timeZone: TZ, hour: "2-digit", minute: "2-digit", hour12: true }) : "–";

export function ago(iso) {
  if (!iso) return "";
  const s = Math.round((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  if (s < 86400) return `${Math.round(s / 3600)} h ago`;
  return `${Math.round(s / 86400)} d ago`;
}

export function countdown(iso) {
  if (!iso) return null;
  const s = Math.round((new Date(iso).getTime() - Date.now()) / 1000);
  if (s <= 0) return "time up";
  const m = Math.floor(s / 60);
  return `${m}:${String(s % 60).padStart(2, "0")} left`;
}

export const OUTCOME = {
  APPROVED: { label: "Approved", cls: "bg-emerald-50 text-emerald-800 border-emerald-300", dot: "bg-emerald-500" },
  REJECTED: { label: "Rejected", cls: "bg-red-50 text-red-800 border-red-300", dot: "bg-red-500" },
  NEEDS_VERIFICATION: { label: "Needs verification", cls: "bg-amber-50 text-amber-900 border-amber-300", dot: "bg-amber-500" },
};

export const ORDER_STATUS = {
  AWAITING_PAYMENT: "bg-sky-50 text-sky-800 border-sky-200",
  PARTIALLY_PAID: "bg-amber-50 text-amber-900 border-amber-300",
  PAID: "bg-emerald-50 text-emerald-800 border-emerald-300",
  EXPIRED: "bg-slate-100 text-slate-600 border-slate-300",
  CANCELLED: "bg-red-50 text-red-800 border-red-300",
};

export const FIELD_LABELS = {
  amount_cents: "Amount", txn_at: "Transaction date & time", receiving_account: "Paid to account",
  reference: "Bank reference", secondary_reference: "e-Receipt reference", sender_account: "Sender account",
  sender_name: "Sender name", beneficiary_name: "Beneficiary name", narration: "Narration / remarks",
  status: "Transfer status", generated_at: "Receipt generated at", bank: "Bank", teller_sequence: "Teller sequence",
  txn_has_seconds: "Time has seconds", date_corroborated: "Date confirmed by 2nd date on slip",
  txn_date: "Date on slip (no time printed)",
};
